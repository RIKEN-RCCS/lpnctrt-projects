#!/bin/bash

for P in 1 2 4 6 8 9 10 12 15 16 24; do
  OMP_NUM_THREADS=1 mpiexec.hydra -np $P ./eigenexa_benchmark -f IN-check
  OMP_NUM_THREADS=4 mpiexec.hydra -np $P ./eigenexa_benchmark -f IN-check
done


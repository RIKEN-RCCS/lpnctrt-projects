#!/bin/bash

if [ -f IN-check ]; then
  \rm IN-check
fi

echo "!   N  nvec bx  by m t s e" > IN-check

awk 'BEGIN{ for(N=3;N<=256;N++){ \
	print N" "N" 48 128 1 0 0 1"; \
	print N" "N" 48 128 1 0 1 1"; \
	print N" "N" 48 128 1 2 0 1"; \
	print N" "N" 48 128 1 2 1 1"; \
    } exit;}END{}' >> IN-check
#for N in 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 100 200 512 1024 2048; do
for N in 512 1024 2048; do
  echo $N" "$N" 48 128 1 0 0 1" >> IN-check
  echo $N" "$N" 48 128 1 0 1 1" >> IN-check
  echo $N" "$N" 48 128 1 2 0 1" >> IN-check
  echo $N" "$N" 48 128 1 2 1 1" >> IN-check
done
echo "-1 0 0 0 0 0 0 0" >> IN-check

for P in 1 2 3 4 5 6 8 9 10 12 15 16 24; do
for T in 1 2 3 4; do
  if [ -f LOG-$P-$T ]; then
    \rm LOG-$P-$T
  fi
done
done
  
INTEL_MPI="yes"
INTEL_MPI1=`ldd eigenexa_benchmark | awk '/libmpifort/{ print $1}'`
INTEL_MPI2=`which mpiexec.hydra | grep " no "`
if [ x$INTEL_MPI1 = x ]; then
	INTEL_MPI="no"
fi
if [ x$INTEL_MPI2 != x ]; then
	INTEL_MPI="no"
fi

if [ $INTEL_MPI = "yes" ]; then
	export I_MPI_CBWR=2
	export FI_SOCKETS_IFACE=enp4s0f0
	export FI_PROVIDER=sockets
	export I_MPI_FABRICS=shm
fi

for P in 2 3 4 5 6 8 9 10 12 15 16 24; do
for T in 2 3 4; do
  if [ $INTEL_MPI = "yes" ]; then
# intel MPI
    mpiexec.hydra \
	-np $P -genv OMP_NUM_THREADS $T \
	./eigenexa_benchmark -f IN-check < /dev/null |& tee LOG-$P-$T
  else
# openMPI
    mpirun \
	-np $P -x OMP_NUM_THREADS=$T \
	./eigenexa_benchmark -f IN-check < /dev/null |& tee LOG-$P-$T

  fi
done
done

killall -9 mpiexec.hydra


#ifndef __HEADER_EIGEN_GPU_CHECK_H__
#define __HEADER_EIGEN_GPU_CHECK_H__

#include <stdio.h>
#include <cuda.h>
#include <cuda_runtime.h>

#ifdef __cplusplus
extern "C" {
#endif

__host__ void
eigen_GPU_check_DP(const int L, const int nm, const int n, const int m, double *a_, double *w_, double *z_, const cudaStream_t stream);
__host__ void
eigen_GPU_check_FP(const int L, const int nm, const int n, const int m, float *a_, float *w_, float *z_, const cudaStream_t stream);

#ifdef __cplusplus
}
#endif

#endif


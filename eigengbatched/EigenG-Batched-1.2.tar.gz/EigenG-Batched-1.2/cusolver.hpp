#include <cusolverDn.h>

void
cusolver_test(int n, half *A, int lda, half *W, int batchSize)
{
}

void
cusolver_test(int n, double *A, int lda, double *W, int batchSize)
{
  cusolverDnHandle_t cusolverH = NULL;
  cusolverDnCreate(&cusolverH);
  cudaStream_t stream = NULL; 
  cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking);
  cusolverDnSetStream(cusolverH, stream);
  syevjInfo_t syevj_params = NULL;
  cusolverDnCreateSyevjInfo(&syevj_params);
  cusolverDnXsyevjSetTolerance(syevj_params,1e-6);
  cusolverDnXsyevjSetMaxSweeps(syevj_params,100);
  cusolverDnXsyevjSetSortEig(syevj_params,0);

  int lwork;
  cusolverDnDsyevjBatched_bufferSize(
    cusolverH,
    CUSOLVER_EIG_MODE_VECTOR,
    CUBLAS_FILL_MODE_UPPER,
    n,
    A,
    lda,
    W,
    &lwork,
    syevj_params,
    batchSize
    );

  double *d_work;
  cudaMalloc((void**)&d_work, sizeof(double)*lwork);
  int *d_info;
  cudaMalloc((void**)&d_info, sizeof(int)*batchSize);

  cusolverDnDsyevjBatched(
    cusolverH,
    CUSOLVER_EIG_MODE_VECTOR,
    CUBLAS_FILL_MODE_UPPER,
    n,
    A,
    lda,
    W,
    d_work,
    lwork,
    d_info,
    syevj_params,
    batchSize
    );

  cudaFree(d_work);
  cudaFree(d_info);

  cusolverDnDestroySyevjInfo(syevj_params);
  cusolverDnDestroy(cusolverH);
  cudaStreamDestroy(stream);
} 

void
cusolver_test(int n, float *A, int lda, float *W, int batchSize)
{
  cusolverDnHandle_t cusolverH = NULL;
  cusolverDnCreate(&cusolverH);
  cudaStream_t stream = NULL; 
  cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking);
  cusolverDnSetStream(cusolverH, stream);
  syevjInfo_t syevj_params = NULL;
  cusolverDnCreateSyevjInfo(&syevj_params);
  cusolverDnXsyevjSetTolerance(syevj_params,1e-6);
  cusolverDnXsyevjSetMaxSweeps(syevj_params,100);
  cusolverDnXsyevjSetSortEig(syevj_params,1);

  int lwork;
  cusolverDnSsyevjBatched_bufferSize(
    cusolverH,
    CUSOLVER_EIG_MODE_VECTOR,
    CUBLAS_FILL_MODE_LOWER,
    n,
    A,
    lda,
    W,
    &lwork,
    syevj_params,
    batchSize
    );

  float *s_work;
  cudaMalloc((void**)&s_work, sizeof(float)*lwork);
  int *s_info;
  cudaMalloc((void**)&s_info, sizeof(int)*batchSize);

  cusolverDnSsyevjBatched(
    cusolverH,
    CUSOLVER_EIG_MODE_VECTOR,
    CUBLAS_FILL_MODE_LOWER,
    n,
    A,
    lda,
    W,
    s_work,
    lwork,
    s_info,
    syevj_params,
    batchSize
    );

  cudaFree(s_work);
  cudaFree(s_info);

  cusolverDnDestroySyevjInfo(syevj_params);
  cusolverDnDestroy(cusolverH);
  cudaStreamDestroy(stream);
} 


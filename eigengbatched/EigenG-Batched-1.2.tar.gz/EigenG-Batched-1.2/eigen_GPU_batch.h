#ifndef __HEADER_EIGEN_GPU_BATCH_H__
#define __HEADER_EIGEN_GPU_BATCH_H__

#include <stdio.h>
#include <cuda.h>
#include <cuda_runtime.h>

#ifdef __cplusplus
extern "C" {
#endif

//
// if wk == NULL && n > 1 then ((size_t)w)[0] returns the length of
// work buffer required in the batch operation with an accordance to
// the matrix size and GPU architecture.
//

void
eigen_GPU_batch_DP(const int L, const int nm, const int n, const int m, double * a, double * w, double *wk, const cudaStream_t stream);

void
eigen_GPU_batch_FP(const int L, const int nm, const int n, const int m, float * a, float * w, float *wk, const cudaStream_t stream);

#ifdef __cplusplus
}
#endif

#endif


#include <stdio.h>
#include <math.h>
#include <limits>
#include <omp.h>

#include <cuda.h>
#include <cuda_runtime.h>

#include "misc.hpp"
#include "eigen_GPU_batch.hpp"

#include "eigen_GPU_check.hpp"
#include "cusolver.hpp"
#include "cusolver_evd.hpp"


extern "C" {
// for calling the original fortran EISPACK routines
  void tred1_(int *, int *, double *, double *, double *);
  void tql2_(int *, int *, double *, double *, double *, int *);
  void trbak1_(int *, int *, double *, int *, double *);
}

enum Matrix_type {
  MATRIX_SYM_RAND,
  MATRIX_LETKF,
  MATRIX_FRANK
};
enum Solver_type {
  EIGENG_BATCH,
  CUSOLVER_EVJ_BATCH,
  CUSOLVER_EVD
};



template <class T>
__host__ void
set_mat(T *a, const int nm, const int n, const enum Matrix_type type, const int seed_)
{
  unsigned int seed = seed_;

  if ( type == MATRIX_LETKF ) {

    T * w = (T *)malloc(sizeof(T)*n);
    for(int i=1;i<=n;i++){
      const T eps = std::numeric_limits<T>::epsilon();
      const T R = 16-1;
      const T delta = R*(2*(rand_r(&seed)/RAND_MAX)-1.)*eps;
      const T DELTA = 1.0+delta;
      w[i-1] = (T)(n-1)*DELTA;
    }
    const int numV=2;
    for(int i=1;i<=numV;i++){
      const int j=(rand_r(&seed)%n);
      w[j] += (((T)rand_r(&seed))/RAND_MAX)*n;
    }

    T scale = 0;
#pragma omp parallel for
    for(int i=1;i<=n;i++){
      scale = (T)fmax(scale, fabs(w[i-1]));
    }
    scale = (T)fmax(scale, 1.);
#pragma omp parallel for
    for(int i=1;i<=n;i++){
      w[i-1] /= scale;
    }

    T * ht = (T *)malloc(sizeof(T)*n);
#pragma omp parallel for
    for(int i=1;i<=n;i++){
      ht[i-1] = (T)sqrt((double)i);
    }

#pragma omp parallel
    {

    T * hi = (T *)malloc(sizeof(T)*n);
    T * hj = (T *)malloc(sizeof(T)*n);

    int i0=0, j0=0;
#pragma omp for collapse(2)
    for(int i=1;i<=n;i++){
    for(int j=1;j<=n;j++){

    if(i0!=i){
    if(i==1){
      T hi_ = ht[n-1];
#pragma omp simd
      for(int j=1;j<=n;j++) hi[j-1] = 1. / hi_;
    } else {
      T s = (T)(i-1);
      T hi_ = ht[i-2] * ht[i-1];
#pragma omp simd
      for(int j=1;j<=i-1;j++) hi[j-1] = 1. / hi_;
      hi[i-1] = -s / hi_;
#pragma omp simd
      for(int j=i+1;j<=n;j++) hi[j-1] = 0.;
    }
    i0=i;
    }

    if(j0!=j){
    if(j==1){
      T hj_ = ht[n-1];
#pragma omp simd
      for(int k=1;k<=n;k++) hj[k-1] = 1. / hj_;
    } else {
      T s = (T)(j-1);
      T hj_ = ht[j-2] * ht[j-1];
#pragma omp simd
      for(int k=1;k<=j-1;k++) hj[k-1] = 1. / hj_;
      hj[j-1] = -s / hj_;
#pragma omp simd
      for(int k=j+1;k<=n;k++) hj[k-1] = 0.;
    }
    j0=j;
    }

      T t = 0.;
#pragma omp simd
      for(int k=1;k<=n;k++) {
        const T hijk = hi[k-1]*hj[k-1];
        t += w[k-1]*hijk;
      }
      a[(j-1)+(i-1)*nm] = t;

    }
    }
      free(hi);
      free(hj);
    }

#pragma omp parallel for collapse(2)
    for(int i=1;i<=n;i++){
    for(int j=1;j<=n;j++){
      a[(j-1)+(i-1)*nm] *= scale;
    }}

    free(w); free(ht);

  } else {

#pragma omp parallel for
    for(int i=0;i<n;i++) {
    for(int j=0;j<=i;j++) {
      T x, t;
      switch ( type ) {
      case MATRIX_SYM_RAND:
#pragma omp critical
	{
        t = static_cast<T>(static_cast<double>(rand_r(&seed))/RAND_MAX);
	}
        x = 2*t - static_cast<T>(1.0);
        break;
      case MATRIX_FRANK:
        int k = min(j+1,i+1);
#if 0
        if ( j==0 || i==0 ) {
          k = 0;
        }
        if ( j==0 && i==0 ) {
          k = 1;
        }
#endif
        x = static_cast<T>(k);
        break;
      }
      a[i+nm*j] = a[j+nm*i] = x;
    }}
  }
}

template <class T, enum Solver_type Solver>
__host__ void
GPU_batch_test(const int Itr, const int L, const int n, const enum Matrix_type type, const bool accuracy_test)
{
  const int nm = n + (n&0x1);
  const int m  = n;
  size_t len;

  len = sizeof(T)*L*nm*n;
  T *a_h = (T *)malloc(len);
  cudaSetDevice(0);
  T *a_d = NULL;  cudaMalloc(&a_d, len);
  T *b_d = NULL;  cudaMalloc(&b_d, len);
  len = sizeof(T)*L*m;
  T *w_d = NULL;  cudaMalloc(&w_d, len);

  {
#if PRINT_DIAGNOSTIC
    cudaDeviceSynchronize();
    double ts = get_wtime();
#endif
    #pragma omp parallel for
    for(int i=0; i<L; i++) {
      T *a = a_h + (size_t)i*(nm*n);
      set_mat(a, nm, n, type, i);
    }
#if PRINT_DIAGNOSTIC
    cudaDeviceSynchronize();
    double te = get_wtime();
    printf("  Data generation :: %le [s]\n", te-ts);
#endif
  }
  len = sizeof(T)*L*nm*n;
  {
#if PRINT_DIAGNOSTIC
    cudaDeviceSynchronize();
    double ts = get_wtime();
#endif
    cudaMemcpy(b_d, a_h, len, cudaMemcpyHostToDevice);
#if PRINT_DIAGNOSTIC
    cudaDeviceSynchronize();
    double te = get_wtime();
    printf("  Host -> Dev :: %le [s]\n", te-ts);
#endif
  }

  T *wk_d = NULL;
  if ( Solver == EIGENG_BATCH ) {
    eigen_GPU_batch_BufferSize(L, nm, n, m, a_d, w_d, &len);
    cudaMalloc(&wk_d, len);
  }

  cudaStream_t stream;
  cudaStreamCreate( &stream );

  double total_time = 0;
  for(int ITR=0; ITR<Itr; ITR++) {

    len = sizeof(T)*L*nm*n;
    cudaMemcpy(a_d, b_d, len, cudaMemcpyDeviceToDevice);

    cudaDeviceSynchronize();
  cudaSetDevice(0);
    double ts = get_wtime();
    switch ( Solver )  {
    case EIGENG_BATCH:
      eigen_GPU_batch(L, nm, n, m, a_d, w_d, wk_d, stream);
      break;
    case CUSOLVER_EVJ_BATCH:
      cusolver_test(n, a_d, nm, w_d, L);
      break;
    case CUSOLVER_EVD:
      cusolver_evd_test(n, a_d, nm, w_d, L);
      break;
    }
  cudaSetDevice(0);

    cudaDeviceSynchronize();
    double te = get_wtime();
    total_time += (te - ts);
  }

  if (accuracy_test) {
#if PRINT_DIAGNOSTIC
    cudaDeviceSynchronize();
    double ts = get_wtime();
#endif
    eigen_GPU_check(L, nm, n, m, b_d, w_d, a_d, stream);
#if PRINT_DIAGNOSTIC
    cudaDeviceSynchronize();
    double te = get_wtime();
    printf("  Accuracy Test :: %le [s]\n", te-ts);
#endif
  }

  cudaStreamDestroy( stream );

  double tm = total_time / Itr;
  double flop = L*(double)n*n*n*(4./3+2.);
  double data = sizeof(T)*L*(double)n*(n/2.+n+2.+3*n/2.);

  printf("N=%d time=%le %le[GF/s] %le[GB/s]\n",
         n, tm, 1e-9*flop/tm, 1e-9*data/tm);
  fflush(stdout);

  cudaFree(a_d);
  cudaFree(b_d);
  cudaFree(w_d);
  if ( Solver == EIGENG_BATCH ) { cudaFree(wk_d); }
  free(a_h);
}


int
main(int argc, char* argv[])
{
  print_header("GPU-Batch-eigensolver", argc, argv);

  const int iter = 100;
  const int numBatch = 16384;
//  const enum Matrix_type type = MATRIX_FRANK;
  const enum Matrix_type type = MATRIX_LETKF;
//  const enum Matrix_type type = MATRIX_SYM_RAND;

  const int nums[] = { 4, 7, 8, 9, 10, 12, 14, 15, 16, 17, 20, 24, 28, 31, 32, 33, 48, 64, 65, 96, 97, 128, 129, 0 };

//  printf(">> half accuracy test\n");
//  for(int n=1; n<=96; n*=2)
//    GPU_batch_test<half,EIGENG_BATCH>(1, 1, n, type, true);

  printf(">> float accuracy test\n");
  for(int i=0; nums[i] > 0; i++) { const int n = nums[i];
    GPU_batch_test<float,EIGENG_BATCH>(1, 1, n, type, true);
  }

  printf("\n");
  printf(">> double accuracy test\n");
  for(int i=0; nums[i] > 0; i++) { const int n = nums[i];
    GPU_batch_test<double,EIGENG_BATCH>(1, 1, n, type, true);
  }

  printf("\n");
  printf(">> float EigenG TQL average out of the %d iterations.\n",iter);
  for(int i=0; nums[i] > 0; i++) { const int n = nums[i];
    GPU_batch_test<float,EIGENG_BATCH>(iter, numBatch, n, type, true);
  }

  printf("\n");
  printf(">> double EigenG TQL avarage out of the %d iterations.\n",iter);
  for(int i=0; nums[i] > 0; i++) { const int n = nums[i];
    GPU_batch_test<double,EIGENG_BATCH>(iter, numBatch, n, type, true);
  }

#if 0
  printf("\n");
  printf(">> float cusolver Jacobi avarage out of the %d iterations.\n",iter);
  for(int n=8; n<=128; n*=2)
    GPU_batch_test<float,CUSOLVER_EVJ_BATCH>(iter, numBatch, n, type, false);

  printf("\n");
  printf(">> double cusolver Jacobi avarage out of the %d iterations.\n",iter);
  for(int n=8; n<=128; n*=2)
    GPU_batch_test<double,CUSOLVER_EVJ_BATCH>(iter, numBatch, n, type, false);
#endif
}



#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdint.h>
#include "cublas.h"

#include "aspen.h"
#include "aspen_fortran.h"

// external API from fortran calls
extern  "C" {

  void
  aspen_init_ ( const int * device_id )
  {
    ASPEN_init( *device_id );
  }

  void
  aspen_shutdown_ ( void )
  {
    ASPEN_shutdown( );
  }

  void
  aspen_get_version_info_ ( int *version,
                            char *codename, unsigned int length_codename,
                            char *releasedate, unsigned int length_releasedate )
  {
    int  version_;
    char code_name[256];
    char release_date[256];

    ASPEN_get_version_info ( &version_, code_name, release_date );

    *version = version_;

    memset( codename, ' ', length_codename );
    size_t len_code_name = strlen( code_name );
    if ( len_code_name >= length_codename ) {
      len_code_name = (size_t)length_codename;
    }
    strncpy( codename, code_name, len_code_name );

    memset( releasedate, ' ', length_releasedate );
    size_t len_release_date = strlen( release_date );
    if ( len_release_date >= length_releasedate ) {
      len_release_date = (size_t)length_releasedate;
    }
    strncpy( releasedate, release_date, len_release_date );
  }

  void
  aspen_wsymv_ (
                  const char              * uplo,
                  const int               * n,
                  const cuddreal          * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuddreal          * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddreal *A = (cuddreal *)(uintptr_t)(*devPtrA);
    const cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);
          cuddreal *y = (cuddreal *)(uintptr_t)(*devPtry);

    ASPEN_wsymv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_dsymv_ (
                  const char              * uplo,
                  const int               * n,
                  const double            * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const double            * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const double *A = (double *)(uintptr_t)(*devPtrA);
    const double *x = (double *)(uintptr_t)(*devPtrx);
          double *y = (double *)(uintptr_t)(*devPtry);

    ASPEN_dsymv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_ssymv_ (
                  const char              * uplo,
                  const int               * n,
                  const float             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const float             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const float *A = (float *)(uintptr_t)(*devPtrA);
    const float *x = (float *)(uintptr_t)(*devPtrx);
          float *y = (float *)(uintptr_t)(*devPtry);

    ASPEN_ssymv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_uhemv_ (
                  const char              * uplo,
                  const int               * n,
                  const cuddcomplex       * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuddcomplex       * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddcomplex *A = (cuddcomplex *)(uintptr_t)(*devPtrA);
    const cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);
          cuddcomplex *y = (cuddcomplex *)(uintptr_t)(*devPtry);

    ASPEN_uhemv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_zhemv_ (
                  const char              * uplo,
                  const int               * n,
                  const cuDoubleComplex   * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuDoubleComplex   * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuDoubleComplex *A = (cuDoubleComplex *)(uintptr_t)(*devPtrA);
    const cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);
          cuDoubleComplex *y = (cuDoubleComplex *)(uintptr_t)(*devPtry);

    ASPEN_zhemv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_chemv_ (
                  const char              * uplo,
                  const int               * n,
                  const cuFloatComplex    * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuFloatComplex    * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuFloatComplex *A = (cuFloatComplex *)(uintptr_t)(*devPtrA);
    const cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);
          cuFloatComplex *y = (cuFloatComplex *)(uintptr_t)(*devPtry);

    ASPEN_chemv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_hsymv_ (
                  const char              * uplo,
                  const int               * n,
                  const half              * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const half              * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const half *A = (half *)(uintptr_t)(*devPtrA);
    const half *x = (half *)(uintptr_t)(*devPtrx);
          half *y = (half *)(uintptr_t)(*devPtry);

    ASPEN_hsymv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

#endif
  void
  aspen_i128symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int128            * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int128            * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int128 *A = (int128 *)(uintptr_t)(*devPtrA);
    const int128 *x = (int128 *)(uintptr_t)(*devPtrx);
          int128 *y = (int128 *)(uintptr_t)(*devPtry);

    ASPEN_i128symv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_i64symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int64             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int64 *A = (int64 *)(uintptr_t)(*devPtrA);
    const int64 *x = (int64 *)(uintptr_t)(*devPtrx);
          int64 *y = (int64 *)(uintptr_t)(*devPtry);

    ASPEN_i64symv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_i32symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int32             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int32 *A = (int32 *)(uintptr_t)(*devPtrA);
    const int32 *x = (int32 *)(uintptr_t)(*devPtrx);
          int32 *y = (int32 *)(uintptr_t)(*devPtry);

    ASPEN_i32symv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_i16symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int16             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int16 *A = (int16 *)(uintptr_t)(*devPtrA);
    const int16 *x = (int16 *)(uintptr_t)(*devPtrx);
          int16 *y = (int16 *)(uintptr_t)(*devPtry);

    ASPEN_i16symv( *uplo, *n,
                 *alpha, A, *lda, x, *incx, *beta,  y, *incy );
  }

  void
  aspen_waxpy_ (
                  const int               * n,
                  const cuddreal          * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);
          cuddreal *y = (cuddreal *)(uintptr_t)(*devPtry);

    ASPEN_waxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_daxpy_ (
                  const int               * n,
                  const double            * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const double *x = (double *)(uintptr_t)(*devPtrx);
          double *y = (double *)(uintptr_t)(*devPtry);

    ASPEN_daxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_saxpy_ (
                  const int               * n,
                  const float             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const float *x = (float *)(uintptr_t)(*devPtrx);
          float *y = (float *)(uintptr_t)(*devPtry);

    ASPEN_saxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_uaxpy_ (
                  const int               * n,
                  const cuddcomplex       * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);
          cuddcomplex *y = (cuddcomplex *)(uintptr_t)(*devPtry);

    ASPEN_uaxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_zaxpy_ (
                  const int               * n,
                  const cuDoubleComplex   * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);
          cuDoubleComplex *y = (cuDoubleComplex *)(uintptr_t)(*devPtry);

    ASPEN_zaxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_caxpy_ (
                  const int               * n,
                  const cuFloatComplex    * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);
          cuFloatComplex *y = (cuFloatComplex *)(uintptr_t)(*devPtry);

    ASPEN_caxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_haxpy_ (
                  const int               * n,
                  const half              * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const half *x = (half *)(uintptr_t)(*devPtrx);
          half *y = (half *)(uintptr_t)(*devPtry);

    ASPEN_haxpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

#endif
  void
  aspen_i128axpy_ (
                  const int               * n,
                  const int128            * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int128 *x = (int128 *)(uintptr_t)(*devPtrx);
          int128 *y = (int128 *)(uintptr_t)(*devPtry);

    ASPEN_i128axpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_i64axpy_ (
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int64 *x = (int64 *)(uintptr_t)(*devPtrx);
          int64 *y = (int64 *)(uintptr_t)(*devPtry);

    ASPEN_i64axpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_i32axpy_ (
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int32 *x = (int32 *)(uintptr_t)(*devPtrx);
          int32 *y = (int32 *)(uintptr_t)(*devPtry);

    ASPEN_i32axpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_i16axpy_ (
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int16 *x = (int16 *)(uintptr_t)(*devPtrx);
          int16 *y = (int16 *)(uintptr_t)(*devPtry);

    ASPEN_i16axpy( *n,
                 *alpha, x, *incx, y, *incy );
  }

  void
  aspen_waxpby_ (
                  const int               * n,
                  const cuddreal          * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuddreal          * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);
          cuddreal *y = (cuddreal *)(uintptr_t)(*devPtry);

    ASPEN_waxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_daxpby_ (
                  const int               * n,
                  const double            * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const double            * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const double *x = (double *)(uintptr_t)(*devPtrx);
          double *y = (double *)(uintptr_t)(*devPtry);

    ASPEN_daxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_saxpby_ (
                  const int               * n,
                  const float             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const float             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const float *x = (float *)(uintptr_t)(*devPtrx);
          float *y = (float *)(uintptr_t)(*devPtry);

    ASPEN_saxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_uaxpby_ (
                  const int               * n,
                  const cuddcomplex       * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuddcomplex       * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);
          cuddcomplex *y = (cuddcomplex *)(uintptr_t)(*devPtry);

    ASPEN_uaxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_zaxpby_ (
                  const int               * n,
                  const cuDoubleComplex   * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuDoubleComplex   * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);
          cuDoubleComplex *y = (cuDoubleComplex *)(uintptr_t)(*devPtry);

    ASPEN_zaxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_caxpby_ (
                  const int               * n,
                  const cuFloatComplex    * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const cuFloatComplex    * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);
          cuFloatComplex *y = (cuFloatComplex *)(uintptr_t)(*devPtry);

    ASPEN_caxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_haxpby_ (
                  const int               * n,
                  const half              * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const half              * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const half *x = (half *)(uintptr_t)(*devPtrx);
          half *y = (half *)(uintptr_t)(*devPtry);

    ASPEN_haxpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

#endif
  void
  aspen_i128axpby_ (
                  const int               * n,
                  const int128            * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int128            * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int128 *x = (int128 *)(uintptr_t)(*devPtrx);
          int128 *y = (int128 *)(uintptr_t)(*devPtry);

    ASPEN_i128axpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_i64axpby_ (
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int64             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int64 *x = (int64 *)(uintptr_t)(*devPtrx);
          int64 *y = (int64 *)(uintptr_t)(*devPtry);

    ASPEN_i64axpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_i32axpby_ (
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int32             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int32 *x = (int32 *)(uintptr_t)(*devPtrx);
          int32 *y = (int32 *)(uintptr_t)(*devPtry);

    ASPEN_i32axpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_i16axpby_ (
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int16             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int16 *x = (int16 *)(uintptr_t)(*devPtrx);
          int16 *y = (int16 *)(uintptr_t)(*devPtry);

    ASPEN_i16axpby( *n,
                 *alpha, x, *incx, *beta, y, *incy );
  }

  void
  aspen_wswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);
    cuddreal *y = (cuddreal *)(uintptr_t)(*devPtry);

    ASPEN_wswap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_dswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    double *x = (double *)(uintptr_t)(*devPtrx);
    double *y = (double *)(uintptr_t)(*devPtry);

    ASPEN_dswap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_sswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    float *x = (float *)(uintptr_t)(*devPtrx);
    float *y = (float *)(uintptr_t)(*devPtry);

    ASPEN_sswap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_uswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);
    cuddcomplex *y = (cuddcomplex *)(uintptr_t)(*devPtry);

    ASPEN_uswap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_zswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);
    cuDoubleComplex *y = (cuDoubleComplex *)(uintptr_t)(*devPtry);

    ASPEN_zswap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_cswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);
    cuFloatComplex *y = (cuFloatComplex *)(uintptr_t)(*devPtry);

    ASPEN_cswap( *n,
                 x, *incx, y, *incy );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_hswap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    half *x = (half *)(uintptr_t)(*devPtrx);
    half *y = (half *)(uintptr_t)(*devPtry);

    ASPEN_hswap( *n,
                 x, *incx, y, *incy );
  }

#endif
  void
  aspen_i128swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    int128 *x = (int128 *)(uintptr_t)(*devPtrx);
    int128 *y = (int128 *)(uintptr_t)(*devPtry);

    ASPEN_i128swap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_i64swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    int64 *x = (int64 *)(uintptr_t)(*devPtrx);
    int64 *y = (int64 *)(uintptr_t)(*devPtry);

    ASPEN_i64swap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_i32swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    int32 *x = (int32 *)(uintptr_t)(*devPtrx);
    int32 *y = (int32 *)(uintptr_t)(*devPtry);

    ASPEN_i32swap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_i16swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    int16 *x = (int16 *)(uintptr_t)(*devPtrx);
    int16 *y = (int16 *)(uintptr_t)(*devPtry);

    ASPEN_i16swap( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_wcopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);
          cuddreal *y = (cuddreal *)(uintptr_t)(*devPtry);

    ASPEN_wcopy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_dcopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const double *x = (double *)(uintptr_t)(*devPtrx);
          double *y = (double *)(uintptr_t)(*devPtry);

    ASPEN_dcopy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_scopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const float *x = (float *)(uintptr_t)(*devPtrx);
          float *y = (float *)(uintptr_t)(*devPtry);

    ASPEN_scopy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_ucopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);
          cuddcomplex *y = (cuddcomplex *)(uintptr_t)(*devPtry);

    ASPEN_ucopy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_zcopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);
          cuDoubleComplex *y = (cuDoubleComplex *)(uintptr_t)(*devPtry);

    ASPEN_zcopy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_ccopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);
          cuFloatComplex *y = (cuFloatComplex *)(uintptr_t)(*devPtry);

    ASPEN_ccopy( *n,
                 x, *incx, y, *incy );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_hcopy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const half *x = (half *)(uintptr_t)(*devPtrx);
          half *y = (half *)(uintptr_t)(*devPtry);

    ASPEN_hcopy( *n,
                 x, *incx, y, *incy );
  }

#endif
  void
  aspen_i128copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int128 *x = (int128 *)(uintptr_t)(*devPtrx);
          int128 *y = (int128 *)(uintptr_t)(*devPtry);

    ASPEN_i128copy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_i64copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int64 *x = (int64 *)(uintptr_t)(*devPtrx);
          int64 *y = (int64 *)(uintptr_t)(*devPtry);

    ASPEN_i64copy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_i32copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int32 *x = (int32 *)(uintptr_t)(*devPtrx);
          int32 *y = (int32 *)(uintptr_t)(*devPtry);

    ASPEN_i32copy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_i16copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                )
  {
    const int16 *x = (int16 *)(uintptr_t)(*devPtrx);
          int16 *y = (int16 *)(uintptr_t)(*devPtry);

    ASPEN_i16copy( *n,
                 x, *incx, y, *incy );
  }

  void
  aspen_wscal_ (
                  const int               * n,
                  const cuddreal          * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);

    ASPEN_wscal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_dscal_ (
                  const int               * n,
                  const double            * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    double *x = (double *)(uintptr_t)(*devPtrx);

    ASPEN_dscal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_sscal_ (
                  const int               * n,
                  const float             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    float *x = (float *)(uintptr_t)(*devPtrx);

    ASPEN_sscal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_uscal_ (
                  const int               * n,
                  const cuddcomplex       * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);

    ASPEN_uscal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_zscal_ (
                  const int               * n,
                  const cuDoubleComplex   * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);

    ASPEN_zscal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_cscal_ (
                  const int               * n,
                  const cuFloatComplex    * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);

    ASPEN_cscal( *n,
                 *alpha, x, *incx );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_hscal_ (
                  const int               * n,
                  const half              * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    half *x = (half *)(uintptr_t)(*devPtrx);

    ASPEN_hscal( *n,
                 *alpha, x, *incx );
  }

#endif
  void
  aspen_i128scal_ (
                  const int               * n,
                  const int128            * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    int128 *x = (int128 *)(uintptr_t)(*devPtrx);

    ASPEN_i128scal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_i64scal_ (
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    int64 *x = (int64 *)(uintptr_t)(*devPtrx);

    ASPEN_i64scal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_i32scal_ (
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    int32 *x = (int32 *)(uintptr_t)(*devPtrx);

    ASPEN_i32scal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_i16scal_ (
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                )
  {
    int16 *x = (int16 *)(uintptr_t)(*devPtrx);

    ASPEN_i16scal( *n,
                 *alpha, x, *incx );
  }

  void
  aspen_wzero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    cuddreal *x = (cuddreal *)(uintptr_t)(*devPtrx);

    ASPEN_WZERO( x, *n );
  }

  void
  aspen_dzero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    double *x = (double *)(uintptr_t)(*devPtrx);

    ASPEN_DZERO( x, *n );
  }

  void
  aspen_szero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    float *x = (float *)(uintptr_t)(*devPtrx);

    ASPEN_SZERO( x, *n );
  }

  void
  aspen_uzero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    cuddcomplex *x = (cuddcomplex *)(uintptr_t)(*devPtrx);

    ASPEN_UZERO( x, *n );
  }

  void
  aspen_zzero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    cuDoubleComplex *x = (cuDoubleComplex *)(uintptr_t)(*devPtrx);

    ASPEN_ZZERO( x, *n );
  }

  void
  aspen_czero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    cuFloatComplex *x = (cuFloatComplex *)(uintptr_t)(*devPtrx);

    ASPEN_CZERO( x, *n );
  }

#if ASPEN_HALF_ENABLED
  void
  aspen_hzero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    half *x = (half *)(uintptr_t)(*devPtrx);

    ASPEN_HZERO( x, *n );
  }

#endif
  void
  aspen_i128zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    int128 *x = (int128 *)(uintptr_t)(*devPtrx);

    ASPEN_I128ZERO( x, *n );
  }

  void
  aspen_i64zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    int64 *x = (int64 *)(uintptr_t)(*devPtrx);

    ASPEN_I64ZERO( x, *n );
  }

  void
  aspen_i32zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    int32 *x = (int32 *)(uintptr_t)(*devPtrx);

    ASPEN_I32ZERO( x, *n );
  }

  void
  aspen_i16zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                )
  {
    int16 *x = (int16 *)(uintptr_t)(*devPtrx);

    ASPEN_I16ZERO( x, *n );
  }

}


#ifndef I128SYMVL_AUTO2_H_INCLUDED
#define I128SYMVL_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for I128SYMVL
 Sat Jul 23 01:28:46  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4068 ) {
	BLK = 0;
} else
if ( n >= 4068 && n < 4099 ) {
	BLK = 2;
} else
if ( n >= 4099 && n < 4571 ) {
	BLK = 1;
} else
if ( n >= 4571 && n < 4636 ) {
	BLK = 2;
} else
if ( n >= 4636 && n < 4699 ) {
	BLK = 0;
} else
if ( n >= 4699 && n < 20483 ) {
	BLK = 1;
} else
if ( n >= 20483 && n < 20858 ) {
	BLK = 5;
} else
if ( n >= 20858 && n < 22063 ) {
	BLK = 1;
} else
if ( n >= 22063 && n < 23318 ) {
	BLK = 5;
} else
if ( n >= 23318 && n < 26688 ) {
	BLK = 1;
} else
if ( n >= 26688 && n < 27105 ) {
	BLK = 6;
} else
if ( n >= 27105 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 

#endif

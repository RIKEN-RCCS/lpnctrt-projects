#ifndef DSYMVL_AUTO2_H_INCLUDED
#define DSYMVL_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for DSYMVL
 Fri Jul 22 08:08:37  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4199 ) {
	BLK = 0;
} else
if ( n >= 4199 && n < 4686 ) {
	BLK = 1;
} else
if ( n >= 4686 && n < 4754 ) {
	BLK = 2;
} else
if ( n >= 4754 && n < 4760 ) {
	BLK = 0;
} else
if ( n >= 4760 && n < 13606 ) {
	BLK = 1;
} else
if ( n >= 13606 && n < 13976 ) {
	BLK = 2;
} else
if ( n >= 13976 && n < 16186 ) {
	BLK = 1;
} else
if ( n >= 16186 && n < 16603 ) {
	BLK = 2;
} else
if ( n >= 16603 && n < 16759 ) {
	BLK = 5;
} else
if ( n >= 16759 && n < 17733 ) {
	BLK = 1;
} else
if ( n >= 17733 && n < 18297 ) {
	BLK = 2;
} else
if ( n >= 18297 && n < 20685 ) {
	BLK = 1;
} else
if ( n >= 20685 && n < 21893 ) {
	BLK = 2;
} else
if ( n >= 21893 && n < 25147 ) {
	BLK = 1;
} else
if ( n >= 25147 && n < 26696 ) {
	BLK = 5;
} else
if ( n >= 26696 && n < 33919 ) {
	BLK = 1;
} else
if ( n >= 33919 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 

#endif

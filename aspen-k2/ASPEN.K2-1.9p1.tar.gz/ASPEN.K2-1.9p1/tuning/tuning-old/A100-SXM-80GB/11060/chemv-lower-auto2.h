#ifndef CHEMVL_AUTO2_H_INCLUDED
#define CHEMVL_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for CHEMVL
 Sun Jul 24 11:38:26  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_4	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4109 ) {
	BLK = 0;
} else
if ( n >= 4109 && n < 11234 ) {
	BLK = 1;
} else
if ( n >= 11234 && n < 11432 ) {
	BLK = 5;
} else
if ( n >= 11432 && n < 11710 ) {
	BLK = 4;
} else
if ( n >= 11710 && n < 12709 ) {
	BLK = 1;
} else
if ( n >= 12709 && n < 38087 ) {
	BLK = 4;
} else
if ( n >= 38087 && n < 42155 ) {
	BLK = 1;
} else
if ( n >= 42155 && n < 51683 ) {
	BLK = 4;
} else
if ( n >= 51683 && n < 2147483647 ) {
	BLK = 1;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 1;
} 

#endif

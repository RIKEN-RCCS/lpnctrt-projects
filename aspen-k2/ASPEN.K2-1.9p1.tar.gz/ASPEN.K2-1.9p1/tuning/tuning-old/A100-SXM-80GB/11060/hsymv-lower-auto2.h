#ifndef HSYMVL_AUTO2_H_INCLUDED
#define HSYMVL_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for HSYMVL
 Fri Jul 22 20:49:12  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 6423 ) {
	BLK = 0;
} else
if ( n >= 6423 && n < 6530 ) {
	BLK = 1;
} else
if ( n >= 6530 && n < 7258 ) {
	BLK = 2;
} else
if ( n >= 7258 && n < 7559 ) {
	BLK = 0;
} else
if ( n >= 7559 && n < 7694 ) {
	BLK = 1;
} else
if ( n >= 7694 && n < 8018 ) {
	BLK = 2;
} else
if ( n >= 8018 && n < 8102 ) {
	BLK = 1;
} else
if ( n >= 8102 && n < 8168 ) {
	BLK = 5;
} else
if ( n >= 8168 && n < 9170 ) {
	BLK = 2;
} else
if ( n >= 9170 && n < 9465 ) {
	BLK = 1;
} else
if ( n >= 9465 && n < 21654 ) {
	BLK = 2;
} else
if ( n >= 21654 && n < 22270 ) {
	BLK = 1;
} else
if ( n >= 22270 && n < 71679 ) {
	BLK = 2;
} else
if ( n >= 71679 && n < 94704 ) {
	BLK = 1;
} else
if ( n >= 94704 && n < 97636 ) {
	BLK = 2;
} else
if ( n >= 97636 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 

#endif

#ifndef DSYMVU_AUTO2_H_INCLUDED
#define DSYMVU_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for DSYMVU
 Fri Jul 22 05:09:16  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_4	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4193 ) {
	BLK = 0;
} else
if ( n >= 4193 && n < 4887 ) {
	BLK = 1;
} else
if ( n >= 4887 && n < 4941 ) {
	BLK = 0;
} else
if ( n >= 4941 && n < 4985 ) {
	BLK = 4;
} else
if ( n >= 4985 && n < 7348 ) {
	BLK = 1;
} else
if ( n >= 7348 && n < 7691 ) {
	BLK = 6;
} else
if ( n >= 7691 && n < 7710 ) {
	BLK = 4;
} else
if ( n >= 7710 && n < 10956 ) {
	BLK = 1;
} else
if ( n >= 10956 && n < 11325 ) {
	BLK = 6;
} else
if ( n >= 11325 && n < 13485 ) {
	BLK = 1;
} else
if ( n >= 13485 && n < 13819 ) {
	BLK = 6;
} else
if ( n >= 13819 && n < 14330 ) {
	BLK = 1;
} else
if ( n >= 14330 && n < 14740 ) {
	BLK = 6;
} else
if ( n >= 14740 && n < 16515 ) {
	BLK = 1;
} else
if ( n >= 16515 && n < 17063 ) {
	BLK = 6;
} else
if ( n >= 17063 && n < 17754 ) {
	BLK = 1;
} else
if ( n >= 17754 && n < 18393 ) {
	BLK = 5;
} else
if ( n >= 18393 && n < 18637 ) {
	BLK = 6;
} else
if ( n >= 18637 && n < 19732 ) {
	BLK = 1;
} else
if ( n >= 19732 && n < 20442 ) {
	BLK = 5;
} else
if ( n >= 20442 && n < 20667 ) {
	BLK = 6;
} else
if ( n >= 20667 && n < 23749 ) {
	BLK = 1;
} else
if ( n >= 23749 && n < 27768 ) {
	BLK = 5;
} else
if ( n >= 27768 && n < 28426 ) {
	BLK = 1;
} else
if ( n >= 28426 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 

#endif

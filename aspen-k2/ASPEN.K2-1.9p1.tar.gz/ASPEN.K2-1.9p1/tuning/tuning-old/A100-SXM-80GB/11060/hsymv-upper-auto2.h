#ifndef HSYMVU_AUTO2_H_INCLUDED
#define HSYMVU_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for HSYMVU
 Fri Jul 22 18:04:09  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_4	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 7070 ) {
	BLK = 0;
} else
if ( n >= 7070 && n < 7119 ) {
	BLK = 4;
} else
if ( n >= 7119 && n < 7135 ) {
	BLK = 2;
} else
if ( n >= 7135 && n < 7265 ) {
	BLK = 1;
} else
if ( n >= 7265 && n < 7796 ) {
	BLK = 0;
} else
if ( n >= 7796 && n < 7862 ) {
	BLK = 4;
} else
if ( n >= 7862 && n < 8080 ) {
	BLK = 1;
} else
if ( n >= 8080 && n < 8186 ) {
	BLK = 5;
} else
if ( n >= 8186 && n < 8302 ) {
	BLK = 4;
} else
if ( n >= 8302 && n < 8589 ) {
	BLK = 1;
} else
if ( n >= 8589 && n < 8711 ) {
	BLK = 4;
} else
if ( n >= 8711 && n < 9919 ) {
	BLK = 5;
} else
if ( n >= 9919 && n < 10251 ) {
	BLK = 1;
} else
if ( n >= 10251 && n < 10396 ) {
	BLK = 4;
} else
if ( n >= 10396 && n < 10532 ) {
	BLK = 5;
} else
if ( n >= 10532 && n < 13799 ) {
	BLK = 1;
} else
if ( n >= 13799 && n < 14453 ) {
	BLK = 5;
} else
if ( n >= 14453 && n < 15022 ) {
	BLK = 1;
} else
if ( n >= 15022 && n < 15945 ) {
	BLK = 5;
} else
if ( n >= 15945 && n < 21373 ) {
	BLK = 1;
} else
if ( n >= 21373 && n < 22727 ) {
	BLK = 5;
} else
if ( n >= 22727 && n < 25382 ) {
	BLK = 1;
} else
if ( n >= 25382 && n < 27068 ) {
	BLK = 5;
} else
if ( n >= 27068 && n < 2147483647 ) {
	BLK = 1;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 1;
} 

#endif

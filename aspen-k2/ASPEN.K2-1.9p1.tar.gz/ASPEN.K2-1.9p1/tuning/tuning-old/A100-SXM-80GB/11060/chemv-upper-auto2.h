#ifndef CHEMVU_AUTO2_H_INCLUDED
#define CHEMVU_AUTO2_H_INCLUDED    1

#if 0
<--/****************************************
 Automatic Performance Tuning for CHEMVU
 Sun Jul 24 08:47:23  2022
 Host on a100-0.cloud.r-ccs.riken.jp
 Device is A100-SXM4-80GB
****************************************/-->
// device name
DEVICE= A100-SXM4-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85042737152
// capacity of the work area reserved on the GPU
WORK= 1167360
// for double or cuFloatComplex or int64
MAXDIM= 97948
// for float or cuHalfComplex or int32
MAXDIM2= 138519
// for cuDoubleComplex or DD or int128
MAXDIM3= 69259
// for DD-Complex
MAXDIM4= 48974
// for half or int16
MAXDIM5= 195896
// cuda version
CUDA= 11070
// ASPEN.K2 version
ASPEN_K2= 1.9p1 Mariko
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_3	1
#define	KERNEL_4	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 32 ) {
	BLK = 4;
} else
if ( n >= 32 && n < 4215 ) {
	BLK = 0;
} else
if ( n >= 4215 && n < 4875 ) {
	BLK = 2;
} else
if ( n >= 4875 && n < 5235 ) {
	BLK = 5;
} else
if ( n >= 5235 && n < 6620 ) {
	BLK = 1;
} else
if ( n >= 6620 && n < 6828 ) {
	BLK = 3;
} else
if ( n >= 6828 && n < 6899 ) {
	BLK = 5;
} else
if ( n >= 6899 && n < 7060 ) {
	BLK = 1;
} else
if ( n >= 7060 && n < 7179 ) {
	BLK = 2;
} else
if ( n >= 7179 && n < 7210 ) {
	BLK = 3;
} else
if ( n >= 7210 && n < 7572 ) {
	BLK = 5;
} else
if ( n >= 7572 && n < 8489 ) {
	BLK = 3;
} else
if ( n >= 8489 && n < 8802 ) {
	BLK = 2;
} else
if ( n >= 8802 && n < 9169 ) {
	BLK = 3;
} else
if ( n >= 9169 && n < 9299 ) {
	BLK = 1;
} else
if ( n >= 9299 && n < 9553 ) {
	BLK = 2;
} else
if ( n >= 9553 && n < 10926 ) {
	BLK = 3;
} else
if ( n >= 10926 && n < 11335 ) {
	BLK = 6;
} else
if ( n >= 11335 && n < 28707 ) {
	BLK = 3;
} else
if ( n >= 28707 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 

#endif

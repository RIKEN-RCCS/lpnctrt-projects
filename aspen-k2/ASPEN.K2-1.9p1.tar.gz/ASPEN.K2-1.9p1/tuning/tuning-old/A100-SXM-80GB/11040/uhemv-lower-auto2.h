#ifndef UHEMV_LOWER_AUTO2_H_INCLUDED
#define UHEMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for UHEMV-L
Sun Mar 20 17:36:51 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_3	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4672 ) {
	BLK = 0;
} else
if ( n >= 4672 && n < 14191 ) {
	BLK = 1;
} else
if ( n >= 14191 && n < 14858 ) {
	BLK = 3;
} else
if ( n >= 14858 && n < 15149 ) {
	BLK = 1;
} else
if ( n >= 15149 && n < 16036 ) {
	BLK = 3;
} else
if ( n >= 16036 && n < 16826 ) {
	BLK = 1;
} else
if ( n >= 16826 && n < 17946 ) {
	BLK = 3;
} else
if ( n >= 17946 && n < 18690 ) {
	BLK = 1;
} else
if ( n >= 18690 && n < 19355 ) {
	BLK = 5;
} else
if ( n >= 19355 && n < 29712 ) {
	BLK = 3;
} else
if ( n >= 29712 && n < 32661 ) {
	BLK = 1;
} else
if ( n >= 32661 && n < 2147483647 ) {
	BLK = 3;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 3;
} 
#endif

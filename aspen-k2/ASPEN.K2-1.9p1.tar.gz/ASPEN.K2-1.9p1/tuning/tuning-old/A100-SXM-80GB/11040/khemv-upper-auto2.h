#ifndef KHEMV_UPPER_AUTO2_H_INCLUDED
#define KHEMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for KHEMV-U
Mon Mar 21 07:59:51 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_3	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 6190 ) {
	BLK = 0;
} else
if ( n >= 6190 && n < 8838 ) {
	BLK = 1;
} else
if ( n >= 8838 && n < 9130 ) {
	BLK = 3;
} else
if ( n >= 9130 && n < 14968 ) {
	BLK = 1;
} else
if ( n >= 14968 && n < 15509 ) {
	BLK = 5;
} else
if ( n >= 15509 && n < 16319 ) {
	BLK = 1;
} else
if ( n >= 16319 && n < 17251 ) {
	BLK = 5;
} else
if ( n >= 17251 && n < 17956 ) {
	BLK = 1;
} else
if ( n >= 17956 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

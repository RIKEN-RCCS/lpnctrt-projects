#ifndef I32SYMV_UPPER_AUTO2_H_INCLUDED
#define I32SYMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for I32SYMV-U
Sun Mar 20 04:09:58 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_4	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 5299 ) {
	BLK = 0;
} else
if ( n >= 5299 && n < 8948 ) {
	BLK = 1;
} else
if ( n >= 8948 && n < 9254 ) {
	BLK = 4;
} else
if ( n >= 9254 && n < 10885 ) {
	BLK = 1;
} else
if ( n >= 10885 && n < 11389 ) {
	BLK = 5;
} else
if ( n >= 11389 && n < 11874 ) {
	BLK = 1;
} else
if ( n >= 11874 && n < 21375 ) {
	BLK = 5;
} else
if ( n >= 21375 && n < 22791 ) {
	BLK = 6;
} else
if ( n >= 22791 && n < 24392 ) {
	BLK = 5;
} else
if ( n >= 24392 && n < 25575 ) {
	BLK = 6;
} else
if ( n >= 25575 && n < 28558 ) {
	BLK = 5;
} else
if ( n >= 28558 && n < 29339 ) {
	BLK = 6;
} else
if ( n >= 29339 && n < 35493 ) {
	BLK = 5;
} else
if ( n >= 35493 && n < 43860 ) {
	BLK = 6;
} else
if ( n >= 43860 && n < 49459 ) {
	BLK = 5;
} else
if ( n >= 49459 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 
#endif

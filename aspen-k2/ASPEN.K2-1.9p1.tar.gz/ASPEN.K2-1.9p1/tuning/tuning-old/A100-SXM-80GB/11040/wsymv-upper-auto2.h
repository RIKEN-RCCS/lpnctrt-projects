#ifndef WSYMV_UPPER_AUTO2_H_INCLUDED
#define WSYMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for WSYMV-U
Fri Mar 18 17:39:09 JST 2022
Host on a100-1.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4254 ) {
	BLK = 0;
} else
if ( n >= 4254 && n < 4315 ) {
	BLK = 1;
} else
if ( n >= 4315 && n < 4509 ) {
	BLK = 2;
} else
if ( n >= 4509 && n < 4791 ) {
	BLK = 0;
} else
if ( n >= 4791 && n < 4821 ) {
	BLK = 2;
} else
if ( n >= 4821 && n < 6051 ) {
	BLK = 1;
} else
if ( n >= 6051 && n < 6145 ) {
	BLK = 0;
} else
if ( n >= 6145 && n < 6287 ) {
	BLK = 2;
} else
if ( n >= 6287 && n < 7626 ) {
	BLK = 1;
} else
if ( n >= 7626 && n < 9043 ) {
	BLK = 2;
} else
if ( n >= 9043 && n < 9455 ) {
	BLK = 1;
} else
if ( n >= 9455 && n < 9594 ) {
	BLK = 2;
} else
if ( n >= 9594 && n < 9779 ) {
	BLK = 6;
} else
if ( n >= 9779 && n < 12478 ) {
	BLK = 1;
} else
if ( n >= 12478 && n < 12510 ) {
	BLK = 2;
} else
if ( n >= 12510 && n < 13186 ) {
	BLK = 6;
} else
if ( n >= 13186 && n < 14591 ) {
	BLK = 1;
} else
if ( n >= 14591 && n < 15392 ) {
	BLK = 6;
} else
if ( n >= 15392 && n < 16744 ) {
	BLK = 1;
} else
if ( n >= 16744 && n < 17099 ) {
	BLK = 6;
} else
if ( n >= 17099 && n < 17304 ) {
	BLK = 2;
} else
if ( n >= 17304 && n < 18290 ) {
	BLK = 1;
} else
if ( n >= 18290 && n < 19304 ) {
	BLK = 6;
} else
if ( n >= 19304 && n < 20581 ) {
	BLK = 1;
} else
if ( n >= 20581 && n < 21626 ) {
	BLK = 6;
} else
if ( n >= 21626 && n < 22609 ) {
	BLK = 1;
} else
if ( n >= 22609 && n < 23686 ) {
	BLK = 6;
} else
if ( n >= 23686 && n < 24284 ) {
	BLK = 1;
} else
if ( n >= 24284 && n < 28944 ) {
	BLK = 6;
} else
if ( n >= 28944 && n < 31250 ) {
	BLK = 1;
} else
if ( n >= 31250 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 
#endif

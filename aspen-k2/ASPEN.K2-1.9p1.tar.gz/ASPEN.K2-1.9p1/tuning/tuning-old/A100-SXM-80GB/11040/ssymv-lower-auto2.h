#ifndef SSYMV_LOWER_AUTO2_H_INCLUDED
#define SSYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for SSYMV-L
Sat Mar 19 07:55:08 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_4	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 6041 ) {
	BLK = 0;
} else
if ( n >= 6041 && n < 8956 ) {
	BLK = 1;
} else
if ( n >= 8956 && n < 9382 ) {
	BLK = 5;
} else
if ( n >= 9382 && n < 9548 ) {
	BLK = 1;
} else
if ( n >= 9548 && n < 10472 ) {
	BLK = 4;
} else
if ( n >= 10472 && n < 11347 ) {
	BLK = 1;
} else
if ( n >= 11347 && n < 11727 ) {
	BLK = 5;
} else
if ( n >= 11727 && n < 12004 ) {
	BLK = 1;
} else
if ( n >= 12004 && n < 13104 ) {
	BLK = 5;
} else
if ( n >= 13104 && n < 13572 ) {
	BLK = 4;
} else
if ( n >= 13572 && n < 14248 ) {
	BLK = 5;
} else
if ( n >= 14248 && n < 14670 ) {
	BLK = 1;
} else
if ( n >= 14670 && n < 14790 ) {
	BLK = 5;
} else
if ( n >= 14790 && n < 15361 ) {
	BLK = 4;
} else
if ( n >= 15361 && n < 16243 ) {
	BLK = 5;
} else
if ( n >= 16243 && n < 17392 ) {
	BLK = 4;
} else
if ( n >= 17392 && n < 17943 ) {
	BLK = 5;
} else
if ( n >= 17943 && n < 18699 ) {
	BLK = 4;
} else
if ( n >= 18699 && n < 19173 ) {
	BLK = 5;
} else
if ( n >= 19173 && n < 21717 ) {
	BLK = 4;
} else
if ( n >= 21717 && n < 22920 ) {
	BLK = 5;
} else
if ( n >= 22920 && n < 24499 ) {
	BLK = 4;
} else
if ( n >= 24499 && n < 26016 ) {
	BLK = 5;
} else
if ( n >= 26016 && n < 2147483647 ) {
	BLK = 4;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 4;
} 
#endif

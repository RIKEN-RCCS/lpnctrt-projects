#ifndef HSYMV_UPPER_AUTO2_H_INCLUDED
#define HSYMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for HSYMV-U
Sat Mar 19 11:05:58 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 7873 ) {
	BLK = 0;
} else
if ( n >= 7873 && n < 8555 ) {
	BLK = 1;
} else
if ( n >= 8555 && n < 8807 ) {
	BLK = 5;
} else
if ( n >= 8807 && n < 9158 ) {
	BLK = 0;
} else
if ( n >= 9158 && n < 9255 ) {
	BLK = 5;
} else
if ( n >= 9255 && n < 10203 ) {
	BLK = 1;
} else
if ( n >= 10203 && n < 10741 ) {
	BLK = 6;
} else
if ( n >= 10741 && n < 11734 ) {
	BLK = 1;
} else
if ( n >= 11734 && n < 11808 ) {
	BLK = 5;
} else
if ( n >= 11808 && n < 12469 ) {
	BLK = 6;
} else
if ( n >= 12469 && n < 13346 ) {
	BLK = 1;
} else
if ( n >= 13346 && n < 13592 ) {
	BLK = 6;
} else
if ( n >= 13592 && n < 14672 ) {
	BLK = 5;
} else
if ( n >= 14672 && n < 15751 ) {
	BLK = 6;
} else
if ( n >= 15751 && n < 16244 ) {
	BLK = 5;
} else
if ( n >= 16244 && n < 19655 ) {
	BLK = 6;
} else
if ( n >= 19655 && n < 21133 ) {
	BLK = 5;
} else
if ( n >= 21133 && n < 21514 ) {
	BLK = 6;
} else
if ( n >= 21514 && n < 22801 ) {
	BLK = 5;
} else
if ( n >= 22801 && n < 24799 ) {
	BLK = 6;
} else
if ( n >= 24799 && n < 27562 ) {
	BLK = 5;
} else
if ( n >= 27562 && n < 28480 ) {
	BLK = 6;
} else
if ( n >= 28480 && n < 30676 ) {
	BLK = 5;
} else
if ( n >= 30676 && n < 31300 ) {
	BLK = 6;
} else
if ( n >= 31300 && n < 36880 ) {
	BLK = 5;
} else
if ( n >= 36880 && n < 37322 ) {
	BLK = 6;
} else
if ( n >= 37322 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

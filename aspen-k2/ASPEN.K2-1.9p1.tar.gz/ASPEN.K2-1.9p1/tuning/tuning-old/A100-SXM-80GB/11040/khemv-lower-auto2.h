#ifndef KHEMV_LOWER_AUTO2_H_INCLUDED
#define KHEMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for KHEMV-L
Mon Mar 21 11:35:35 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_4	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 20 ) {
	BLK = 2;
} else
if ( n >= 20 && n < 6190 ) {
	BLK = 0;
} else
if ( n >= 6190 && n < 6346 ) {
	BLK = 4;
} else
if ( n >= 6346 && n < 12508 ) {
	BLK = 1;
} else
if ( n >= 12508 && n < 12805 ) {
	BLK = 4;
} else
if ( n >= 12805 && n < 13274 ) {
	BLK = 1;
} else
if ( n >= 13274 && n < 13727 ) {
	BLK = 5;
} else
if ( n >= 13727 && n < 14157 ) {
	BLK = 4;
} else
if ( n >= 14157 && n < 14721 ) {
	BLK = 1;
} else
if ( n >= 14721 && n < 15306 ) {
	BLK = 4;
} else
if ( n >= 15306 && n < 15855 ) {
	BLK = 1;
} else
if ( n >= 15855 && n < 16467 ) {
	BLK = 4;
} else
if ( n >= 16467 && n < 17245 ) {
	BLK = 5;
} else
if ( n >= 17245 && n < 17695 ) {
	BLK = 1;
} else
if ( n >= 17695 && n < 18133 ) {
	BLK = 4;
} else
if ( n >= 18133 && n < 18747 ) {
	BLK = 5;
} else
if ( n >= 18747 && n < 18841 ) {
	BLK = 6;
} else
if ( n >= 18841 && n < 19838 ) {
	BLK = 4;
} else
if ( n >= 19838 && n < 22542 ) {
	BLK = 5;
} else
if ( n >= 22542 && n < 22795 ) {
	BLK = 6;
} else
if ( n >= 22795 && n < 23572 ) {
	BLK = 4;
} else
if ( n >= 23572 && n < 25527 ) {
	BLK = 5;
} else
if ( n >= 25527 && n < 26505 ) {
	BLK = 6;
} else
if ( n >= 26505 && n < 27167 ) {
	BLK = 4;
} else
if ( n >= 27167 && n < 29700 ) {
	BLK = 5;
} else
if ( n >= 29700 && n < 35929 ) {
	BLK = 6;
} else
if ( n >= 35929 && n < 38744 ) {
	BLK = 5;
} else
if ( n >= 38744 && n < 40830 ) {
	BLK = 6;
} else
if ( n >= 40830 && n < 45964 ) {
	BLK = 5;
} else
if ( n >= 45964 && n < 60480 ) {
	BLK = 6;
} else
if ( n >= 60480 && n < 66622 ) {
	BLK = 5;
} else
if ( n >= 66622 && n < 69476 ) {
	BLK = 6;
} else
if ( n >= 69476 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

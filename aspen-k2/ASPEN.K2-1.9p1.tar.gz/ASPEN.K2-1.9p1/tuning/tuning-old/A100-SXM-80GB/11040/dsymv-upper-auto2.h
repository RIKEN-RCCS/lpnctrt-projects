#ifndef DSYMV_UPPER_AUTO2_H_INCLUDED
#define DSYMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for DSYMV-U
Fri Mar 18 22:57:50 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_3	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 3599 ) {
	BLK = 0;
} else
if ( n >= 3599 && n < 3635 ) {
	BLK = 2;
} else
if ( n >= 3635 && n < 3666 ) {
	BLK = 6;
} else
if ( n >= 3666 && n < 3668 ) {
	BLK = 3;
} else
if ( n >= 3668 && n < 3845 ) {
	BLK = 0;
} else
if ( n >= 3845 && n < 3904 ) {
	BLK = 2;
} else
if ( n >= 3904 && n < 3929 ) {
	BLK = 1;
} else
if ( n >= 3929 && n < 4198 ) {
	BLK = 0;
} else
if ( n >= 4198 && n < 4210 ) {
	BLK = 6;
} else
if ( n >= 4210 && n < 4446 ) {
	BLK = 2;
} else
if ( n >= 4446 && n < 4889 ) {
	BLK = 1;
} else
if ( n >= 4889 && n < 4952 ) {
	BLK = 6;
} else
if ( n >= 4952 && n < 5026 ) {
	BLK = 2;
} else
if ( n >= 5026 && n < 5096 ) {
	BLK = 1;
} else
if ( n >= 5096 && n < 5382 ) {
	BLK = 6;
} else
if ( n >= 5382 && n < 5821 ) {
	BLK = 2;
} else
if ( n >= 5821 && n < 6132 ) {
	BLK = 6;
} else
if ( n >= 6132 && n < 6254 ) {
	BLK = 1;
} else
if ( n >= 6254 && n < 10979 ) {
	BLK = 2;
} else
if ( n >= 10979 && n < 11315 ) {
	BLK = 6;
} else
if ( n >= 11315 && n < 24748 ) {
	BLK = 2;
} else
if ( n >= 24748 && n < 25482 ) {
	BLK = 6;
} else
if ( n >= 25482 && n < 28197 ) {
	BLK = 2;
} else
if ( n >= 28197 && n < 28298 ) {
	BLK = 6;
} else
if ( n >= 28298 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

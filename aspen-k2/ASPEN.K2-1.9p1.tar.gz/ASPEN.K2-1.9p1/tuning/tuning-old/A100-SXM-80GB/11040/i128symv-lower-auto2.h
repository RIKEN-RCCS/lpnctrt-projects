#ifndef I128SYMV_LOWER_AUTO2_H_INCLUDED
#define I128SYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for I128SYMV-L
Sat Mar 19 19:16:17 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_3	1
#define	KERNEL_4	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4059 ) {
	BLK = 0;
} else
if ( n >= 4059 && n < 4079 ) {
	BLK = 4;
} else
if ( n >= 4079 && n < 8144 ) {
	BLK = 1;
} else
if ( n >= 8144 && n < 8427 ) {
	BLK = 4;
} else
if ( n >= 8427 && n < 11014 ) {
	BLK = 1;
} else
if ( n >= 11014 && n < 16279 ) {
	BLK = 3;
} else
if ( n >= 16279 && n < 17234 ) {
	BLK = 1;
} else
if ( n >= 17234 && n < 18090 ) {
	BLK = 3;
} else
if ( n >= 18090 && n < 18907 ) {
	BLK = 1;
} else
if ( n >= 18907 && n < 19455 ) {
	BLK = 3;
} else
if ( n >= 19455 && n < 20570 ) {
	BLK = 1;
} else
if ( n >= 20570 && n < 2147483647 ) {
	BLK = 3;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 3;
} 
#endif

#ifndef SSYMV_UPPER_AUTO2_H_INCLUDED
#define SSYMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for SSYMV-U
Sat Mar 19 05:06:47 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_4	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 5307 ) {
	BLK = 0;
} else
if ( n >= 5307 && n < 5406 ) {
	BLK = 6;
} else
if ( n >= 5406 && n < 9225 ) {
	BLK = 1;
} else
if ( n >= 9225 && n < 9542 ) {
	BLK = 4;
} else
if ( n >= 9542 && n < 9739 ) {
	BLK = 6;
} else
if ( n >= 9739 && n < 12241 ) {
	BLK = 1;
} else
if ( n >= 12241 && n < 12583 ) {
	BLK = 4;
} else
if ( n >= 12583 && n < 12868 ) {
	BLK = 1;
} else
if ( n >= 12868 && n < 13211 ) {
	BLK = 4;
} else
if ( n >= 13211 && n < 14071 ) {
	BLK = 1;
} else
if ( n >= 14071 && n < 21596 ) {
	BLK = 4;
} else
if ( n >= 21596 && n < 22472 ) {
	BLK = 1;
} else
if ( n >= 22472 && n < 24552 ) {
	BLK = 4;
} else
if ( n >= 24552 && n < 25671 ) {
	BLK = 5;
} else
if ( n >= 25671 && n < 2147483647 ) {
	BLK = 4;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 4;
} 
#endif

#if defined(PRESERVE_DROP)
#undef	PRESERVE_DROP
#endif
#define	PRESERVE_DROP	1

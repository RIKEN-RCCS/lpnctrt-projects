#ifndef DSYMV_LOWER_AUTO2_H_INCLUDED
#define DSYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for DSYMV-L
Sat Mar 19 01:47:52 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_3	1
#define	KERNEL_4	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 23 ) {
	BLK = 4;
} else
if ( n >= 23 && n < 4146 ) {
	BLK = 0;
} else
if ( n >= 4146 && n < 6275 ) {
	BLK = 1;
} else
if ( n >= 6275 && n < 7226 ) {
	BLK = 3;
} else
if ( n >= 7226 && n < 7572 ) {
	BLK = 1;
} else
if ( n >= 7572 && n < 8090 ) {
	BLK = 3;
} else
if ( n >= 8090 && n < 8417 ) {
	BLK = 1;
} else
if ( n >= 8417 && n < 8803 ) {
	BLK = 3;
} else
if ( n >= 8803 && n < 9138 ) {
	BLK = 1;
} else
if ( n >= 9138 && n < 9561 ) {
	BLK = 3;
} else
if ( n >= 9561 && n < 10361 ) {
	BLK = 1;
} else
if ( n >= 10361 && n < 11230 ) {
	BLK = 3;
} else
if ( n >= 11230 && n < 11674 ) {
	BLK = 1;
} else
if ( n >= 11674 && n < 18507 ) {
	BLK = 3;
} else
if ( n >= 18507 && n < 19628 ) {
	BLK = 1;
} else
if ( n >= 19628 && n < 28792 ) {
	BLK = 3;
} else
if ( n >= 28792 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 
#endif

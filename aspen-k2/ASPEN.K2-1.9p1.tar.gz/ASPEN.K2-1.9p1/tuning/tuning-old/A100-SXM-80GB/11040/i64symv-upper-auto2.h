#ifndef I64SYMV_UPPER_AUTO2_H_INCLUDED
#define I64SYMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for I64SYMV-U
Sat Mar 19 22:02:30 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_3	1
#define	KERNEL_4	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 12 ) {
	BLK = 6;
} else
if ( n >= 12 && n < 3607 ) {
	BLK = 0;
} else
if ( n >= 3607 && n < 3631 ) {
	BLK = 3;
} else
if ( n >= 3631 && n < 3661 ) {
	BLK = 4;
} else
if ( n >= 3661 && n < 3911 ) {
	BLK = 1;
} else
if ( n >= 3911 && n < 4242 ) {
	BLK = 0;
} else
if ( n >= 4242 && n < 4306 ) {
	BLK = 3;
} else
if ( n >= 4306 && n < 4334 ) {
	BLK = 4;
} else
if ( n >= 4334 && n < 4443 ) {
	BLK = 1;
} else
if ( n >= 4443 && n < 4509 ) {
	BLK = 0;
} else
if ( n >= 4509 && n < 4640 ) {
	BLK = 3;
} else
if ( n >= 4640 && n < 4649 ) {
	BLK = 1;
} else
if ( n >= 4649 && n < 4746 ) {
	BLK = 2;
} else
if ( n >= 4746 && n < 4913 ) {
	BLK = 3;
} else
if ( n >= 4913 && n < 4914 ) {
	BLK = 0;
} else
if ( n >= 4914 && n < 4938 ) {
	BLK = 1;
} else
if ( n >= 4938 && n < 5077 ) {
	BLK = 2;
} else
if ( n >= 5077 && n < 8627 ) {
	BLK = 3;
} else
if ( n >= 8627 && n < 8910 ) {
	BLK = 4;
} else
if ( n >= 8910 && n < 16738 ) {
	BLK = 3;
} else
if ( n >= 16738 && n < 17462 ) {
	BLK = 4;
} else
if ( n >= 17462 && n < 19516 ) {
	BLK = 3;
} else
if ( n >= 19516 && n < 20084 ) {
	BLK = 6;
} else
if ( n >= 20084 && n < 24078 ) {
	BLK = 3;
} else
if ( n >= 24078 && n < 25450 ) {
	BLK = 6;
} else
if ( n >= 25450 && n < 36439 ) {
	BLK = 3;
} else
if ( n >= 36439 && n < 38422 ) {
	BLK = 6;
} else
if ( n >= 38422 && n < 44258 ) {
	BLK = 3;
} else
if ( n >= 44258 && n < 45460 ) {
	BLK = 6;
} else
if ( n >= 45460 && n < 2147483647 ) {
	BLK = 3;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 3;
} 
#endif

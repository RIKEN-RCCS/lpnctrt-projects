#ifndef ZHEMV_UPPER_AUTO2_H_INCLUDED
#define ZHEMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for ZHEMV-U
Sun Mar 20 20:06:23 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_4	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 3509 ) {
	BLK = 0;
} else
if ( n >= 3509 && n < 3560 ) {
	BLK = 2;
} else
if ( n >= 3560 && n < 3773 ) {
	BLK = 1;
} else
if ( n >= 3773 && n < 3784 ) {
	BLK = 0;
} else
if ( n >= 3784 && n < 4673 ) {
	BLK = 2;
} else
if ( n >= 4673 && n < 8595 ) {
	BLK = 1;
} else
if ( n >= 8595 && n < 8864 ) {
	BLK = 2;
} else
if ( n >= 8864 && n < 13721 ) {
	BLK = 1;
} else
if ( n >= 13721 && n < 14259 ) {
	BLK = 2;
} else
if ( n >= 14259 && n < 14613 ) {
	BLK = 1;
} else
if ( n >= 14613 && n < 14856 ) {
	BLK = 2;
} else
if ( n >= 14856 && n < 15251 ) {
	BLK = 4;
} else
if ( n >= 15251 && n < 15926 ) {
	BLK = 1;
} else
if ( n >= 15926 && n < 59854 ) {
	BLK = 4;
} else
if ( n >= 59854 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

#ifndef ZHEMV_LOWER_AUTO2_H_INCLUDED
#define ZHEMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for ZHEMV-L
Sun Mar 20 22:22:41 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_4	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 3737 ) {
	BLK = 0;
} else
if ( n >= 3737 && n < 12656 ) {
	BLK = 1;
} else
if ( n >= 12656 && n < 13307 ) {
	BLK = 4;
} else
if ( n >= 13307 && n < 15014 ) {
	BLK = 1;
} else
if ( n >= 15014 && n < 16077 ) {
	BLK = 4;
} else
if ( n >= 16077 && n < 17308 ) {
	BLK = 1;
} else
if ( n >= 17308 && n < 18093 ) {
	BLK = 4;
} else
if ( n >= 18093 && n < 20413 ) {
	BLK = 1;
} else
if ( n >= 20413 && n < 2147483647 ) {
	BLK = 4;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 4;
} 
#endif

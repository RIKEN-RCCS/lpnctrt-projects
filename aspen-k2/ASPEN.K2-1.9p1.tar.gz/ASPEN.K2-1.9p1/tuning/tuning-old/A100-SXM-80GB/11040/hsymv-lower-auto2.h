#ifndef HSYMV_LOWER_AUTO2_H_INCLUDED
#define HSYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for HSYMV-L
Sat Mar 19 14:16:01 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_3	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 7945 ) {
	BLK = 0;
} else
if ( n >= 7945 && n < 8208 ) {
	BLK = 1;
} else
if ( n >= 8208 && n < 8374 ) {
	BLK = 0;
} else
if ( n >= 8374 && n < 8469 ) {
	BLK = 3;
} else
if ( n >= 8469 && n < 8855 ) {
	BLK = 1;
} else
if ( n >= 8855 && n < 9054 ) {
	BLK = 0;
} else
if ( n >= 9054 && n < 9192 ) {
	BLK = 3;
} else
if ( n >= 9192 && n < 10226 ) {
	BLK = 1;
} else
if ( n >= 10226 && n < 11431 ) {
	BLK = 3;
} else
if ( n >= 11431 && n < 12436 ) {
	BLK = 1;
} else
if ( n >= 12436 && n < 12826 ) {
	BLK = 3;
} else
if ( n >= 12826 && n < 13048 ) {
	BLK = 1;
} else
if ( n >= 13048 && n < 13697 ) {
	BLK = 6;
} else
if ( n >= 13697 && n < 15218 ) {
	BLK = 3;
} else
if ( n >= 15218 && n < 15842 ) {
	BLK = 1;
} else
if ( n >= 15842 && n < 15848 ) {
	BLK = 3;
} else
if ( n >= 15848 && n < 17250 ) {
	BLK = 6;
} else
if ( n >= 17250 && n < 18104 ) {
	BLK = 3;
} else
if ( n >= 18104 && n < 18588 ) {
	BLK = 6;
} else
if ( n >= 18588 && n < 19746 ) {
	BLK = 3;
} else
if ( n >= 19746 && n < 20726 ) {
	BLK = 6;
} else
if ( n >= 20726 && n < 21590 ) {
	BLK = 3;
} else
if ( n >= 21590 && n < 22349 ) {
	BLK = 6;
} else
if ( n >= 22349 && n < 23544 ) {
	BLK = 3;
} else
if ( n >= 23544 && n < 25482 ) {
	BLK = 6;
} else
if ( n >= 25482 && n < 27844 ) {
	BLK = 3;
} else
if ( n >= 27844 && n < 33563 ) {
	BLK = 6;
} else
if ( n >= 33563 && n < 36367 ) {
	BLK = 3;
} else
if ( n >= 36367 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 
#endif

#ifndef CHEMV_UPPER_AUTO2_H_INCLUDED
#define CHEMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for CHEMV-U
Mon Mar 21 01:18:56 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_3	1
#define	KERNEL_4	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 4491 ) {
	BLK = 0;
} else
if ( n >= 4491 && n < 4857 ) {
	BLK = 3;
} else
if ( n >= 4857 && n < 5107 ) {
	BLK = 1;
} else
if ( n >= 5107 && n < 5173 ) {
	BLK = 3;
} else
if ( n >= 5173 && n < 5258 ) {
	BLK = 4;
} else
if ( n >= 5258 && n < 5404 ) {
	BLK = 1;
} else
if ( n >= 5404 && n < 5456 ) {
	BLK = 3;
} else
if ( n >= 5456 && n < 5544 ) {
	BLK = 2;
} else
if ( n >= 5544 && n < 5638 ) {
	BLK = 4;
} else
if ( n >= 5638 && n < 5732 ) {
	BLK = 1;
} else
if ( n >= 5732 && n < 5872 ) {
	BLK = 3;
} else
if ( n >= 5872 && n < 7262 ) {
	BLK = 2;
} else
if ( n >= 7262 && n < 7536 ) {
	BLK = 4;
} else
if ( n >= 7536 && n < 28247 ) {
	BLK = 2;
} else
if ( n >= 28247 && n < 2147483647 ) {
	BLK = 6;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 6;
} 
#endif

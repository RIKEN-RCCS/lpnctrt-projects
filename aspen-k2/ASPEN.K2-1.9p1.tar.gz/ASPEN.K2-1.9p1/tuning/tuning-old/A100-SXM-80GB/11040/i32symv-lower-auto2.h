#ifndef I32SYMV_LOWER_AUTO2_H_INCLUDED
#define I32SYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for I32SYMV-L
Sun Mar 20 07:01:59 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_3	1
#define	KERNEL_4	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 23 ) {
	BLK = 2;
} else
if ( n >= 23 && n < 6118 ) {
	BLK = 0;
} else
if ( n >= 6118 && n < 6733 ) {
	BLK = 1;
} else
if ( n >= 6733 && n < 7309 ) {
	BLK = 3;
} else
if ( n >= 7309 && n < 7340 ) {
	BLK = 5;
} else
if ( n >= 7340 && n < 7608 ) {
	BLK = 1;
} else
if ( n >= 7608 && n < 7755 ) {
	BLK = 4;
} else
if ( n >= 7755 && n < 7792 ) {
	BLK = 3;
} else
if ( n >= 7792 && n < 7817 ) {
	BLK = 1;
} else
if ( n >= 7817 && n < 8172 ) {
	BLK = 5;
} else
if ( n >= 8172 && n < 8211 ) {
	BLK = 1;
} else
if ( n >= 8211 && n < 8408 ) {
	BLK = 3;
} else
if ( n >= 8408 && n < 8921 ) {
	BLK = 5;
} else
if ( n >= 8921 && n < 9351 ) {
	BLK = 3;
} else
if ( n >= 9351 && n < 10491 ) {
	BLK = 4;
} else
if ( n >= 10491 && n < 10915 ) {
	BLK = 1;
} else
if ( n >= 10915 && n < 12804 ) {
	BLK = 5;
} else
if ( n >= 12804 && n < 14079 ) {
	BLK = 4;
} else
if ( n >= 14079 && n < 14851 ) {
	BLK = 5;
} else
if ( n >= 14851 && n < 15254 ) {
	BLK = 4;
} else
if ( n >= 15254 && n < 16067 ) {
	BLK = 5;
} else
if ( n >= 16067 && n < 18648 ) {
	BLK = 4;
} else
if ( n >= 18648 && n < 19273 ) {
	BLK = 5;
} else
if ( n >= 19273 && n < 21362 ) {
	BLK = 4;
} else
if ( n >= 21362 && n < 22621 ) {
	BLK = 6;
} else
if ( n >= 22621 && n < 22832 ) {
	BLK = 5;
} else
if ( n >= 22832 && n < 24563 ) {
	BLK = 4;
} else
if ( n >= 24563 && n < 25945 ) {
	BLK = 5;
} else
if ( n >= 25945 && n < 27140 ) {
	BLK = 6;
} else
if ( n >= 27140 && n < 30057 ) {
	BLK = 4;
} else
if ( n >= 30057 && n < 31690 ) {
	BLK = 5;
} else
if ( n >= 31690 && n < 2147483647 ) {
	BLK = 4;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 4;
} 
#endif

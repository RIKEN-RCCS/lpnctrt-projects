#ifndef I64SYMV_LOWER_AUTO2_H_INCLUDED
#define I64SYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for I64SYMV-L
Sun Mar 20 00:53:13 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_2	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 7 ) {
	BLK = 2;
} else
if ( n >= 7 && n < 4966 ) {
	BLK = 0;
} else
if ( n >= 4966 && n < 5866 ) {
	BLK = 1;
} else
if ( n >= 5866 && n < 9187 ) {
	BLK = 2;
} else
if ( n >= 9187 && n < 9516 ) {
	BLK = 1;
} else
if ( n >= 9516 && n < 15376 ) {
	BLK = 2;
} else
if ( n >= 15376 && n < 15860 ) {
	BLK = 6;
} else
if ( n >= 15860 && n < 23398 ) {
	BLK = 2;
} else
if ( n >= 23398 && n < 23727 ) {
	BLK = 6;
} else
if ( n >= 23727 && n < 24744 ) {
	BLK = 5;
} else
if ( n >= 24744 && n < 24837 ) {
	BLK = 6;
} else
if ( n >= 24837 && n < 25919 ) {
	BLK = 2;
} else
if ( n >= 25919 && n < 26868 ) {
	BLK = 6;
} else
if ( n >= 26868 && n < 29622 ) {
	BLK = 5;
} else
if ( n >= 29622 && n < 31366 ) {
	BLK = 2;
} else
if ( n >= 31366 && n < 33690 ) {
	BLK = 6;
} else
if ( n >= 33690 && n < 34305 ) {
	BLK = 5;
} else
if ( n >= 34305 && n < 38380 ) {
	BLK = 2;
} else
if ( n >= 38380 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

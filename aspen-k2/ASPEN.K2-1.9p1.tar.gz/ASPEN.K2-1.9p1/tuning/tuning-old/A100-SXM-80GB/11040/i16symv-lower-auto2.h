#ifndef I16SYMV_LOWER_AUTO2_H_INCLUDED
#define I16SYMV_LOWER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for I16SYMV-L
Sun Mar 20 13:12:48 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_3	1
#define	KERNEL_5	1
#define	KERNEL_6	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 9388 ) {
	BLK = 0;
} else
if ( n >= 9388 && n < 9717 ) {
	BLK = 3;
} else
if ( n >= 9717 && n < 10110 ) {
	BLK = 6;
} else
if ( n >= 10110 && n < 12640 ) {
	BLK = 3;
} else
if ( n >= 12640 && n < 13500 ) {
	BLK = 6;
} else
if ( n >= 13500 && n < 13893 ) {
	BLK = 5;
} else
if ( n >= 13893 && n < 14603 ) {
	BLK = 3;
} else
if ( n >= 14603 && n < 14900 ) {
	BLK = 5;
} else
if ( n >= 14900 && n < 15237 ) {
	BLK = 6;
} else
if ( n >= 15237 && n < 15930 ) {
	BLK = 3;
} else
if ( n >= 15930 && n < 16105 ) {
	BLK = 5;
} else
if ( n >= 16105 && n < 16615 ) {
	BLK = 6;
} else
if ( n >= 16615 && n < 18834 ) {
	BLK = 5;
} else
if ( n >= 18834 && n < 19172 ) {
	BLK = 6;
} else
if ( n >= 19172 && n < 19927 ) {
	BLK = 5;
} else
if ( n >= 19927 && n < 21055 ) {
	BLK = 6;
} else
if ( n >= 21055 && n < 26640 ) {
	BLK = 5;
} else
if ( n >= 26640 && n < 28823 ) {
	BLK = 6;
} else
if ( n >= 28823 && n < 2147483647 ) {
	BLK = 5;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 5;
} 
#endif

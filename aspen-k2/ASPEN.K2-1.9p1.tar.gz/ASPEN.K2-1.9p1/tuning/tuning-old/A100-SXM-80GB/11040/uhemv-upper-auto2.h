#ifndef UHEMV_UPPER_AUTO2_H_INCLUDED
#define UHEMV_UPPER_AUTO2_H_INCLUDED 1
#if 0
<--/****************************************
Automatic Performance Tuning for UHEMV-U
Sun Mar 20 15:20:15 JST 2022
Host on a100-0.cloud.r-ccs.riken.jp
Device is A100-SXM-80GB
****************************************/-->
// device name
DEVICE= A100-SXM-80GB
// the number of multi-processors
MP= 108
// compute-compatibility generation
CG= 800
// capacity of the global memory or host memory
MAXmem= 85196873728
// capacity of the work area reserved on the GPU
WORK= 1171456
// for double or cuFloatComplex or int64
MAXDIM= 98037
// for float or cuHalfComplex or int32
MAXDIM2= 138645
// for cuDoubleComplex or DD or int128
MAXDIM3= 69322
// for DD-Complex
MAXDIM4= 49018
// for half or int16
MAXDIM5= 196074
// cuda version
CUDA= 11040
// ASPEN.K2 version
ASPEN_K2= 1.9 Fuchu
<--
#define CURRENT_GPU 800
-->
#endif

#define	KERNEL_0	1
#define	KERNEL_1	1
#define	KERNEL_3	1
#define	KERNEL_5	1


// default kernel is
BLK = 0;

if ( n >= 1 && n < 5011 ) {
	BLK = 0;
} else
if ( n >= 5011 && n < 15009 ) {
	BLK = 1;
} else
if ( n >= 15009 && n < 15639 ) {
	BLK = 3;
} else
if ( n >= 15639 && n < 15786 ) {
	BLK = 1;
} else
if ( n >= 15786 && n < 16319 ) {
	BLK = 5;
} else
if ( n >= 16319 && n < 17043 ) {
	BLK = 1;
} else
if ( n >= 17043 && n < 17759 ) {
	BLK = 3;
} else
if ( n >= 17759 && n < 18534 ) {
	BLK = 1;
} else
if ( n >= 18534 && n < 19114 ) {
	BLK = 5;
} else
if ( n >= 19114 && n < 19523 ) {
	BLK = 3;
} else
if ( n >= 19523 && n < 20129 ) {
	BLK = 1;
} else
if ( n >= 20129 && n < 21321 ) {
	BLK = 3;
} else
if ( n >= 21321 && n < 23147 ) {
	BLK = 1;
} else
if ( n >= 23147 && n < 25377 ) {
	BLK = 3;
} else
if ( n >= 25377 && n < 26170 ) {
	BLK = 5;
} else
if ( n >= 26170 && n < 35882 ) {
	BLK = 3;
} else
if ( n >= 35882 && n < 36867 ) {
	BLK = 1;
} else
if ( n >= 36867 && n < 2147483647 ) {
	BLK = 3;
} else
if ( n >= 2147483647 && n <= 2147483647 ) {
	BLK = 3;
} 
#endif

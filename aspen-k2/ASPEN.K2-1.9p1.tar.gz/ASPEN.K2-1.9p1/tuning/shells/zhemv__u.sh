#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for ZHEMV-U'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../zhemvu__b3.sh log-*-X-X-X
/bin/sh ../zhemvu_c.sh
python ../d_filter.py zhemv-upper-auto3.h zhemv-upper-auto2.h

echo "Complete phase d"

echo '#if 0'             > zhemv-upper-auto_.h
echo_Message            >> zhemv-upper-auto_.h
cat ../DEV_INFO         >> zhemv-upper-auto_.h
echo '<--'              >> zhemv-upper-auto_.h
cat ../CURRENT_GPU      >> zhemv-upper-auto_.h
echo '-->'              >> zhemv-upper-auto_.h
echo '#endif'           >> zhemv-upper-auto_.h
cat zhemv-upper-auto.h	>> zhemv-upper-auto_.h
mv zhemv-upper-auto_.h zhemv-upper-auto.h
cp zhemv-upper-auto.h ..

echo '#if 0'             > zhemv-upper-auto_.h
echo_Message            >> zhemv-upper-auto_.h
cat ../DEV_INFO         >> zhemv-upper-auto_.h
echo '<--'              >> zhemv-upper-auto_.h
cat ../CURRENT_GPU      >> zhemv-upper-auto_.h
echo '-->'              >> zhemv-upper-auto_.h
echo '#endif'           >> zhemv-upper-auto_.h
cat zhemv-upper-auto2.h	>> zhemv-upper-auto_.h
mv zhemv-upper-auto_.h zhemv-upper-auto2.h
cp zhemv-upper-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-zhemvu.h
echo '#undef    PRESERVE_DROP'		>> param-zhemvu.h
echo '#endif'				>> param-zhemvu.h
echo '#define   PRESERVE_DROP   1'	>> param-zhemvu.h
cp param-zhemvu.h ..

cat zhemv-upper-auto.h
cat zhemv-upper-auto2.h

cd ../../src

\rm zhemv_upper.cu_o
make

cd ../bench

\rm test-z.o test2-z.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-zhemv-u IN-medium >& /dev/null
timeout -s KILL 600 ./test-zhemv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-zhemv-u IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-zhemv-u IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-zhemv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-zhemv-u IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-zhemvu

echo_Message end

exit 0


#!/bin/sh

DEFAULT_CUDA=9020


do_touch_header()
{
	if [ ! -e $1 ]; then
	if [ -e tuning-old/$MACHINE_DIR/$CUDA__DIR/$1 ]; then
		echo Copy tuning-old/$MACHINE_DIR/$CUDA__DIR/$1
		cp tuning-old/$MACHINE_DIR/$CUDA__DIR/$1 ./$1
	else
		echo Copy tuning-old/default/$DEFAULT_CUDA/$1
		if [ -e tuning-old/default/$DEFAULT_CUDA/$1 ]; then
		cp tuning-old/default/$DEFAULT_CUDA/$1 ./$1
		else
		f=`echo $1 | awk ' \
			/param/{ print "param-dsymvu.h" } \
			/upper-auto\.h/{ print "dsymv-upper-auto.h" } \
			/upper-auto2\.h/{ print "dsymv-upper-auto2.h" } \
			/lower-auto\.h/{ print "dsymv-lower-auto.h" } \
			/lower-auto2\.h/{ print "dsymv-lower-auto2.h" } '`
		if [[ $f =~ auto2 ]]; then
		g=`echo $1 | awk '{ gsub(/mv.*/,""); print}'`
		awk '{ gsub(/dsy/,"'$g'"); print}' tuning-old/default/$DEFAULT_CUDA/$f > ./$1
		else
		cp tuning-old/default/$DEFAULT_CUDA/$f ./$1
		fi
		fi
	fi
	fi
}

cd ../src; make get_dev_info; cd ../tuning

if [ x$CUDA_PATH != x ]; then
	export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi

../src/get_dev_info $ASPEN_GPU_ID > DEV_INFO

DEVICE=`awk '/DEVICE= /{print $2}' DEV_INFO`
CUDA=`awk '/CUDA= /{print $2; i=1}END{if(i==0)print '$DEFAULT_CUDA'}' DEV_INFO`

echo DEVICE $DEVICE
echo CUDA $CUDA

MACHINE_DIR=default
CUDA__DIR=$DEFAULT_CUDA
if [ -e tuning-old/$DEVICE ]; then
	MACHINE_DIR=$DEVICE
	if [ -e tuning-old/$MACHINE_DIR/$CUDA ]; then
		CUDA__DIR=$CUDA
	else
		CUDA__DIR=$DEFAULT_CUDA
	fi
	echo 'The configuration files tuned for '$DEVICE' with CUDA '$CUDA__DIR' are adopted.'
else
	MACHINE_DIR=default
	echo 'The default configuration files are adopted.'
	if [ -e tuning-old/$MACHINE_DIR/$CUDA ]; then
		CUDA__DIR=$CUDA
	else
		CUDA__DIR=$DEFAULT_CUDA
	fi
fi

for header in \
	wsymv-upper-auto.h \
	wsymv-upper-auto2.h \
	param-wsymvu.h \
	dsymv-upper-auto.h \
	dsymv-upper-auto2.h \
	param-dsymvu.h \
	ssymv-upper-auto.h \
	ssymv-upper-auto2.h \
	param-ssymvu.h \
	hsymv-upper-auto.h \
	hsymv-upper-auto2.h \
	param-hsymvu.h \
	wsymv-lower-auto.h \
	wsymv-lower-auto2.h \
	param-wsymvl.h \
	dsymv-lower-auto.h \
	dsymv-lower-auto2.h \
	param-dsymvl.h \
	ssymv-lower-auto.h \
	ssymv-lower-auto2.h \
	param-ssymvl.h \
	hsymv-lower-auto.h \
	hsymv-lower-auto2.h \
	param-hsymvl.h \
	uhemv-upper-auto.h \
	uhemv-upper-auto2.h \
	param-uhemvu.h \
	zhemv-upper-auto.h \
	zhemv-upper-auto2.h \
	param-zhemvu.h \
	chemv-upper-auto.h \
	chemv-upper-auto2.h \
	param-chemvu.h \
	uhemv-lower-auto.h \
	uhemv-lower-auto2.h \
	param-uhemvl.h \
	zhemv-lower-auto.h \
	zhemv-lower-auto2.h \
	param-zhemvl.h \
	chemv-lower-auto.h \
	chemv-lower-auto2.h \
	param-chemvl.h \
	i128symv-upper-auto.h \
	i128symv-upper-auto2.h \
	param-i128symvu.h \
	i64symv-upper-auto.h \
	i64symv-upper-auto2.h \
	param-i64symvu.h \
	i32symv-upper-auto.h \
	i32symv-upper-auto2.h \
	param-i32symvu.h \
	i16symv-upper-auto.h \
	i16symv-upper-auto2.h \
	param-i16symvu.h \
	i128symv-lower-auto.h \
	i128symv-lower-auto2.h \
	param-i128symvl.h \
	i64symv-lower-auto.h \
	i64symv-lower-auto2.h \
	param-i64symvl.h \
	i32symv-lower-auto.h \
	i32symv-lower-auto2.h \
	param-i32symvl.h \
	i16symv-lower-auto.h \
	i16symv-lower-auto2.h \
	param-i16symvl.h
do
	do_touch_header $header
done



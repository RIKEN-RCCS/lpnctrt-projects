#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for ZHEMV-U'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C
LOG=log-zhemvu-AT1X.`date +%Y.%m.%d.%T`
WORK_DIR=zhemvu-current

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH

#########################################################################
#export CUDA_FORCE_PTX_JIT=0
#export CUDA_CACHE_DISABLE=1
#########################################################################

cd ../src; make get_dev_info; cd ../tuning
../src/get_dev_info $ASPEN_GPU_ID > DEV_INFO

DEVICE=`awk '/DEVICE=/{ print $2 }' DEV_INFO`
MP=`awk '/MP=/{ print $2 }' DEV_INFO`
CG=`awk '/CG=/{ print $2 }' DEV_INFO`
MAXDIM=`awk '/MAXDIM3=/{ print $2 }' DEV_INFO`


cd ../src; make get_mult get_mult32 get_mult48; cd ../tuning

echo_Message begin

$PYTHON ./touch_header.py

mkdir $LOG
if [ -f $WORK_DIR ]; then
	\rm -rf $WORK_DIR
fi
if [ -h $WORK_DIR ]; then
	\rm $WORK_DIR
fi
if [ -d $WORK_DIR ]; then
	\rm -rf $WORK_DIR
fi
ln -s $LOG $WORK_DIR

echo 'Tuning processes are recorded on '$LOG'.'

cd $WORK_DIR
cd ../../src; make get_dev_info; cd ../tuning/$WORK_DIR
ln -s ../../src/get_dev_info .

tar -C ../.. -cf - src template | tar -xf -
cd src; make clean; cd ..

touch done_pattern
\rm done_pattern

if [ 'z' != 'h' ] || [ $CG -eq 530 ] || [ $CG -eq 600 ] || [ $CG -eq 610 ] || [ $CG -eq 630 ] || [ $CG -eq 700 ] || [ $CG -eq 750 ] || [ $CG -eq 800 ] || [ $CG -eq 860 ] ; then
	H_OK=1
else
	H_OK=0
fi

if [ $H_OK -eq 1 ]; then

touch $LOG.0

export USE_PARAMS_VIA_ARG=1
export ASPEN_TUNING_LEVEL=

for i in 0 1; do
/bin/sh ../zhemvu_a.sh $i | tee -a $LOG.0
done

/bin/sh ../zhemvu_b0.sh  $LOG 0 1 top20-0step
echo "Complete phase b0"

/bin/sh ../zhemvu_b1.sh  $LOG 1 2 top20-1step
echo "Complete phase b1"

/bin/sh ../zhemvu_b2.sh  $LOG 2 3 top20-3step
echo "Complete phase b2"

export USE_PARAMS_VIA_ARG=0

echo '#if defined(PRESERVE_DROP)'	 > param-zhemvu.h
echo '#undef	PRESERVE_DROP'		>> param-zhemvu.h
echo '#endif'				>> param-zhemvu.h
echo '#define	PRESERVE_DROP	1'	>> param-zhemvu.h
cp param-zhemvu.h ..

/bin/sh ../zhemvu_b3.sh  $LOG 3 4 top20-4step
echo "Complete phase b3"

/bin/sh ../zhemvu_b4.sh  $LOG 4 5 top20-final
echo "Complete phase b4"

$PYTHON ../symv_predict.py predict.data zhemv-upper-auto3.h
echo "Complete phase c"

$PYTHON ../d_filter.py zhemv-upper-auto3.h zhemv-upper-auto2.h
echo "Complete phase d"

unset USE_PARAMS_VIA_ARG

fi


echo zhemv_upper | awk '{print "#ifndef "toupper($0)"_AUTO_H_INCLUDED" }' \
			>  zhemv-upper-auto_.h
echo zhemv_upper | awk '{print "#define "toupper($0)"_AUTO_H_INCLUDED 1" }' \
			>> zhemv-upper-auto_.h
echo '#if 0'            >> zhemv-upper-auto_.h
echo_Message            >> zhemv-upper-auto_.h
cat ../DEV_INFO         >> zhemv-upper-auto_.h
echo '<--'              >> zhemv-upper-auto_.h
cat ../CURRENT_GPU      >> zhemv-upper-auto_.h
echo '-->'              >> zhemv-upper-auto_.h
echo '#endif'           >> zhemv-upper-auto_.h
if [ $H_OK -eq 1 ]; then
cat zhemv-upper-auto.h	>> zhemv-upper-auto_.h
fi
echo '#endif'           >> zhemv-upper-auto_.h

mv zhemv-upper-auto_.h zhemv-upper-auto.h
cp zhemv-upper-auto.h ..


echo zhemv_upper | awk '{print "#ifndef "toupper($0)"_AUTO2_H_INCLUDED" }' \
			>  zhemv-upper-auto_.h
echo zhemv_upper | awk '{print "#define "toupper($0)"_AUTO2_H_INCLUDED 1" }' \
			>> zhemv-upper-auto_.h
echo '#if 0'            >> zhemv-upper-auto_.h
echo_Message            >> zhemv-upper-auto_.h
cat ../DEV_INFO         >> zhemv-upper-auto_.h
echo '<--'              >> zhemv-upper-auto_.h
cat ../CURRENT_GPU      >> zhemv-upper-auto_.h
echo '-->'              >> zhemv-upper-auto_.h
echo '#endif'           >> zhemv-upper-auto_.h
if [ $H_OK -eq 1 ]; then
cat zhemv-upper-auto2.h	>> zhemv-upper-auto_.h
fi
echo '#endif'           >> zhemv-upper-auto_.h

mv zhemv-upper-auto_.h zhemv-upper-auto2.h
cp zhemv-upper-auto2.h ..


echo '#if defined(PRESERVE_DROP)'	 > param-zhemvu.h
echo '#undef	PRESERVE_DROP'		>> param-zhemvu.h
echo '#endif'				>> param-zhemvu.h
echo '#define	PRESERVE_DROP	1'	>> param-zhemvu.h
cp param-zhemvu.h ..


cat zhemv-upper-auto.h
cat zhemv-upper-auto2.h

cd ../../src

\rm zhemv_upper.cu_o zhemv_upper.cu_lo
make

cd ../bench

\rm test-z.o test2-z.o
make

echo "Complete phase e"

echo 1  >  IN-abc
echo 10 >> IN-abc
echo -1 >> IN-abc

if [ $H_OK -eq 1 ]; then
timeout -s KILL 30  ./test-zhemv-u IN-abc >& /dev/null
timeout -s KILL 30  ./test-zhemv-u IN-abc >& /dev/null

timeout -s KILL 600 ./test-zhemv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-zhemv-u IN-medium
fi
fi

echo "Complete phase f1"

if [ $H_OK -eq 1 ]; then
timeout -s KILL 20   ./test2-zhemv-u IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-zhemv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-zhemv-u IN-medium
fi
fi

echo "Complete phase f2"

cd ../tuning

touch .done-zhemvu

echo_Message end

exit 0


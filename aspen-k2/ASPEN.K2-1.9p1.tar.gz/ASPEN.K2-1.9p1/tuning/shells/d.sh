#!/bin/bash

UX=8

Do ( )
{
	awk '\
		/\/\//{ gsub(/\/\//,""); } \
		/switch[ ]*\([ ]*_MM_/ { flag = 1; } \
		/_M_SPLIT/ { \
				JJ=$3; \
			} \
		/case/ { \
			gsub(/:/,""); CASE = $2; \
			pat0 = ""; \
			pat1 = ""; \
			while ( 1 ) { \
				getline; \
				if ( $0~/break/ ) break; \
				if ( $0~/if/ ) continue; \
				gsub(/_L_[ ]*\([ ]*[0-9]*[ ]*\)[ ]*;[ ]*/,""); \
				gsub(/_M_/,""); gsub(/[\(\);]/,""); \
				p = split($0, c); \
				for(i=1;i<=p;i++) { \
					if ( c[i] < '$UX' ) { \
						if ( c[i] < JJ ) \
							pat0 = pat0","c[i]; \
						if ( c[i] >= JJ ) \
							pat1 = pat1","c[i]; \
					} \
				} \
			} \
			pat[CASE] = pat1"."pat0; \
		} \
		/default:/{ exit; } \
		END { \
			for(i=0;i<10;i++) { \
			for(j=i+1;j<10;j++) { \
				if ( pat[i] == pat[j] ) { \
					break; \
				} \
			} \
				if ( j<10 ) { } else { \
					print '$UX'" "i+00; \
					print '$UX'" "i+10; \
					print '$UX'" "i+20; \
					print '$UX'" "i+30; \
					print '$UX'" "i+40; \
					print '$UX'" "i+50; \
					print '$UX'" "i+60; \
					print '$UX'" "i+70; \
					print '$UX'" "i+80; \
					print '$UX'" "i+90; \
				} \
			} \
		} \
	' ../../template/hesymv_M_patterns.h
}


UX=2
while [ $UX -lt 128 ]
do
	Do
	UX=`expr $UX "+" 1`
done


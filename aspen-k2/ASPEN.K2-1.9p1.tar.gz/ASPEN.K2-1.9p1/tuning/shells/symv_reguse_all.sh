#!/bin/bash

CUDA_PATH_65=/usr/local/cuda-6.5
CUDA_PATH_70=/usr/local/cuda-7.0
CUDA_PATH_75=/usr/local/cuda-7.5


Init()
{
	\rm ../CURRENT_GPU
	echo '#define CURRENT_GPU '$CG > ../CURRENT_GPU

	UX_PATTERN=" 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 "
	if [ $CG -lt 300 ]; then
		MM_PATTERN=" 8 7 6 5 4 3 2 "
		MM_MAX=8
	else
	if [ $CG -lt 500 ]; then
		MM_PATTERN=" 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 "
		MM_MAX=16
	else
		MM_PATTERN=" 32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 "
		MM_MAX=32
	fi
	fi
}

Setup()
{
	if [ -f $HEADER ]; then
		\rm $HEADER
	fi
	awk ' \
		BEGIN{ \
			print "switch (BLK) {"; \
			for ( i=1; i <= 10*'$MM_MAX'; i++ ) { \
				print "#if __KERNEL"i; \
				print "case "i":"; \
				print "\tAPI(SYMV'$FORMAT'_ATOMIC_host) < GPU_ARCH, scalar_t, BLOCK_SIZE, VX, UX, "int((i-1)/10)+1", "(i-1)%10" >"; \
				print "\t( n, a, lda, x, y, alpha, beta ); break;"; \
				print "#endif" \
			} \
			print "default:"; \
			print "\tfprintf( stderr, \"Not proper Parameter %d \", BLK );"; \
			print "\tbreak;"; \
			print "}"; \
			exit; \
		} { exit; } END { exit; }' > $HEADER
	cp $HEADER ../
}


Make0()
{
	if [ -f $PARAM ]; then
		\rm $PARAM
	fi
	touch $PARAM

cat << EOF_1 >> $PARAM
#define BLOCK_SIZE      $BLOCK_SIZE
#define VX              $VX
#define UX              $UX

// $MMM_PATTERN
EOF_1

        for MULTI in \
                $MMM_PATTERN
        do
        for MX in \
                0 1 2 3 4 5 6 7 8 9
        do
                ID=`expr $MULTI "-" 1`
                ID=`expr $ID "*" 10`
                ID=`expr $ID "+" $MX`
                ID=`expr $ID "+" 1`
                echo "#define   __KERNEL"$ID" 1" >> $PARAM
        done
        done
	if [ -f ../$PARAM ]; then
		\rm ../$PARAM
	fi
        cp $PARAM ../
}

Do()
{

Init

Setup

echo "Sampling start"

	GLOBAL_MAX_UX_MX=0

for VX in \
	2 3 4 5 6 7 8
do
for BLOCK_SIZE in \
	32 64 96 128 160 192 224 256 288
do
if [ `expr $BLOCK_SIZE "*" $VX` -ge 128 ]; then
if [ `expr $BLOCK_SIZE "*" $VX` -le 320 ]; then

  touch log-regs-$BLOCK_SIZE
  \rm log-regs-$BLOCK_SIZE

	MAX_UX_MX=0

  for UX in \
	$UX_PATTERN
  do
  if [ $UX -le $BLOCK_SIZE ]; then

  if [ `expr $UX "%" $VX` -eq 0 ]; then
  if [ `expr $UX "/" $VX` -ge 3 ]; then
  if [ `expr $UX "/" $VX` -le 32 ]; then


	MMM_PATTERN="1"
	Make0 >& /dev/null

	M=`expr $UX "/" 2`
	M=`expr $M "*" 2`
	M=`expr $M "+" 1`
	M=`expr $M "*" $UX`
	M2=`expr $BLOCK_SIZE "*" $VX`
#	if [ $M -lt $M2 ]; then
		M=$M2
#	fi
	M1=`expr $M "%" 2`
	M=`expr $M "+" $M1`
	M=`expr $M "+" $UX`
	M=`expr $M "+" 8`
	SHMEM_MIN=`expr $M "*" $SIZEOF`

	/bin/sh ../get_reguse.sh $CG main_do \
		../../src/$TEMPLATE \
		../../src/$TEMPLATE \
		../../src/$TEMPLATE \
		../../src/$TEMPLATE \
		../../src/$TEMPLATE \
		../../src/$TEMPLATE \
		| \
        sort -k 5 > log-reg-all

	MMM=0
	OOO=0
	CCC=0
	SSS=0
	XXX=0
      for MX in \
	0 1 2 3 4 5 6 7 8 9
      do

	touch log-regs
	\rm log-regs

	cat log-reg-all | awk '{if($5=='$MX')print $1}' > CX
	CX=`cat CX`

	cat log-reg-all | awk '{if($5=='$MX')print $7}' > SX
	SX=`cat SX`

	M=`expr $BLOCK_SIZE "*" $VX`
if [ $CG -lt 200 ]; then
	/bin/sh ../get_mult.sh $M $CX $SHMEM_MIN $CG > multi_use
else
	/bin/sh ../get_mult48.sh $M $CX $SHMEM_MIN $CG > multi_use
fi

	MMM_PATTERN=`cat multi_use | \
		awk '{ gsub(/\([0-9]*\)/," "); print; }'`
	OOO_PATTERN=`cat multi_use | \
		awk '{ gsub(/[0-9]*\(/," "); gsub(/\)/,""); print; }'`
	M=`echo $MMM_PATTERN | awk '{ print $(NF); }'`
	O=`echo $OOO_PATTERN | awk '{ print $(NF); }'`
	if [ $M -gt $MMM ]; then
		if [ ! $MMM -eq 0 ]; then
			CCC=1
		fi
		MMM=$M
		OOO=$O
        else
		if [ ! $M -eq $MMM ]; then
			CCC=1
		fi
	fi

	UX_MX=`expr $UX "*" $M`
if [ $UX_MX -gt $MAX_UX_MX ]; then
	MAX_UX_MX=$UX_MX
fi

if [ $SX -eq 0 ]; then
	M=`expr $M "-" 2`
fi
if [ $SX -eq 2 ]; then
	M=`expr $M "-" 1`
fi

	if [ $M -eq $MMM ]; then
		XXX=$MX
	fi

	if [ $SSS -lt $SX ]; then
		SSS=$SX
	fi

	echo $BLOCK_SIZE' '$VX' '$UX' '$MX' Register= '$CX ' / '$SX' :: '$SHMEM_MIN' : '$MMM_PATTERN | \
		tee -a log-regs-$BLOCK_SIZE

      done # for MX

      echo '## '$BLOCK_SIZE' '$VX' '$UX' '$MMM' / '$OOO'% ! '$CCC' > '$SSS '::' $XXX | \
		tee -a log-regs-$BLOCK_SIZE

        if [ $MMM -eq 1 ]; then
		break
	fi
        if [ $SSS -eq 0 ]; then
		break
	fi

  fi
  fi
  fi

  fi
  done # for UX

M=`expr $MAX_UX_MX "*" $BLOCK_SIZE`
if [ $M -gt $GLOBAL_MAX_UX_MX ]; then
	GLOBAL_MAX_UX_MX=$M
fi

  cp log-regs-$BLOCK_SIZE log-regs-$BLOCK_SIZE-$VX
  echo $MAX_UX_MX > MAX_UX_MX-$BLOCK_SIZE-$VX

fi
fi
done # for BLOCK_SIZE
done # for VX

  echo $GLOBAL_MAX_UX_MX > GLOBAL_MAX_UX_MX
}



for PRECISION in \
	d s
do

if [ $PRECISION = 'd' ]; then
	SIZEOF=8
else
	SIZEOF=4
fi

for FORMAT in \
	u l
do


	WORK_DIR=$PRECISION'symv'$FORMAT'_reguse'

if [ $FORMAT = 'u' ]; then
	HEADER=$PRECISION'symv-upper-auto.h'
	TEMPLATE=$PRECISION'symv_upper-X_template'
else
	HEADER=$PRECISION'symv-lower-auto.h'
	TEMPLATE=$PRECISION'symv_lower-X_template'
fi
	PARAM='param-'$PRECISION'symv'$FORMAT'.h'


if [ -e $WORK_DIR ]; then
	\rm -rf $WORK_DIR
fi
mkdir $WORK_DIR

for CUDA in \
	6050 7000 7050
do

	if [ $CUDA = '6050' ]; then
		export CUDA_PATH=$CUDA_PATH_65
	fi
	if [ $CUDA = '7000' ]; then
		export CUDA_PATH=$CUDA_PATH_70
	fi
	if [ $CUDA = '7050' ]; then
		export CUDA_PATH=$CUDA_PATH_75
	fi

	cd $WORK_DIR
	if [ -e  $CUDA ]; then
		\rm -rf $CUDA
	fi
	mkdir $CUDA
	cd ..

	for CG in \
		200 300 350 500 520
	do
		echo 'CUDA '$CUDA'/ CG '$CG'/ '$PRECISION'symv'$FORMAT
		if [ -e log-$CG ]; then
			\rm -rf log-$CG
		fi
		mkdir log-$CG
		cd log-$CG
		Do | tee log-reguse-all
		cd ..
	done

	for CG in \
		200 300 350 500 520
	do
		cd log-$CG
		\rm CX SX multi_use log-reg-all *.h
		chmod -w *
		cd ..
		mv log-$CG $WORK_DIR/$CUDA/$CG
	done

done

done
done

	\rm CURRENT_GPU


#! /usr/bin/env python

import sys
import os
import subprocess
import re
import math


def check_lines() :
    err = False
    for j in line :
        if 'ERR' in line[j] :
            err = True
            break
        if 'cannot' in line[j] :
            err = True
            break
    return err

def print_out() :
    err = check_lines()
    if err is True :
        return
    for j in line :
        a = line[j].split()
        N = int( a[1] )
        T = float( a[2] )
        point = int( float( a[4] ) * 1000 )
        print( 'N= %6d %010d %3d %2d %3d %2d %2d %2d' %
               ( N, point,
                 BLOCK_SIZE, VX, UX, MULTI, _M_, GY ) )
        if not N in pmax :
            pmax[N] = point
            tmin[N] = T
        else :
            if pmax[N] < point :
               pmax[N] = point
               tmin[N] = T
    print( 'EOR' )

def calc_point() :
    err = check_lines()
    if err is True :
        return
    point = 0
    for j in line :
        a = line[j].split()
        N = int( a[1] )
        T = float( a[2] )
        Tmin = tmin[N]
        if T <= Tmin :
            c = 300000
        else :
            c = (2.0*(Tmin-T)*(Tmin-T))/(Tmin*Tmin)
            c = c * math.sqrt(float(N))/100
            if c < 700 :
                c = int(100000*math.exp(-c)+1)
            else :
                c = 1
        point = point + c
    tag = str(BLOCK_SIZE) + ' ' + str(VX) + ' ' + str(UX) + ' ' + str(MULTI) + ' ' + str(_M_) + ' ' + str(GY)
    kernel[tag] = point


if __name__ == '__main__' :

    args = sys.argv
    argc = len( args )

    if argc != 3 :
        print( 'Usage: %s infile top' % os.path.basename( args[0] ) )
        exit( 1 )

    infile  = args[1]
    if not os.path.exists( infile ) :
        sys.stderr.write( 'Error: file %s not exsiting.\n' % infile )
        exit( 1 )

    pmax = {}
    tmin = {}
    kernel = {}

    for itr in range(2) :

        with open( infile, mode = 'r' ) as file :

            flag = False
    	    i = 0
            line = {}

            BLOCK_SIZE = 32
            VX         = 1
            UX         = 1
            MULTI      = 2
            _M_        = 0
            GY         = 3

            while True :

                buff = file.readline()
                if not buff :
                    break

                if '#define' in buff :

                    if flag :
                        if itr == 0 :
                            print_out()
                        else :
                            calc_point()
                        flag = False
                        i = 0
                    if 'N=' in buff :
                        buff = re.sub( 'N= [0-9]* ', '', buff );

                    if 'BLOCK_SIZE' in buff :
                        BLOCK_SIZE = int( buff.split()[2] )
                        continue
                    if 'VX' in buff :
                        VX = int( buff.split()[2] )
                        continue
                    if 'UX' in buff :
                        UX = int( buff.split()[2] )
                        continue
                    if 'MULTIPLICITY' in buff :
                        MULTI = int( buff.split()[2] )
                        continue
                    if '_M_' in buff :
                        _M_ = int( buff.split()[2] )
                        continue
                    if 'GY' in buff :
                        GY = int( buff.split()[2] )
                        continue
                    continue

                if 'N= ' in buff :
                    if not 'numBlocks' in buff :
                        if '[s]' in buff :
                            i = i + 1
                            line[i] = buff
                            flag = True
                    continue

        if flag :
            if itr == 0 :
                print_out()
            else :
                calc_point()


    Point = {}
    Param = {}
    itr = 0
    for j in kernel :
        Point[itr] = kernel[j]
        Param[itr] = j
        itr = itr + 1

    for j in range(0,itr) :
        for k in range(j,itr) :
            if Point[j] < Point[k] :
                Point[j], Point[k] = Point[k], Point[j]
                Param[j], Param[k] = Param[k], Param[j]

    if ( itr < 60 ) :
        for j in range(itr,60) :
            Point[j] = 1
            Param[j] = '32 1 1 1 1'+str(j)
    itr = 60

    topfile = args[2]
    if os.path.exists( topfile ) :
        sys.stderr.write( 'Warning: file %s already exsited, it will be overwritten.\n' % infile )

    with open( topfile, mode='w' ) as file :

        for j in range(itr) :
            point = Point[j]
            line  = Param[j].split()
            BLOCK_SIZE = int(line[0])
            VX         = int(line[1])
            UX         = int(line[2])
            MULTI      = int(line[3])
            _M_        = int(line[4])
            GY         = int(line[5])
            print( '# %010d %3d %2d %3d %2d %2d %2d' %
               ( point,
                 BLOCK_SIZE, VX, UX, MULTI, _M_, GY ) )
            file.write( '%010d %3d %2d %3d %2d %2d %2d\n' %
               ( point,
                 BLOCK_SIZE, VX, UX, MULTI, _M_, GY ) )

    

#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for CHEMV-U'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../chemvu__b3.sh log-*-X-X-X
/bin/sh ../chemvu_c.sh
python ../d_filter.py chemv-upper-auto3.h chemv-upper-auto2.h

echo "Complete phase d"

echo '#if 0'             > chemv-upper-auto_.h
echo_Message            >> chemv-upper-auto_.h
cat ../DEV_INFO         >> chemv-upper-auto_.h
echo '<--'              >> chemv-upper-auto_.h
cat ../CURRENT_GPU      >> chemv-upper-auto_.h
echo '-->'              >> chemv-upper-auto_.h
echo '#endif'           >> chemv-upper-auto_.h
cat chemv-upper-auto.h	>> chemv-upper-auto_.h
mv chemv-upper-auto_.h chemv-upper-auto.h
cp chemv-upper-auto.h ..

echo '#if 0'             > chemv-upper-auto_.h
echo_Message            >> chemv-upper-auto_.h
cat ../DEV_INFO         >> chemv-upper-auto_.h
echo '<--'              >> chemv-upper-auto_.h
cat ../CURRENT_GPU      >> chemv-upper-auto_.h
echo '-->'              >> chemv-upper-auto_.h
echo '#endif'           >> chemv-upper-auto_.h
cat chemv-upper-auto2.h	>> chemv-upper-auto_.h
mv chemv-upper-auto_.h chemv-upper-auto2.h
cp chemv-upper-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-chemvu.h
echo '#undef    PRESERVE_DROP'		>> param-chemvu.h
echo '#endif'				>> param-chemvu.h
echo '#define   PRESERVE_DROP   1'	>> param-chemvu.h
cp param-chemvu.h ..

cat chemv-upper-auto.h
cat chemv-upper-auto2.h

cd ../../src

\rm chemv_upper.cu_o
make

cd ../bench

\rm test-c.o test2-c.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-chemv-u IN-medium >& /dev/null
timeout -s KILL 600 ./test-chemv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-chemv-u IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-chemv-u IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-chemv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-chemv-u IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-chemvu

echo_Message end

exit 0


#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for DSYMV-U'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../dsymvu__b3.sh log-*-X-X-X
/bin/sh ../dsymvu_c.sh
python ../d_filter.py dsymv-upper-auto3.h dsymv-upper-auto2.h

echo "Complete phase d"

echo '#if 0'             > dsymv-upper-auto_.h
echo_Message            >> dsymv-upper-auto_.h
cat ../DEV_INFO         >> dsymv-upper-auto_.h
echo '<--'              >> dsymv-upper-auto_.h
cat ../CURRENT_GPU      >> dsymv-upper-auto_.h
echo '-->'              >> dsymv-upper-auto_.h
echo '#endif'           >> dsymv-upper-auto_.h
cat dsymv-upper-auto.h	>> dsymv-upper-auto_.h
mv dsymv-upper-auto_.h dsymv-upper-auto.h
cp dsymv-upper-auto.h ..

echo '#if 0'             > dsymv-upper-auto_.h
echo_Message            >> dsymv-upper-auto_.h
cat ../DEV_INFO         >> dsymv-upper-auto_.h
echo '<--'              >> dsymv-upper-auto_.h
cat ../CURRENT_GPU      >> dsymv-upper-auto_.h
echo '-->'              >> dsymv-upper-auto_.h
echo '#endif'           >> dsymv-upper-auto_.h
cat dsymv-upper-auto2.h	>> dsymv-upper-auto_.h
mv dsymv-upper-auto_.h dsymv-upper-auto2.h
cp dsymv-upper-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-dsymvu.h
echo '#undef    PRESERVE_DROP'		>> param-dsymvu.h
echo '#endif'				>> param-dsymvu.h
echo '#define   PRESERVE_DROP   1'	>> param-dsymvu.h
cp param-dsymvu.h ..

cat dsymv-upper-auto.h
cat dsymv-upper-auto2.h

cd ../../src

\rm dsymv_upper.cu_o
make

cd ../bench

\rm test-d.o test2-d.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-dsymv-u IN-medium >& /dev/null
timeout -s KILL 600 ./test-dsymv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-dsymv-u IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-dsymv-u IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-dsymv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-dsymv-u IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-dsymvu

echo_Message end

exit 0


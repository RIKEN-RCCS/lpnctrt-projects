#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for SSYMV-U'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../ssymvu__b3.sh log-*-X-X-X
/bin/sh ../ssymvu_c.sh
python ../d_filter.py ssymv-upper-auto3.h ssymv-upper-auto2.h

echo "Complete phase d"

echo '#if 0'             > ssymv-upper-auto_.h
echo_Message            >> ssymv-upper-auto_.h
cat ../DEV_INFO         >> ssymv-upper-auto_.h
echo '<--'              >> ssymv-upper-auto_.h
cat ../CURRENT_GPU      >> ssymv-upper-auto_.h
echo '-->'              >> ssymv-upper-auto_.h
echo '#endif'           >> ssymv-upper-auto_.h
cat ssymv-upper-auto.h	>> ssymv-upper-auto_.h
mv ssymv-upper-auto_.h ssymv-upper-auto.h
cp ssymv-upper-auto.h ..

echo '#if 0'             > ssymv-upper-auto_.h
echo_Message            >> ssymv-upper-auto_.h
cat ../DEV_INFO         >> ssymv-upper-auto_.h
echo '<--'              >> ssymv-upper-auto_.h
cat ../CURRENT_GPU      >> ssymv-upper-auto_.h
echo '-->'              >> ssymv-upper-auto_.h
echo '#endif'           >> ssymv-upper-auto_.h
cat ssymv-upper-auto2.h	>> ssymv-upper-auto_.h
mv ssymv-upper-auto_.h ssymv-upper-auto2.h
cp ssymv-upper-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-ssymvu.h
echo '#undef    PRESERVE_DROP'		>> param-ssymvu.h
echo '#endif'				>> param-ssymvu.h
echo '#define   PRESERVE_DROP   1'	>> param-ssymvu.h
cp param-ssymvu.h ..

cat ssymv-upper-auto.h
cat ssymv-upper-auto2.h

cd ../../src

\rm ssymv_upper.cu_o
make

cd ../bench

\rm test-s.o test2-s.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-ssymv-u IN-medium >& /dev/null
timeout -s KILL 600 ./test-ssymv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-ssymv-u IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-ssymv-u IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-ssymv-u IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-ssymv-u IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-ssymvu

echo_Message end

exit 0


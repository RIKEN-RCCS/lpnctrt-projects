#! /usr/bin/env python

import sys
import os
import subprocess
import shutil
import re


os.environ['NEW_KEY'] = 'test'

#!/bin/sh

CG=$1
KERNEL_KEY=$2
TARGET=$3.cu

#TEMPDIR=TEMP.$$_$$_$$

#COMPILER=$CUDA_PATH'/bin/nvcc -O3 --ptxas-options=-v --maxrregcount=63 -DAT_VERSION --fmad=true -I'$CUDA_PATH'/include -I./include -I../include -I../../include -I. --keep-dir=$TEMPDIR'
COMPILER=$CUDA_PATH'/bin/nvcc -O3 --ptxas-options=-v --maxrregcount=63 -DAT_VERSION --fmad=true -I'$CUDA_PATH'/include -I./include -I../include -I../../include -I.'


#mkdir $TEMPDIR
#touch comp-log.$$; \rm comp-log.$$

if [ $CG -eq 130 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_13 -code=compute_13,sm_13 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 200 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_20 -code=compute_20,sm_20 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 300 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_30 -code=compute_30,sm_30 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 350 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_35 -code=compute_35,sm_35 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 370 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_37 -code=compute_37,sm_37 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 500 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_50 -code=compute_50,sm_50 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 520 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_52 -code=compute_52,sm_52 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 530 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_53 -code=compute_53,sm_53 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 600 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_60 -code=compute_60,sm_60 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 610 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_61 -code=compute_61,sm_61 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 620 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_62 -code=compute_62,sm_62 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 700 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_70 -code=compute_70,sm_70 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

if [ $CG -eq 750 ]; then
	$COMPILER -DGPU_ARCH=$CG \
		-arch=compute_75 -code=compute_75,sm_75 \
		-c $TARGET -o tmp$$.o >& comp-log.$$
fi

cat comp-log.$$ | \
	awk '/Func/ { \
		if ( $0 ~ /'$KERNEL_KEY'/ ) { \
			Name = $7; \
			o=0;\
			gsub(/.*'$KERNEL_KEY'/, "", Name); \
			gsub(/E7double2/, " ", Name); \
			gsub(/E6float2/, " ", Name); \
			gsub(/E12__cudfreal__/, " ", Name); \
			o+=\
			gsub(/E15__cudfcomplex__/, " ", Name); \
			gsub(/E12__cuddreal__/, " ", Name); \
			o+=\
			gsub(/E15__cuddcomplex__/, " ", Name); \
			gsub(/_.*/, "", Name); \
			gsub(/[A-Za-z]/, " ", Name); \
			split(Name, P); \
			spilled=0; \
			while ( 1 ) { \
				getline; \
				if ( $0~/spill/ ) { \
					spilled=$5+$9; \
				} \
				if ( $0~/registers/ ) { \
					Reg = $5; \
					if ( '$CG' < 350 ) { \
						Limit = (o>0)?320:192; \
					} else { \
						Limit = 64; \
					} \
					if ( spilled > Limit ) { \
						s = 0; \
					} else { \
						s = (spilled==0)?1:2; \
					} \
					print Reg" "P[2]" "P[3]" "P[4]" "P[5]" "P[6]" "s; \
					break; \
				} \
			} \
		} \
	}'

if [ -f comp-log.$$ ]; then
	\rm comp-log.$$
fi
if [ -f tmp$$.o ]; then
	\rm tmp$$.o
fi
#\rm -rf $TEMPDIR

exit 0


#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for UHEMV-L'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../uhemvl__b3.sh log-*-X-X-X
/bin/sh ../uhemvl_c.sh
python ../d_filter.py uhemv-lower-auto3.h uhemv-lower-auto2.h

echo "Complete phase d"

echo '#if 0'             > uhemv-lower-auto_.h
echo_Message            >> uhemv-lower-auto_.h
cat ../DEV_INFO         >> uhemv-lower-auto_.h
echo '<--'              >> uhemv-lower-auto_.h
cat ../CURRENT_GPU      >> uhemv-lower-auto_.h
echo '-->'              >> uhemv-lower-auto_.h
echo '#endif'           >> uhemv-lower-auto_.h
cat uhemv-lower-auto.h	>> uhemv-lower-auto_.h
mv uhemv-lower-auto_.h uhemv-lower-auto.h
cp uhemv-lower-auto.h ..

echo '#if 0'             > uhemv-lower-auto_.h
echo_Message            >> uhemv-lower-auto_.h
cat ../DEV_INFO         >> uhemv-lower-auto_.h
echo '<--'              >> uhemv-lower-auto_.h
cat ../CURRENT_GPU      >> uhemv-lower-auto_.h
echo '-->'              >> uhemv-lower-auto_.h
echo '#endif'           >> uhemv-lower-auto_.h
cat uhemv-lower-auto2.h	>> uhemv-lower-auto_.h
mv uhemv-lower-auto_.h uhemv-lower-auto2.h
cp uhemv-lower-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-uhemvl.h
echo '#undef    PRESERVE_DROP'		>> param-uhemvl.h
echo '#endif'				>> param-uhemvl.h
echo '#define   PRESERVE_DROP   1'	>> param-uhemvl.h
cp param-uhemvl.h ..

cat uhemv-lower-auto.h
cat uhemv-lower-auto2.h

cd ../../src

\rm uhemv_lower.cu_o
make

cd ../bench

\rm test-u.o test2-u.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-uhemv-l IN-medium >& /dev/null
timeout -s KILL 600 ./test-uhemv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-uhemv-l IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-uhemv-l IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-uhemv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-uhemv-l IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-uhemvl

echo_Message end

exit 0


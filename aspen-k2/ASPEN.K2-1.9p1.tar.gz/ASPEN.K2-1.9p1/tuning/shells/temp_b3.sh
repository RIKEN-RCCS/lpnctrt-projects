#!/bin/bash

export LD_LIBRARY_PATH=../../lib:$LD_LIBRARY_PATH

IN=$1

Make ()
{
	cd ../../src
	\rm @p.@kernel._@luop..cu_o
	make
	cd ../bench
	\rm test-d.o test2-d.o
	make 
	cd ../tuning/@p.@kernel.@lu.-current
}

Do ()
{
	echo $IN
	awk -f ../anal_symv.awk $IN | \
	tee anal_symv-result | \
	awk ' \
		/N= '$N'/{ \
			print; \
		} \
	' | \
	sort -S 1G -r | \
	head -200 | \
	awk ' \
		BEGIN { \
			N=0; \
		} \
		{ \
                        if ( N != $2 ) { \
				N=$2; Tmin=$3; p=1; \
				print $0" "500000; \
			} else { \
                        T = (1.0e+5*(1.0*Tmin-$3)*(1.0*Tmin-$3))/(1.0*Tmin*Tmin); \
			T = T * sqrt(1.0*N)/100; \
                        if ( T < 700 ) { \
                           print $0" "(int(100000*exp(-T)+1)); \
                        } else { \
                           print $0" "1; \
                        } } \
                        p++; \
                } \
	'
}

Main ()
{
N_PATTERN=`cat IN-exe-a | awk '{ if( i>0 && $1>0 ) printf("%d ",$1); i++; }'`
for N in \
	$N_PATTERN
do
	Do
done
}

DO_MATLAB ()
{

echo "S=[ 0" > cc$ID.m

	awk ' \
		BEGIN { \
			line = 0; \
		} \
		{ \
			line++; \
			if ( line <= 2 )next; \
			if ( $1 > 0 ) print; \
		} \
	' IN-exe-b >> cc$ID.m
	cat << EOS_M >> cc$ID.m
];

y=[ 0
EOS_M

	awk ' \
		/BLK/{ \
			gsub(/=/," "); \
			flag = ($4=='$ID')?1:0; next; \
		} \
		/N=/{ \
			if(flag>0){ \
				if(flag==1) { \
					flag++; next; \
				} \
				print $2" "$5; flag++; \
			} \
		} \
		' log-@p.@kernel.-AV > log-RANK$ID

	awk ' \
		{
			print $2;
		} \
		' log-RANK$ID >> cc$ID.m

	cat << EOS_MM >> cc$ID.m
];

[M,c]=size(S);
[MM,c]=size(y);
if MM<M
	M=MM
end
N=S(M)-S(1)+1;

z=zeros(N,1);
ii=zeros(N,1);
for j=1:N
	ii(j) = j+S(1)-1;
end

norm = y'*y;
if norm > 0

	EtE = sparse(N,N);
	for j=1:M
		k=S(j)-S(1)+1;
		EtE(k,k)=1;
	end

	D = sparse(N,N);
	for j=2:N-1
		D(j,j-1)=1; D(j,j)=-2; D(j,j+1)=1;
	end
	DtD=D'*D/N;

	AA=EtE+DtD;

	yy=zeros(N,1);
	for j=1:M
		s = S(j)-S(1)+1;
		yy(s) = y(j);
	end

	yyN=yy(N);
	yy=yy/yyN;
	z=(AA\yy)*yyN;

end

[ii,z]
EOS_MM

	octave cc$ID.m

}

Main | \
	awk '\
		{ \
			s=$4" "$5" "$6" "$7" "$8" "$9; \
			score[s] += $10; \
		} \
		END{ \
			for(f in score) \
				printf("%08d %s\n", score[f], f); \
		}' | \
	sort -S 1G -r | \
	awk ' \
		{ \
			body=$2" "$3" "$4" "$5" "$6" "$7; \
			h=1; \
			h1=$1; \
			if ( h1 > 10000 ) { \
				printf("%03d::%s %s\n", h, h1, body); \
			} else { \
				body="32 1 1 1 1 2"; \
			} \
		} \
		END { \
			for(i=0;i<20;i++){ \
				printf("%03d::%s %s\n", 0, 0, body); \
			}\
		} \
        ' | \
	sort -S 1G -r | head -20 | tee top20 | \
	awk '\
		BEGIN{ \
			id=1; \
		}\
		{ \
			if ( $1 > 0 ) { \
				score[id]=$1; \
				BLOCK_SIZE[id]=$2; \
				VX[id]=$3; \
				UX[id]=$4; \
				MULTI[id]=$5; \
				MX[id]=$6; \
				GY[id]=$7; \
				id++; \
			} \
		} \
		END { \
			print "{"; \
			print "//=========="; \
			print "if(blk==-1){"; \
			print "\t#include \"@p.@kernel.-@luop.-auto2.h\""; \
			print "}"; \
			print "//=========="; \
			print "#if 0"; \
			print "struct @p.@kernel._auto_tuning_param_t { "; \
			print "\tint\tBLOCK_SIZE, GY, VX, UX, MULTI, MX; "; \
			print "} PARAM["id+1"] = {"; \
				for(i=1;i<id;i++) { \
					print "\t{ "BLOCK_SIZE[i]", "GY[i]", "VX[i]", "UX[i]", "MULTI[i]", "MX[i]" },"; \
				} \
			print "\t{ 0, 0, 0, 0, 0, 0 }\n};"; \
			print "#endif"; \
			print "//=========="; \
			print "switch ( BLK ) {"; \
			for(i=1;i<id;i++) { \
				print "#if KERNEL_"i; \
				print "case "i":"; \
				print "\tAPI_private(HESYMV@lu._ATOMIC__host) < GPU_ARCH, scalar_t, "BLOCK_SIZE[i]", "GY[i]", "VX[i]", "UX[i]", "MULTI[i]", "MX[i]" >"; \
				print "\t\t( n, a, lda, x, incx, y, incy, alpha, beta ); break;"; \
				print "#endif"; \
			} \
			print "default:"; \
			print "\tbreak;"; \
			print "}"; \
			print "//=========="; \
			print "}"; \
		} \
	' > @p.@kernel.-@luop.-auto.h
\rm @p.@kernel.-@luop.-auto2.h
touch @p.@kernel.-@luop.-auto2.h
awk ' \
	BEGIN{ \
		for(i=0;i<=20;i++) print "#define\tKERNEL_"i"\t1"; \
		exit; \
	} \
	' > @p.@kernel.-@luop.-auto2.h
cp @p.@kernel.-@luop.-auto.h ../
cp @p.@kernel.-@luop.-auto2.h ../

cat -n top20

Make >& /dev/null

	ID_max=16
if [ x$ASPEN_TUNING_LEVEL = xROUGH ]; then
	ID_max=10
fi
if [ x$ASPEN_TUNING_LEVEL = xFULL ]; then
	ID_max=20
fi
	ID_list=" 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 "

\rm log-@p.@kernel.-AV
for ID in \
	$ID_list
do
  if [ $ID -le $ID_max ]; then

  POINT=`awk 'BEGIN{ X=0; }{ if (NR=='$ID' && $1~/[0-9]/) { X=$1; exit; } }END{ gsub(/[0-9]*::/,"",X); print X; }' top20`
  if [ $POINT -gt 10000 ]; then

	timeout -s KILL 3600 ../../bench/test2-@p.@kernel.-@lu. IN-exe-b $ID | tee -a log-@p.@kernel.-AV

  else

	echo '% BLK specified='$ID >> log-@p.@kernel.-AV
	awk '{ if(i==0){i=1;next;} N=$1; if(N>0)print "N= "N" 100 [s] 0 GFLOPS 0 0"; }' IN-exe-b >> log-@p.@kernel.-AV

  fi

  fi
done

for ID in \
	$ID_list
do

	touch mat_mat.$ID
	\rm mat_mat.$ID
	echo 'Fitting the Kernel.'$ID
	DO_MATLAB 1> mat_mat.$ID 2> /dev/null
        awk ' \
		BEGIN { \
			flga=0; \
		} \
		/ans/ { \
			flag=1; next; \
		} \
		/[0-9]/ { \
			if ( flag ) printf("%6d %f\n", $1, $2); \
		} \
	' mat_mat.$ID > mat.$ID

done

echo "Complete phase b3"

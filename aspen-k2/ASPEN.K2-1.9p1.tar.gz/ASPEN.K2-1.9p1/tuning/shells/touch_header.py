#! /usr/bin/env python

import sys
import os
import subprocess
import shutil
import re


def do_touch_header ( target, MACHINE_DIR, CUDA_DIR ) :

    if not os.path.exists( target ) :

        source1 = 'tuning-old/' + MACHINE_DIR + '/' + CUDA__DIR + '/' + target
        source2 = 'tuning-old/default/' + DEFAULT_CUDA + '/' + target

        if os.path.exists( source1 ) :
            print( 'Copy ' + source1 )
            shutil.copy( source1, target )
        else :
            if os.path.exists( source2 ) :
                print( 'Copy ' + source2 )
                shutil.copy( source2, target )
            else :
                if 'param' in target :
                    another = 'param-dsymvu.h'
                if 'upper-auto.h' in target :
                    another = 'dsymv-upper-auto.h'
                if 'upper-auto2.h' in target :
                    another = 'dsymv-upper-auto2.h'
                if 'lower-auto.h' in target :
                    another = 'dsymv-lower-auto.h'
                if 'lower-auto2.h' in target :
                    another = 'dsymv-lower-auto2.h'

                if 'auto2' in another :
                    print( 'Copy&modify ' + another + ' as a template' )
                    gpat = re.sub( 'mv.*', '', target )
                    cmd = 'awk \'{ gsub(/dsy/,"' + gpat + '"); print; }\' ' + another
                    with open( target, mode = 'wb' ) as outfile :
                        subprocess.call( cmd, shell = True, stdout = outfile )
                else :
                    print( 'Copy ' + another + ' as a template' )
                    shutil.copy( another, target )


if __name__ == '__main__':

    DEFAULT_CUDA = '9020'

    p_list  = [ 'w', 'd', 's', 'h', 'u', 'z', 'c', 'i128', 'i64', 'i32', 'i16' ]
    f_list  = [ 'sy', 'sy', 'sy', 'sy', 'he', 'he', 'he', 'sy', 'sy', 'sy', 'sy' ]
    lu_list = [ 'upper', 'lower' ]
    ul_list = [ 'u', 'l' ]
    h_list  = [ '@p.@f.mv-@lu.-auto.h', '@p.@f.mv-@lu.-auto2.h', 'param-@p.@f.mv@ul..h' ]


    os.chdir( '../src' )
    subprocess.call( 'make get_dev_info', shell = True )
    os.chdir( '../tuning' )

    CUDA_PATH = os.getenv( 'CUDA_PATH', default = '/usr/local/cuda' )
    LD_LIBRARY_PATH = os.getenv( 'LD_LIBRARY_PATH' )
    LD_LIBRARY_PATH = CUDA_PATH + '/lib64:+' + LD_LIBRARY_PATH
    os.environ[ 'LD_LIBRARY_PATH' ] = LD_LIBRARY_PATH

    ASPEN_GPU_ID = os.getenv( 'ASPEN_GPU_ID', default = 0 )
    cmd = '../src/get_dev_info ' + str( ASPEN_GPU_ID )
    with open( 'DEV_INFO', mode = 'wb' ) as dev_info :
        subprocess.call( cmd, shell = True, stdout = dev_info )

    CUDA = DEFAULT_CUDA
    with open( 'DEV_INFO', mode = 'r' ) as file :
        while True :
            line = file.readline()
            if not line :
                break
            if 'DEVICE=' in line :
                DEVICE = line.split()[1]
            if 'CUDA=' in line :
                CUDA = line.split()[1]

    print( 'DEVICE' + DEVICE )
    print( 'CUDA' + CUDA )

    MACHINE_DIR = 'default'
    CUDA__DIR   = DEFAULT_CUDA

    if os.path.exists( 'tuning-old/' + DEVICE ) :
        MACHINE_DIR = DEVICE
        if os.path.exists( 'tuning-old/' + MACHINE_DIR + '/' + CUDA ) :
                CUDA__DIR = CUDA
        else :
                CUDA__DIR = DEFAULT_CUDA
        print( 'The configuration files tuned for ' + DEVICE + ' with CUDA ' + CUDA__DIR + ' are adopted.' )
    else :
        MACHINE_DIR = 'default'
        print( 'The default configuration files are adopted.' )
        if os.path.exists( 'tuning-old/' + MACHINE_DIR + '/' + CUDA ) :
                CUDA__DIR = CUDA
        else :
                CUDA__DIR = DEFAULT_CUDA

    for header in h_list :
        for i in range( len( p_list ) ) :
           h1 = re.sub( '@p.', p_list[i], header )
           header_ = re.sub( '@f.', f_list[i], h1 )
           for j in range( len( lu_list ) ) :
               h2 = re.sub( '@lu.', lu_list[j], header_ )
               target = re.sub( '@ul.', ul_list[j], h2 )
               do_touch_header ( target, MACHINE_DIR, CUDA__DIR )


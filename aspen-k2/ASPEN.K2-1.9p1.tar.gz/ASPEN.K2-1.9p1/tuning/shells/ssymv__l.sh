#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for SSYMV-L'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../ssymvl__b3.sh log-*-X-X-X
/bin/sh ../ssymvl_c.sh
python ../d_filter.py ssymv-lower-auto3.h ssymv-lower-auto2.h

echo "Complete phase d"

echo '#if 0'             > ssymv-lower-auto_.h
echo_Message            >> ssymv-lower-auto_.h
cat ../DEV_INFO         >> ssymv-lower-auto_.h
echo '<--'              >> ssymv-lower-auto_.h
cat ../CURRENT_GPU      >> ssymv-lower-auto_.h
echo '-->'              >> ssymv-lower-auto_.h
echo '#endif'           >> ssymv-lower-auto_.h
cat ssymv-lower-auto.h	>> ssymv-lower-auto_.h
mv ssymv-lower-auto_.h ssymv-lower-auto.h
cp ssymv-lower-auto.h ..

echo '#if 0'             > ssymv-lower-auto_.h
echo_Message            >> ssymv-lower-auto_.h
cat ../DEV_INFO         >> ssymv-lower-auto_.h
echo '<--'              >> ssymv-lower-auto_.h
cat ../CURRENT_GPU      >> ssymv-lower-auto_.h
echo '-->'              >> ssymv-lower-auto_.h
echo '#endif'           >> ssymv-lower-auto_.h
cat ssymv-lower-auto2.h	>> ssymv-lower-auto_.h
mv ssymv-lower-auto_.h ssymv-lower-auto2.h
cp ssymv-lower-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-ssymvl.h
echo '#undef    PRESERVE_DROP'		>> param-ssymvl.h
echo '#endif'				>> param-ssymvl.h
echo '#define   PRESERVE_DROP   1'	>> param-ssymvl.h
cp param-ssymvl.h ..

cat ssymv-lower-auto.h
cat ssymv-lower-auto2.h

cd ../../src

\rm ssymv_lower.cu_o
make

cd ../bench

\rm test-s.o test2-s.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-ssymv-l IN-medium >& /dev/null
timeout -s KILL 600 ./test-ssymv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-ssymv-l IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-ssymv-l IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-ssymv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-ssymv-l IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-ssymvl

echo_Message end

exit 0


#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for ZHEMV-L'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../zhemvl__b3.sh log-*-X-X-X
/bin/sh ../zhemvl_c.sh
python ../d_filter.py zhemv-lower-auto3.h zhemv-lower-auto2.h

echo "Complete phase d"

echo '#if 0'             > zhemv-lower-auto_.h
echo_Message            >> zhemv-lower-auto_.h
cat ../DEV_INFO         >> zhemv-lower-auto_.h
echo '<--'              >> zhemv-lower-auto_.h
cat ../CURRENT_GPU      >> zhemv-lower-auto_.h
echo '-->'              >> zhemv-lower-auto_.h
echo '#endif'           >> zhemv-lower-auto_.h
cat zhemv-lower-auto.h	>> zhemv-lower-auto_.h
mv zhemv-lower-auto_.h zhemv-lower-auto.h
cp zhemv-lower-auto.h ..

echo '#if 0'             > zhemv-lower-auto_.h
echo_Message            >> zhemv-lower-auto_.h
cat ../DEV_INFO         >> zhemv-lower-auto_.h
echo '<--'              >> zhemv-lower-auto_.h
cat ../CURRENT_GPU      >> zhemv-lower-auto_.h
echo '-->'              >> zhemv-lower-auto_.h
echo '#endif'           >> zhemv-lower-auto_.h
cat zhemv-lower-auto2.h	>> zhemv-lower-auto_.h
mv zhemv-lower-auto_.h zhemv-lower-auto2.h
cp zhemv-lower-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-zhemvl.h
echo '#undef    PRESERVE_DROP'		>> param-zhemvl.h
echo '#endif'				>> param-zhemvl.h
echo '#define   PRESERVE_DROP   1'	>> param-zhemvl.h
cp param-zhemvl.h ..

cat zhemv-lower-auto.h
cat zhemv-lower-auto2.h

cd ../../src

\rm zhemv_lower.cu_o
make

cd ../bench

\rm test-z.o test2-z.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-zhemv-l IN-medium >& /dev/null
timeout -s KILL 600 ./test-zhemv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-zhemv-l IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-zhemv-l IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-zhemv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-zhemv-l IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-zhemvl

echo_Message end

exit 0


#!/bin/sh

echo_Message()
{
	echo '<--/****************************************'
	echo 'Automatic Performance Tuning for WSYMV-L'
	date
	echo -n 'Host on '; echo `hostname`
	echo 'Device is '$DEVICE
	if [ x${1} = xbegin ]; then
		echo 'Start.'
	fi
	if [ x${1} = xend ]; then
		echo 'Successfully completed.'
	fi
	if [ x${1} = xterminate ]; then
		echo 'Terminated unfortunately.'
	fi
	echo '****************************************/-->'
}


export LANG=C

if [ x${CUDA_PATH} != x ]; then
        export LD_LIBRARY_PATH=$CUDA_PATH/lib64:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH=`pwd`/../lib:$LD_LIBRARY_PATH


echo_Message begin

/bin/sh ../wsymvl__b3.sh log-*-X-X-X
/bin/sh ../wsymvl_c.sh
python ../d_filter.py wsymv-lower-auto3.h wsymv-lower-auto2.h

echo "Complete phase d"

echo '#if 0'             > wsymv-lower-auto_.h
echo_Message            >> wsymv-lower-auto_.h
cat ../DEV_INFO         >> wsymv-lower-auto_.h
echo '<--'              >> wsymv-lower-auto_.h
cat ../CURRENT_GPU      >> wsymv-lower-auto_.h
echo '-->'              >> wsymv-lower-auto_.h
echo '#endif'           >> wsymv-lower-auto_.h
cat wsymv-lower-auto.h	>> wsymv-lower-auto_.h
mv wsymv-lower-auto_.h wsymv-lower-auto.h
cp wsymv-lower-auto.h ..

echo '#if 0'             > wsymv-lower-auto_.h
echo_Message            >> wsymv-lower-auto_.h
cat ../DEV_INFO         >> wsymv-lower-auto_.h
echo '<--'              >> wsymv-lower-auto_.h
cat ../CURRENT_GPU      >> wsymv-lower-auto_.h
echo '-->'              >> wsymv-lower-auto_.h
echo '#endif'           >> wsymv-lower-auto_.h
cat wsymv-lower-auto2.h	>> wsymv-lower-auto_.h
mv wsymv-lower-auto_.h wsymv-lower-auto2.h
cp wsymv-lower-auto2.h ..

echo '#if defined(PRESERVE_DROP)'	 > param-wsymvl.h
echo '#undef    PRESERVE_DROP'		>> param-wsymvl.h
echo '#endif'				>> param-wsymvl.h
echo '#define   PRESERVE_DROP   1'	>> param-wsymvl.h
cp param-wsymvl.h ..

cat wsymv-lower-auto.h
cat wsymv-lower-auto2.h

cd ../../src

\rm wsymv_lower.cu_o
make

cd ../bench

\rm test-w.o test2-w.o
make 

echo "Complete phase e"

timeout -s KILL 4   ./test-wsymv-l IN-medium >& /dev/null
timeout -s KILL 600 ./test-wsymv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 600 ./test-wsymv-l IN-medium
fi

echo "Complete phase f1"

timeout -s KILL 4    ./test2-wsymv-l IN-medium >& /dev/null
timeout -s KILL 3600 ./test2-wsymv-l IN-medium
if [ $? -eq 137 ]; then
timeout -s KILL 3600 ./test2-wsymv-l IN-medium
fi

echo "Complete phase f2"

cd ../tuning

touch .done-wsymvl

echo_Message end

exit 0


#!/bin/sh


echo 'Shrinking the condition pattern'

cat $1 | \
	awk ' BEGIN{ pat = 0; } \
		/define/{ \
			gsub(/KERNEL_/,""); \
			i = $2; \
			BLK[i] = 1; \
		} \
		/if/{ \
			From[pat] = $5; \
			To[pat]   = $9; \
			getline; \
			gsub(/;/,"",$3); \
			Id[pat]   = $3; \
			pat++; \
		} \
		END { \
			for(j=1;j<pat-1;j++) { \
				if ( (From[j] >= 0) && (To[j] - From[j] <= 32) ) { \
					if ( Id[j-1] == Id[j+1] ) { \
						To[j] = To[j+1]; \
					for(k=j-1;k>=0;k--){ \
						To[k] = To[j+1]; \
						if ( From[k] >= 0 ) break; \
					} \
						From[j] = From[j+1] = -1; \
						id[j] = id[j-1]; \
					} \
				} \
			} \
			i = 0; \
			FROM[i] = From[i]; TO[i] = To[i]; ID[i] = Id[i]; \
			i++; \
			for(j=1;j<pat;j++) { \
				if ( From[j] >= 0 ) { \
					FROM[i] = From[j]; \
					TO[i] = To[j]; \
					ID[i] = Id[j]; \
					i++; \
				} \
			} \
			for(k in BLK) BLK[k] = 0; \
			for(j=0;j<i;j++){\
				k = ID[j]; \
				BLK[k] = 1; \
			} \
			print ""; \
			numK=0; \
			for(k in BLK) { \
				if ( BLK[k] ) { \
					KK[numK++] = k; \
				} \
			} \
			for(kk=0;kk<numK-1;kk++) { \
				for(jj=kk+1;jj<numK;jj++) { \
					k = KK[kk]*1; \
					j = KK[jj]*1; \
					if ( k > j ) { \
						t = KK[kk]; \
						KK[kk] = KK[jj]; \
						KK[jj] = t; \
					} \
				} \
			} \
			for(k in BLK) { \
				if ( BLK[k] ) { \
					print "#define\tKERNEL_"k"\t"1; \
				} \
			} \
			print ""; \
			FROM[i] = TO[i-1]; \
			TO[i]   = 100000000; \
			ID[i]   = ID[i-1]; \
			for(j=0;j<=i;j++){\
				print "if ( n >= "FROM[j]" && n < "TO[j]" ) {"; \
				print "\tBLK = "ID[j]";"; \
				if ( j < i ) \
					print "} else"; \
				else \
					print "}"; \
			} \
		} ' > $2




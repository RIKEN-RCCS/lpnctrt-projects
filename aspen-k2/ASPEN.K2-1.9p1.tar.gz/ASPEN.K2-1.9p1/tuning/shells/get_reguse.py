#! /usr/bin/env python

import sys
import os
import subprocess
import re


def byte2string( line ) :
    if sys.version_info.major > 2 :
       buf = line.decode()
    else :
       buf = line.rstrip()
    return buf

def choose( cond, yes, no ) :
    ans = yes if cond else no
    return ans

def get_params_from_Name ( Name, KERNEL_KEY ) :
    Name = re.sub( '.*'+KERNEL_KEY, '', Name )
    Name = re.sub( 'E7double2', ' ', Name )
    Name = re.sub( 'E6float2', ' ', Name )
    Name = re.sub( 'E6__half', ' ', Name )
    Name = re.sub( 'E12__cudfreal__', ' ', Name )
    Name = re.sub( 'E15__cudfcomplex__', ' ', Name )
    Name = re.sub( 'E12__cuddreal__', ' ', Name )
    Name = re.sub( 'E15__cuddcomplex__', ' ', Name )
    Name = re.sub( 'E9__int16__', ' ', Name )
    Name = re.sub( 'E10__int128__', ' ', Name )
    Name = re.sub( 'E12__bfloat16__', ' ', Name )
    Name = re.sub( '_.*', '', Name )
    Name = re.sub( '[A-Za-z]', ' ', Name )
    return Name.split()

def listsort_by_index( data ) :
    ctr = len( data )
    index = list( range( ctr ) )
    for i0 in range( ctr ) :
        i = index[i0]
        key_i = data[i][5]
        for j0 in range( i0+1, ctr ) :
            j = index[j0]
            key_j = data[j][5]
            if key_i > key_j :
               index[i0] = j
               index[j0] = i
               i = j
               key_i = key_j
    return index


if __name__ == '__main__' :

    args = sys.argv
    argc = len( args )

    if argc != 4 :
        print( 'Usage: ' + os.path.basename( args[0] ) + '  CG keyval target_cu_file' )
        quit()

    CG         = args[1]
    KERNEL_KEY = args[2]
    TARGET     = args[3]

    if not os.path.exists( TARGET ) :
        sys.stderr.write( 'Error: file "%s" not existing\n' % TARGET )
        quit()

    CUDA_PATH = os.getenv( 'CUDA_PATH', default = '/usr/local/cuda' )
    if not os.path.exists( CUDA_PATH ) :
        CUDA_PATH = '/usr/local/cuda'


    CG_lists = [
    '130', '200', '300',
    '350', '370',
    '500', '520', '530',
    '600', '610', '620',
    '700', '750'
    ]

    if CG in CG_lists :
        COMPILER_FLAGS = '-'
    else :
        COMPILER_FLAGS = '-'
        CG = '610'
    SM = CG[0:2]


    COMPILER = CUDA_PATH + '/bin/nvcc'
    COMPILER_FLAGS = '-O3 --ptxas-options=-v --maxrregcount=255 --fmad=true -I' + CUDA_PATH + '/include -I./include -I../include -I../../include -I. -arch=compute_' + SM + ' -code=compute_' + SM + ',sm_' + SM + ' --define-macro CURRENT_GPU=' + CG

    cmd = COMPILER + ' ' + COMPILER_FLAGS + ' -c ' + TARGET + ' -o /dev/null'

    proc = subprocess.Popen( cmd, shell = True, stdout = subprocess.PIPE, stderr = subprocess.STDOUT )


    data = []
    while True :
        line = proc.stdout.readline()
        if ( not line ) or ( proc.poll() is not None ) :
            break
        buf = byte2string( line )

        if not ( ( ' Function ' in buf ) and ( KERNEL_KEY in buf ) ) :
            continue

        Name = buf.split()[6]
        o = choose( 'complex__' in Name, 1, 0 )
        P = get_params_from_Name ( Name, KERNEL_KEY )
        spilled = 0

        while True :
            line = proc.stdout.readline()
            if ( not line ) or ( proc.poll() is not None ) :
                break
            buf = byte2string( line )

            if 'spill' in buf :
                Q = buf.split()
                spilled = int( Q[4] ) + int( Q[8] )
            if 'register' in buf :
                Q = buf.split()
                Registers = int( Q[4] )
                Limit = choose( int( CG ) < 350, choose( o > 0, 320, 192 ), 64 )
                s = choose( spilled > Limit, 0, choose( spilled == 0, 1, 2 ) )
                GX = int( P[1] )
                GY = int( P[2] )
                VX = int( P[3] )
                UX = int( P[4] )
                MX = int( P[5] )
                data += [ [ Registers, GX, GY, VX, UX, MX, s ] ]
                break


    index = listsort_by_index( data )

    for i in index :
        P = data[i]
        Registers = P[0]
        GX = P[1]
        GY = P[2]
        VX = P[3]
        UX = P[4]
        MX = P[5]
        s = P[6]
        print( '%4d %3d %3d %3d %3d %3d %3d' %
               ( Registers, GX, GY, VX, UX, MX, s ) )


    proc.wait()
    sys.exit( 0 )


#!/bin/sh

python ../symv_predict.py predict.data

cat predict.data | \
	awk 'BEGIN{ flag=0; }/end comment/{ flag=1; next }{ if(flag)print; }' \
	> chemv-lower-auto3.h

echo "Complete phase c"

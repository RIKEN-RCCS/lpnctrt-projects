#ifndef REDUCE_IN_BLOCK_H_INCLUDED
#define REDUCE_IN_BLOCK_H_INCLUDED	1

#if GPU_ARCH>=300

typedef struct {
  uint32_t  x;
  uint32_t  y;
} uint32_t2;

typedef struct {
  uint32_t  x;
  uint32_t  y;
  uint32_t  z;
  uint32_t  w;
} uint32_t4;

typedef struct {
  uint32_t4  x;
  uint32_t4  y;
} uint32_t4x2;


template < class TYPE >
__forceinline__ __device__ TYPE
__SHFL_xor ( const TYPE x, const int laneMask, const int width )
{
#if CUDA_VERSION >= 9000
#define SHFL_XOR( x, laneMask, width, ...)              \
  __shfl_xor_sync ( 0xffffffff, x, laneMask, width )
#else
#define SHFL_XOR( x, laneMask, width, ...)	\
  __shfl_xor ( x, laneMask, width )
#endif
  _____ TYPE xx = x;
  if ( sizeof(TYPE) == 2 ) {
    const uint16_t y = *(reinterpret_cast<uint16_t *>(&xx));
    _____ uint16_t z = SHFL_XOR ( y, laneMask, width );
    xx = *(reinterpret_cast<TYPE*>(&z));
  }
  if ( sizeof(TYPE) == 4 ) {
    const uint32_t y = *(reinterpret_cast<uint32_t *>(&xx));
    _____ uint32_t z = SHFL_XOR ( y, laneMask, width );
    xx = *(reinterpret_cast<TYPE*>(&z));
  }
  if ( sizeof(TYPE) == 8 ) {
    const uint32_t2 y = *(reinterpret_cast<uint32_t2 *>(&xx));
    _____ uint32_t2 z;
    z.x = SHFL_XOR ( y.x, laneMask, width );
    z.y = SHFL_XOR ( y.y, laneMask, width );
    xx = *(reinterpret_cast<TYPE*>(&z));
  }
  if ( sizeof(TYPE) == 16 ) {
    const uint32_t4 y = *(reinterpret_cast<uint32_t4 *>(&xx));
    _____ uint32_t4 z;
    z.x = SHFL_XOR ( y.x, laneMask, width );
    z.y = SHFL_XOR ( y.y, laneMask, width );
    z.z = SHFL_XOR ( y.z, laneMask, width );
    z.w = SHFL_XOR ( y.w, laneMask, width );
    xx = *(reinterpret_cast<TYPE*>(&z));
  }
  if ( sizeof(TYPE) == 32 ) {
    const uint32_t4x2 y = *(reinterpret_cast<uint32_t4x2 *>(&xx));
    _____ uint32_t4x2 z;
    z.x = __SHFL_xor ( y.x, laneMask, width );
    z.y = __SHFL_xor ( y.y, laneMask, width );
    xx = *(reinterpret_cast<TYPE*>(&z));
  }
  return xx;
#undef SHFL_XOR
}


// In return, if flag is true, x and y are swapped
//  int flag : flag whether swap the arguments
//  TYPE x,y : regsiters
template < class TYPE >
__forceinline__ __device__  void
Swap_Elements ( _____ TYPE &x, _____ TYPE &y, const bool flag )
{
  const TYPE z = x;
  const TYPE w = y;
  x = __choose__ ( flag, w, z );
  y = __choose__ ( flag, z, w );
}

// In return, warp-oriented sumup are stored on x0 of the first warp
// Hidden / un-passed/ implicit parameters
//  TYPE x0  : variable to be sumed up
//  TYPE w[] : work area on shared_memory : blockDim.x-32 or more
//  int  c = local_id / 32; : the warp number
template < class TYPE >
__forceinline__ __device__ void
_sumup_inter_Warp( const int w_offset, _____ TYPE &x, const int threadIdx_x, const int BLOCK_SIZE )
{
  TYPE x_ = x;
  if ( BLOCK_SIZE <= 32 ) return;
  _____ SHMEM_addr_t shmem_w = shared_memory_raw_proxy < TYPE > ( w_offset );
  const bool flag = ( threadIdx_x < 32 );
  __syncthreads ( );
  if ( !flag ) {
    Store_Volatile_Shared( shmem_w, x_ );
  }
  __syncthreads ( );
  if ( flag ) {
    const SHMEM_addr_t step    = 32*sizeof(TYPE);
    const SHMEM_addr_t shmem_e = shmem_w + BLOCK_SIZE*sizeof(TYPE) - step;
#pragma unroll 1
    do {
      shmem_w += step;
      x_ += Load_Volatile_Shared < TYPE > ( shmem_w );
    } while ( shmem_w < shmem_e );
  }
  x = x_;
}

// In return, x@mine += x@(mine^(1<<lane))
//  TYPE x   : regsiters to be summed up
//  int lane : lane , a distance of the registers sumed up
template < class TYPE >
__forceinline__ __device__ void
ADD_Default( _____ TYPE &a, const int lane )
{
  TYPE a_ = a;
  a_ += __SHFL_xor ( a_,  lane, 32 );
  a = a_;
}


#define ADD_WithSwap( a, b, lane )	_ADD_WithSwap( a, b, lane, threadIdx_x )
#define ADD_WithSwap1( a, b, lane )	_ADD_WithSwap1( a, b, lane,threadIdx_x )
#define ADD_WithSwap2( a, b, lane )	_ADD_WithSwap2( a, b, lane,threadIdx_x )
#define ADD_WithSwap3( a, b, lane )	_ADD_WithSwap3( a, b, lane,threadIdx_x )

template < class TYPE >
__forceinline__ __device__ void
_ADD_WithSwap1( _____ TYPE &a, _____ TYPE &b, const int lane, const int threadIdx_x )
{
  TYPE a_ = a, b_ = b;
  const bool flag = ( threadIdx_x & lane );
  Swap_Elements( a_, b_, flag );
  a = a_; b = b_;
}

template < class TYPE >
__forceinline__ __device__ void
_ADD_WithSwap2( _____ TYPE &a, _____ TYPE &b, const int lane, const int threadIdx_x )
{
  TYPE b_ = b;
  b_ = __SHFL_xor ( b_,  lane, 32 );
  b = b_;
}

template < class TYPE >
__forceinline__ __device__ void
_ADD_WithSwap3( _____ TYPE &a, _____ TYPE &b, const int lane, const int threadIdx_x )
{
  TYPE a_ = a, b_ = b;
  a_ += b_;
  a = a_;
}

// In return, x@{mine,(mine^(1<<lane))} += y@{(mine^(1<<lane)),mine}
//  TYPE x,y : regsiters to be summed up
//  int lane : lane , a distance of butterfly swaps
template < class TYPE >
__forceinline__ __device__ void
_ADD_WithSwap( _____ TYPE &a, _____ TYPE &b, const int lane, const int threadIdx_x )
{
  TYPE a_ = a, b_ = b;
  _ADD_WithSwap1( a_, b_, lane, threadIdx_x );
  _ADD_WithSwap2( a_, b_, lane, threadIdx_x );
  _ADD_WithSwap3( a_, b_, lane, threadIdx_x );
  a = a_; b = b_;
}


#if __isHALF__
#  define	HALFv2		half2
#  define	__HALFv2	__half2
#endif
#if __isINT16__
#  define	HALFv2		int16v2
#  define	__HALFv2	__int16v2__t_
#endif

#if __isHALF__ || __isINT16__
template < class TYPE >
__forceinline__ __device__ void
Half2_Swap( _____ TYPE &a, _____ TYPE &b )
{
#if 1
  _____ uint32_t u = *(reinterpret_cast<uint32_t *>(&(a)));
  _____ uint32_t v = *(reinterpret_cast<uint32_t *>(&(b)));
  _____ uint32_t w = __funnelshift_lc( u, u, 16 ); // [ax,ay] --> [ay,ax]
  w = __funnelshift_lc( w, v, 16 ); // [ay,ax][bx,by] --> [ax,bx]
  v = __funnelshift_lc( v, v, 16 ); // [bx,by] --> [by,bx]
  u = __funnelshift_lc( u, v, 16 ); // [ax,ay][by,bx] --> [ay,by]
  a = *(reinterpret_cast<TYPE*>(&(w)));
  b = *(reinterpret_cast<TYPE*>(&(u)));
#else
  _____ uint32_t16_t2 *u = (reinterpret_cast<uint32_t16_t2 *>(&(a)));
  _____ uint32_t16_t2 *v = (reinterpret_cast<uint32_t16_t2 *>(&(b)));
  const uint32_t16_t t = u->y; u->y = v->x; v->x = t;
  a = *(reinterpret_cast<TYPE*>(u));
  b = *(reinterpret_cast<TYPE*>(v));
#endif
}
#endif



template < class TYPE >
__device__ TYPE
reduce_in_block_non_power2 (
                            _____ TYPE x0,
                            const int threadIdx_x, const int BLOCK_SIZE,
                            const int w_offset, const int z_offset )
{
  _____ SHMEM_addr_t shmem_w = shared_memory_raw_proxy < TYPE > ( w_offset );

  __syncthreads();
  if ( threadIdx_x >= 1 ) {
    Store_Volatile_Shared ( shmem_w, x0 );
  }
  __syncthreads();

  if ( threadIdx_x < 1 ) {
    const int          step    = (int)sizeof(TYPE);
    const SHMEM_addr_t shmem_e = shmem_w + BLOCK_SIZE * sizeof(TYPE) - step;
#pragma unroll 1
    do {
      shmem_w += step;
      x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    } while ( shmem_w < shmem_e );

    if ( z_offset >= 0 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
  return x0;
}

template < class TYPE >
__device__ TYPE
reduce_in_block_power2_multiple32 (
                                   _____ TYPE x0,
                                   const int threadIdx_x, const int BLOCK_SIZE,
                                   const int w_offset,    const int z_offset )
{
  if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

  if ( BLOCK_SIZE > 32 ) {
    _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
  }

  if ( threadIdx_x < 32 ) {
    ADD_Default( x0, 1  );
    ADD_Default( x0, 2  );
    ADD_Default( x0, 4  );
    if ( BLOCK_SIZE > 8 ) {
      ADD_Default( x0, 8  );
      if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
    }
  }

  if ( z_offset >= 0 && threadIdx_x < 1 ) {
    reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
  }
  return x0;
}

template < class TYPE >
__INLINE__ __device__ TYPE
reduce_in_block (
                 _____ TYPE x0,
                 const int4 ss )
{
  const int4 tt = ss;
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    x0 = reduce_in_block_non_power2 (
                                     x0, threadIdx_x, BLOCK_SIZE, w_offset, z_offset );
  } else {
    x0 = reduce_in_block_power2_multiple32 (
                                            x0, threadIdx_x, BLOCK_SIZE, w_offset, z_offset );
  }
  return x0;
}

template < class TYPE >
__device__ void
reduce2_in_block_non_power2 (
                             _____ TYPE x0, _____ TYPE x1,
                             const int threadIdx_x, const int BLOCK_SIZE,
                             const int w_offset, const int z_offset )
{
  _____ SHMEM_addr_t shmem_w = shared_memory_raw_proxy < TYPE > ( w_offset );

  __syncthreads();
  {
    const bool flag = (threadIdx_x & 0x1);
    Swap_Elements ( x0, x1, flag );
    const int step = (int)sizeof(TYPE);
    const SHMEM_addr_t shmem_d = shmem_w + (flag ? - step : + step);
    Store_Volatile_Shared ( shmem_d, x1 );
    __syncthreads();
    x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
  }
  __syncthreads();

  if ( threadIdx_x >= 2 ) {
    Store_Volatile_Shared ( shmem_w, x0 );
  }
  __syncthreads();

  if ( threadIdx_x < 2 ) {
    const int          step    = (int)sizeof(TYPE)*2;
    const SHMEM_addr_t shmem_e = shmem_w + BLOCK_SIZE * sizeof(TYPE) - step;
#pragma unroll 1
    do {
      shmem_w += step;
      x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    } while ( shmem_w < shmem_e );

    reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
  }
}

template < class TYPE >
__device__ void
reduce2_in_block_power2_multiple32 (
                                    _____ TYPE x0, _____ TYPE x1,
                                    const int threadIdx_x, const int BLOCK_SIZE,
                                    const int w_offset,    const int z_offset )
{
  if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

  {
    ADD_WithSwap( x0, x1, 1 );
  }

  if ( BLOCK_SIZE > 32 ) {
    _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
  }

  if ( threadIdx_x < 32 ) {
    ADD_Default( x0, 2  );
    ADD_Default( x0, 4  );
    if ( BLOCK_SIZE > 8 ) {
      ADD_Default( x0, 8  );
      if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
    }
  }

  if ( threadIdx_x < 2 ) {
    reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
  }
}

template < class TYPE >
__INLINE__ __device__ void
reduce2_in_block (
                  _____ TYPE x0, _____ TYPE x1,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce2_in_block_non_power2 (
                                 x0, x1, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
  } else {
    reduce2_in_block_power2_multiple32 (
                                        x0, x1, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
  }

}


template < class TYPE >
__INLINE__ __device__ void
reduce3_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce2_in_block_non_power2 (
                                 x0, x1, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
    reduce_in_block_non_power2 (
                                x2, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+2 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
      ADD_WithSwap( x0, x1, 1 );
      ADD_Default ( x2,  1 );

      ADD_WithSwap( x0, x2, 2 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      ADD_Default( x0, 4  );
      if ( BLOCK_SIZE > 8 ) {
        ADD_Default( x0, 8  );
        if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
      }
    }

    if ( threadIdx_x < 3 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}


template < class TYPE >
__device__ void
reduce4_in_block_non_power2 (
                             _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                             const int threadIdx_x, const int BLOCK_SIZE,
                             const int w_offset, const int z_offset )
{
  _____ SHMEM_addr_t shmem_w = shared_memory_raw_proxy < TYPE > ( w_offset );

  __syncthreads();
  {
    const bool flag = (threadIdx_x & 0x1);
    const int  step = (int)sizeof(TYPE);
    const SHMEM_addr_t shmem_d = shmem_w + (flag ? - step : + step);
    Swap_Elements ( x0, x1, flag );
    Store_Volatile_Shared ( shmem_d, x1 );
    __syncthreads();
    x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    __syncthreads();
    Swap_Elements ( x2, x3, flag );
    Store_Volatile_Shared ( shmem_d, x3 );
    __syncthreads();
    x2 += Load_Volatile_Shared < TYPE > ( shmem_w );
  }
  __syncthreads();

  {
    const bool flag = (threadIdx_x & 0x2);
    const int  step = (int)sizeof(TYPE)*2;
    const SHMEM_addr_t shmem_d = shmem_w + (flag ? - step : + step);
    Swap_Elements ( x0, x2, flag );
    Store_Volatile_Shared ( shmem_d, x2 );
    __syncthreads();
    x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
  }
  __syncthreads();


  if ( threadIdx_x >= 4 ) {
    Store_Volatile_Shared ( shmem_w, x0 );
  }
  __syncthreads();

  if ( threadIdx_x < 4 ) {
    const int          step    = (int)sizeof(TYPE)*4;
    const SHMEM_addr_t shmem_e = shmem_w + BLOCK_SIZE * sizeof(TYPE) - step;
#pragma unroll 1
    do {
      shmem_w += step;
      x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    } while ( shmem_w < shmem_e );

    reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
  }
}


template < class TYPE >
__INLINE__ __device__ void
reduce4_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce4_in_block_non_power2 (
                                 x0, x1, x2, x3, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
#if __isHALF__ || __isINT16__
      _____ HALFv2 y0 = __HALFv2( x0, x2 );
      _____ HALFv2 y1 = __HALFv2( x1, x3 );
      ADD_WithSwap ( y0, y1, 1 );
      x0 = y0.x; x2 = y0.y;
#else
      ADD_WithSwap ( x0, x1, 1 );
      ADD_WithSwap ( x2, x3, 1 );
#endif
      ADD_WithSwap ( x0, x2, 2 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      ADD_Default( x0, 4  );
      if ( BLOCK_SIZE > 8 ) {
        ADD_Default( x0, 8  );
        if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
      }
    }

    if ( threadIdx_x < 4 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}

template < class TYPE >
__INLINE__ __device__ void
reduce5_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                  _____ TYPE x4,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce4_in_block_non_power2 (
                                 x0, x1, x2, x3, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
    reduce_in_block_non_power2 (
                                x4, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+4 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
#if __isHALF__ || __isINT16__
      _____ HALFv2 y0 = __HALFv2( x0, x2 );
      _____ HALFv2 y1 = __HALFv2( x1, x3 );
      ADD_WithSwap ( y0, y1, 1 );
      x0 = y0.x; x2 = y0.y;
#else
      ADD_WithSwap ( x0, x1, 1 );
      ADD_WithSwap ( x2, x3, 1 );
#endif
      ADD_Default  ( x4,  1 );

      ADD_WithSwap ( x0, x2, 2 );
      ADD_Default  ( x4,  2 );

      ADD_WithSwap ( x0, x4, 4 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      if ( BLOCK_SIZE > 8 ) {
        ADD_Default( x0, 8  );
        if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
      }
    }

    if ( threadIdx_x < 5 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}

template < class TYPE >
__INLINE__ __device__ void
reduce6_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                  _____ TYPE x4, _____ TYPE x5,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce4_in_block_non_power2 (
                                 x0, x1, x2, x3, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
    reduce2_in_block_non_power2 (
                                 x4, x5, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+4 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
#if __isHALF__ || __isINT16__
      _____ HALFv2 y0 = __HALFv2( x0, x2 );
      _____ HALFv2 y1 = __HALFv2( x1, x3 );
      ADD_WithSwap ( y0, y1, 1 );
      ADD_WithSwap ( x4, x5, 1 );
      x0 = y0.x; x2 = y0.y;
#else
      ADD_WithSwap ( x0, x1, 1 );
      ADD_WithSwap ( x2, x3, 1 );
      ADD_WithSwap ( x4, x5, 1 );
#endif
      ADD_WithSwap ( x0, x2, 2 );
      ADD_Default  ( x4, 2 );

      ADD_WithSwap ( x0, x4, 4 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      if ( BLOCK_SIZE > 8 ) {
        ADD_Default( x0, 8  );
        if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
      }
    }

    if ( threadIdx_x < 6 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}

template < class TYPE >
__INLINE__ __device__ void
reduce7_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                  _____ TYPE x4, _____ TYPE x5, _____ TYPE x6,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce4_in_block_non_power2 (
                                 x0, x1, x2, x3, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
    reduce2_in_block_non_power2 (
                                 x4, x5, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+4 );
    reduce_in_block_non_power2 (
                                x6, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+6 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
#if __isHALF__ || __isINT16__
      _____ HALFv2 y0 = __HALFv2( x0, x2 );
      _____ HALFv2 y1 = __HALFv2( x1, x3 );
      ADD_WithSwap ( y0, y1, 1 );
      ADD_WithSwap ( x4, x5, 1 );
      ADD_Default  ( x6, 1 );

      Half2_Swap( y0, y1 );
      ADD_WithSwap ( y0, y1, 2 );
      x0 = y0.x; x4 = y0.y;
#else
      ADD_WithSwap ( x0, x1, 1 );
      ADD_WithSwap ( x2, x3, 1 );
      ADD_WithSwap ( x0, x2, 2 );

      ADD_WithSwap ( x4, x5, 1 );
      ADD_Default  ( x6, 1 );
      ADD_WithSwap ( x4, x6, 2 );
#endif
      ADD_WithSwap ( x0, x4, 4 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      if ( BLOCK_SIZE > 8 ) {
        ADD_Default( x0, 8  );
        if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
      }
    }

    if ( threadIdx_x < 7 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}


template < class TYPE >
__device__ void
reduce8_in_block_non_power2 (
                             _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                             _____ TYPE x4, _____ TYPE x5, _____ TYPE x6, _____ TYPE x7,
                             const int threadIdx_x, const int BLOCK_SIZE,
                             const int w_offset, const int z_offset )
{
  _____ SHMEM_addr_t shmem_w = shared_memory_raw_proxy < TYPE > ( w_offset );

  __syncthreads();
  {
    const bool flag = (threadIdx_x & 0x1);
    const int  step = (int)sizeof(TYPE);
    const SHMEM_addr_t shmem_d = shmem_w + (flag ? - step : + step);
    Swap_Elements ( x0, x1, flag );
    Store_Volatile_Shared ( shmem_d, x1 );
    __syncthreads();
    x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    __syncthreads();
    Swap_Elements ( x2, x3, flag );
    Store_Volatile_Shared ( shmem_d, x3 );
    __syncthreads();
    x2 += Load_Volatile_Shared < TYPE > ( shmem_w );
    __syncthreads();
    Swap_Elements ( x4, x5, flag );
    Store_Volatile_Shared ( shmem_d, x5 );
    __syncthreads();
    x4 += Load_Volatile_Shared < TYPE > ( shmem_w );
    __syncthreads();
    Swap_Elements ( x6, x7, flag );
    Store_Volatile_Shared ( shmem_d, x7 );
    __syncthreads();
    x6 += Load_Volatile_Shared < TYPE > ( shmem_w );
  }
  __syncthreads();

  {
    const bool flag = (threadIdx_x & 0x2);
    const int  step = (int)sizeof(TYPE)*2;
    const SHMEM_addr_t shmem_d = shmem_w + (flag ? - step : + step);
    Swap_Elements ( x0, x2, flag );
    Store_Volatile_Shared ( shmem_d, x2 );
    __syncthreads();
    x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    __syncthreads();
    Swap_Elements ( x4, x6, flag );
    Store_Volatile_Shared ( shmem_d, x6 );
    __syncthreads();
    x4 += Load_Volatile_Shared < TYPE > ( shmem_w );
  }
  __syncthreads();

  {
    const bool flag = (threadIdx_x & 0x4);
    Swap_Elements ( x0, x4, flag );
    const int          step    = (int)sizeof(TYPE)*4;
    const SHMEM_addr_t shmem_d = shmem_w + (flag ? - step : + step);
    Store_Volatile_Shared ( shmem_d, x4 );
    __syncthreads();
    x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
  }
  __syncthreads();


  if ( threadIdx_x >= 8 ) {
    Store_Volatile_Shared ( shmem_w, x0 );
  }
  __syncthreads();

  if ( threadIdx_x < 8 ) {
    const int          step    = (int)sizeof(TYPE)*8;
    const SHMEM_addr_t shmem_e = shmem_w + BLOCK_SIZE * sizeof(TYPE) - step;
#pragma unroll 1
    do {
      shmem_w += step;
      x0 += Load_Volatile_Shared < TYPE > ( shmem_w );
    } while ( shmem_w < shmem_e );

    reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
  }
}

template < class TYPE >
__INLINE__ __device__ void
reduce8_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                  _____ TYPE x4, _____ TYPE x5, _____ TYPE x6, _____ TYPE x7,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce8_in_block_non_power2 (
                                 x0, x1, x2, x3, x4, x5, x6, x7,
                                 threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
#if __isHALF__ || __isINT16__
      _____ HALFv2 y0 = __HALFv2( x0, x2 );
      _____ HALFv2 y1 = __HALFv2( x1, x3 );
      _____ HALFv2 y2 = __HALFv2( x4, x6 );
      _____ HALFv2 y3 = __HALFv2( x5, x7 );
      ADD_WithSwap ( y0, y1, 1 );
      ADD_WithSwap ( y2, y3, 1 );

      Half2_Swap( y0, y2 );
      ADD_WithSwap ( y0, y2, 2 );
      x0 = y0.x; x4 = y0.y;
#else
      ADD_WithSwap ( x0, x1, 1 );
      ADD_WithSwap ( x2, x3, 1 );
      ADD_WithSwap ( x0, x2, 2 );

      ADD_WithSwap ( x4, x5, 1 );
      ADD_WithSwap ( x6, x7, 1 );
      ADD_WithSwap ( x4, x6, 2 );
#endif
      ADD_WithSwap ( x0, x4, 4 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      if ( BLOCK_SIZE > 8 ) {
        ADD_Default( x0, 8  );
        if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
      }
    }

    if ( threadIdx_x < 8 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}

template < class TYPE >
__INLINE__ __device__ void
reduce9_in_block (
                  _____ TYPE x0, _____ TYPE x1, _____ TYPE x2, _____ TYPE x3,
                  _____ TYPE x4, _____ TYPE x5, _____ TYPE x6, _____ TYPE x7,
                  _____ TYPE x8,
                  const int4 tt )
{
  const int threadIdx_x = tt.x;
  const int BLOCK_SIZE  = tt.y;
  const int w_offset    = tt.z;
  const int z_offset    = tt.w;

  if (  __popc(BLOCK_SIZE) > 1 && (BLOCK_SIZE % 32) ) {
    reduce8_in_block_non_power2 (
                                 x0, x1, x2, x3, x4, x5, x6, x7,
                                 threadIdx_x, BLOCK_SIZE, w_offset, z_offset+0 );
    reduce_in_block_non_power2 (
                                x8, threadIdx_x, BLOCK_SIZE, w_offset, z_offset+8 );
  } else {

    if ( BLOCK_SIZE > 32 ) { __syncthreads ( ); }

    {
#if __isHALF__ || __isINT16__
      _____ HALFv2 y0 = __HALFv2( x0, x2 );
      _____ HALFv2 y1 = __HALFv2( x1, x3 );
      _____ HALFv2 y2 = __HALFv2( x4, x6 );
      _____ HALFv2 y3 = __HALFv2( x5, x7 );
      ADD_WithSwap ( y0, y1, 1 );
      ADD_WithSwap ( y2, y3, 1 );
      ADD_Default  ( x8,  1 );

      Half2_Swap( y0, y2 );
      ADD_WithSwap ( y0, y2, 2 );
      ADD_Default  ( x8,  2 );
      x0 = y0.x; x4 = y0.y;
#else
      ADD_WithSwap ( x0, x1, 1 );
      ADD_WithSwap ( x2, x3, 1 );
      ADD_WithSwap ( x4, x5, 1 );
      ADD_WithSwap3( x6, x7, 1 );
      ADD_Default  ( x8,  1 );

      ADD_WithSwap ( x0, x2, 2 );
      ADD_WithSwap ( x4, x6, 2 );
      ADD_Default  ( x8,  2 );
#endif
      ADD_WithSwap ( x0, x4, 4 );
      ADD_Default  ( x8,  4 );

      ADD_WithSwap ( x0, x8, 8 );
    }

    if ( BLOCK_SIZE > 32 ) {
      _sumup_inter_Warp( w_offset, x0, threadIdx_x, BLOCK_SIZE );
    }

    if ( threadIdx_x < 32 ) {
      if ( BLOCK_SIZE > 16 ) ADD_Default( x0, 16 );
    }

    if ( threadIdx_x < 9 ) {
      reinterpret_cast<TYPE*>(__shmem)[z_offset] = x0;
    }
  }
}

#endif

#endif

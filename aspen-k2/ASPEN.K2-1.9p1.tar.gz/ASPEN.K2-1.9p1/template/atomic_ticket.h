#ifndef ATOMIC_TICKET_H_INCLUDED
#define ATOMIC_TICKET_H_INCLUDED	1

#include "aspen_atomic.h"


__forceinline__ __device__ void
__sync_if_ty_zero ( const int block_size )
{
  asm volatile ( "{\n\t"
                 ".reg.pred\t%pp;\n\t"

                 "setp.gt.s32\t%pp, %0, 32;\n\t"
                 "@%pp bar.sync\t0;\n\t"
                 "@!%pp bar.warp.sync\t-1;\n\t"
                 "}"
                 : : "r"(block_size) );
}

__forceinline__ __device__ void
__weaksync_init ( void )
{
  const SHMEM_addr_t mbar = shared_memory_raw_proxy_root ( );
  asm volatile ( "{\n\t"
                 ".reg.pred\t%pp;\n\t"
                 ".reg.b32\t%temp;\n\t"

                 "mov.b32\t%temp, %tid.x;\n\t"
                 "setp.lt.u32\t%pp, %temp, 4;\n\t"
                 "@%pp shl.b32\t%temp, %temp, 2;\n\t"
                 "@%pp add.u32\t%temp, %temp, %0;\n\t"
                 "@%pp st.shared.b32\t[%temp], 0;\n\t"
                 "}"
                 : : "r"(mbar) );
}


__forceinline__ __device__ void
__weaksync ( const int block_size )
{
  const int count = ((block_size-1) >> 5) + 1;
  if ( threadIdx.x < (count << 5) ) {
    const int countx = count - 1;
    if ( countx > 0 ) {
      const SHMEM_addr_t mbar = shared_memory_raw_proxy_root ( );
#if 0
      int temp, syid;
      temp = threadIdx.x;
      temp &= 0x1f;
      bool pp = (temp != 0);
      if ( ! pp ) {
        syid = Load_Shared < int > ( mbar+4 );
        asm volatile ( "atom.shared.inc.u32\t%0, [%1], %2;"
                       : "=r"(temp) : "r"(mbar), "r"(countx) );
        pp = (temp == countx);
        if ( pp ) {
          asm volatile ( "atom.shared.add.u32\t%0, [%1+4], 1;"
                         : "=r"(temp) : "r"(mbar) );
        }
      }
      temp = _ZERO_();
      if ( ! pp ) {
#pragma unroll 1
        while ( 1 ) {
          asm volatile ( "atom.shared.or.b32\t%0, [%1+4], %0;"
                         : "=r"(temp) : "r"(mbar) );
          pp = ( temp == syid );
          if ( ! pp ) break;
          temp = _ZERO_();
        }
      }
#else
      asm volatile (
                    "{\n\t"
                    ".reg.pred\t%pp;\n\t"
                    ".reg.b32\t%temp;\n\t"
                    ".reg.b32\t%syid;\n\t"

                    "mov.b32\t\t%temp, %tid.x;\n\t"
                    "and.b32\t\t%temp, %temp, 0x1f;\n\t"
                    "setp.ne.s32\t%pp, %temp, 0;\n\t"
                    "@%pp bra\tLABEL_;\n\t"

                    "atom.shared.add.u32\t%temp, [%0], 1;\n\t"
                    "add.u32\t%syid, %temp, 0x00010000;\n\t"
                    "and.b32\t%temp, %temp, 0x0000ffff;\n\t"
                    "and.b32\t%syid, %syid, 0xffff0000;\n\t"
                    "setp.eq.s32\t%pp, %temp, %1;\n\t"
                    "@%pp atom.shared.exch.b32\t%temp, [%0], %syid;\n"

                    "LABEL_:\n\t"
                    PTX_LOAD_ZERO(temp)
                    "@%pp bra\tEXIT_;\n"

                    "LOOP_:\n\t"
                    ".pragma \"nounroll\";\n\t"
                    "atom.shared.or.b32\t%temp, [%0], %temp;\n\t"
                    "setp.lt.u32\t%pp, %temp, %syid;\n\t"
                    PTX_LOAD_ZERO(temp)
                    "@%pp bra\tLOOP_;\n"

                    "EXIT_:\n\t"
                    "}"
                    : : "r"(mbar), "r"(countx) );
#endif 
    }
    __syncwarp();
  }
}

__forceinline__ __device__ void
get_Ticket_nosync ( int * Ticket, const int block_id )
{
  asm volatile ( "{\n\t"
                 ".reg.pred\t%pp;\n\t"
                 ".reg.b32\t%temp;\n\t"

                 "mov.u32\t%temp, %tid.x;\n\t"
                 "setp.eq.u32\t%pp, %temp, 0;\n"
                 "LOOP_:\n\t"
                 "@%pp atom.global.cas.b32\t%temp, [%0], %1, -1;\n\t"
                 "@%pp setp.ne.s32\t%pp, %temp, %1;\n\t"
                 "@%pp bra\tLOOP_;\n\t"
                 "}"
                 : : "l"(Ticket), "r"(block_id) );
}

__forceinline__ __device__ void
get_Ticket ( int * Ticket, const int block_id )
{
  get_Ticket_nosync ( Ticket, block_id );
  __syncthreads ( );
}

__forceinline__ __device__ void
release_Ticket_nosync ( int * Ticket, const int next_block_id )
{
  asm volatile ( "{\n\t"
                 ".reg.pred\t%pp;\n\t"
                 ".reg.b32\t%temp;\n\t"

                 "mov.u32 %temp, %tid.x;\n\t"
                 "setp.eq.u32\t%pp, %temp, 0;\n\t"
                 "@%pp red.global.and.b32\t[%0], %1;\n\t"
                 "}"
                 : : "l"(Ticket), "r"(next_block_id) );
}

__forceinline__ __device__ void
release_Ticket ( int * Ticket, const int next_block_id )
{
  __syncthreads ( );
  release_Ticket_nosync ( Ticket, next_block_id );
}

__forceinline__ __device__ void
skip_Ticket ( int * Ticket, const int block_id, const int next_block_id )
{
  if ( threadIdx.x == 0 ) {
    while ( 1 ) {
      if ( atomicCAS( Ticket, block_id, next_block_id ) == block_id ) break;
    }
  }
  __syncthreads ( );
}

__forceinline__ __device__ void
inc_Ticket ( int * Ticket )
{
  if ( threadIdx.x == 0 ) {
    pokeAdd( Ticket, 1 );
  }
  __syncthreads ( );
}

__forceinline__ __device__ void
dec_Ticket ( int * Ticket )
{
  if ( threadIdx.x == 0 ) {
    pokeAdd( Ticket, -1 );
  }
  __syncthreads ( );
}

__forceinline__ __device__ void
wait_for_Ticket ( int * Ticket, const int T )
{
  if ( threadIdx.x == 0 ) {
    while ( 1 ) {
      if ( atomicLoad( Ticket ) == T ) break;
    }
  }
  __syncthreads ( );
}

__forceinline__ __device__ void
inc_wait_for_Ticket ( int * Ticket, const int T )
{
  if ( threadIdx.x == 0 ) {
    ______ int c = atomicAdd( Ticket, 1 ) + 1;
    while ( c != T ) {
      c = atomicLoad( Ticket );
    }
  }
  __syncthreads ( );
}

__forceinline__ __device__ void
dec_wait_for_Ticket ( int * Ticket, const int T )
{
  if ( threadIdx.x == 0 ) {
    ______ int c = atomicAdd( Ticket, -1 ) - 1;
    while ( c != T ) {
      c = atomicLoad( Ticket );
    }
  }
  __syncthreads ( );
}

__forceinline__ __device__ int
look_at_Ticket_Value ( int * Ticket, int * sh_mem )
{
  __syncthreads ( );
  if ( threadIdx.x == 0 ) {
    *sh_mem = atomicLoad( Ticket );
  }
  __syncthreads ( ); const int ret = *sh_mem; __syncthreads ( );
  return ret;
}

__forceinline__ __device__ void
setup_Ticket_Value ( int * Ticket, const int value )
{
  if ( threadIdx.x == 0 ) {
    atomicExch( Ticket, value );
  }
  __syncthreads ( );
}

#endif

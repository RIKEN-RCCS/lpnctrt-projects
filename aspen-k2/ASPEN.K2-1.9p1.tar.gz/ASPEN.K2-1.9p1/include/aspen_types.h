#ifndef ASPEN_TYPES_H_INCLUDED
#define ASPEN_TYPES_H_INCLUDED	1

#include <stdint.h>
#ifdef __cplusplus
#include <cmath>
#endif

#include "aspen_real.h"
#include "aspen_complex.h"
#include "aspen_half.h"
#include "aspen_half_complex.h"
#include "aspen_ddreal.h"
#include "aspen_ddcomplex.h"
#include "aspen_dfreal.h"
#include "aspen_dfcomplex.h"
#include "aspen_int16.h"
#include "aspen_int32.h"
#include "aspen_int64.h"
#include "aspen_int128.h"
#include "aspen_bfloat16.h"

#endif


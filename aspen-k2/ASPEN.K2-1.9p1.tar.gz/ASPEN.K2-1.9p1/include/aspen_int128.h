#ifndef ASPEN_INT128_H_INCLUDED
#define ASPEN_INT128_H_INCLUDED		1

#include <stdint.h>
#include <endian.h>

#if __BYTE_ORDER == __LITTLE_ENDIAN
#define	ASPEN_INT128_struct_body                \
  uint64_t y; int64_t x
#endif
#if __BYTE_ORDER == __BIG_ENDIAN
#define	ASPEN_INT128_struct_body                \
  uint64_t x; int64_t y
#endif

typedef struct __align__(16) {
  ASPEN_INT128_struct_body;
} __int128_raw__;

#ifndef __cplusplus

typedef	__int128_raw__	int128;

#else

struct __align__(16) __int128__t_
{
  //  if big endian
  //    hi part => y     low part => x
  //  if little endian
  //    hi part => x     low part => y
  // 0x0000000000000000,0000000000000000
 private:
  ASPEN_INT128_struct_body;
 public:
  // default constructor
#if __cplusplus >= 201103L
  __int128__t_() = default;
#else
  __host__ __device__ __forceinline__
    __int128__t_() { }
#endif
  // guaranteeing transparency between __int128__ and __int128_raw__
  __host__ __device__ __forceinline__
    __int128__t_( const __int128_raw__ &h ) { x = h.x; y = h.y; }
  __host__ __device__ __forceinline__
    __int128__t_ &operator= ( const __int128_raw__ &h ) { x = h.x; y = h.y; return *this; }
  __host__ __device__ __forceinline__
    operator __int128_raw__() const { __int128_raw__ h; h.x = x; h.y = y; return h; }

  // special constructor
  __host__ __device__ __forceinline__
    __int128__t_( const int64_t &hx, const uint64_t &hy ) { x = hx; y = hy; }
  __host__ __device__ __forceinline__
    __int128__t_( const uint64_t &hx, const uint64_t &hy ) { x = (int64_t)hx; y = hy; }

  __host__ __device__ __forceinline__
    __int128_raw__ * raw( void ) { return reinterpret_cast<__int128_raw__*>(this); }

  __host__ __device__ __forceinline__
    operator double() const {
    double t = (double)x;
    t *= 1024.;
    t *= 1024.;
    t *= 1024.;
    t *= 1024.;
    t *= 1024.;
    t *= 1024.;
    t *= 16.;
    t += y;
    return t;
  }

  __host__ __device__ __forceinline__
    int64_t msb( void ) const {
    return x;
  }
  __host__ __device__ __forceinline__
    uint64_t lsb( void ) const {
    return y;
  }

  __host__ __device__ __forceinline__
    int64_t msb( const int64_t x ) {
    this->x = x; return x;
  }
  __host__ __device__ __forceinline__
    uint64_t lsb( const uint64_t y ) {
    this->y = y; return y;
  }
};

typedef struct __int128__t_	int128;
typedef        __int128_raw__	int128_raw;

//-------------------------------------------------

__host__ __device__ __forceinline__ int64_t
i128__u64_to_s64__( const uint64_t a )
{
  uint64_t aa = a;
  int64_t  bb = *(reinterpret_cast<int64_t *>(&(aa)));
  return bb;
}

__host__ __device__ __forceinline__ uint64_t
i128__s64_to_u64__( const int64_t a )
{
  int64_t  aa = a;
  uint64_t bb = *(reinterpret_cast<uint64_t *>(&(aa)));
  return bb;
}

__host__ __device__ __forceinline__ void
i128__s64_to_u32x2__( uint32_t &d1, uint32_t &d2, const int64_t s )
{
#if 0 && defined(__CUDA_ARCH__)
  asm volatile ( "mov.b64\t{%0, %1}, %2;" \
                 : "=r"(d1), "=r"(d2) : "l"(s) );
#else
#if 0
  union {
    struct {
      uint32_t s1 : 32;
      uint32_t s2 : 32;
    } c;
    int64_t s : 64;
  } c;
  c.s = s;
  d1 = c.c.s1; d2 = c.c.s2;
#else
  typedef struct { uint32_t x; uint32_t y; } uint32v2_t;
  int64_t ss = s;
  uint32v2_t dd = *(reinterpret_cast<uint32v2_t *>(&(ss)));
  d1 = dd.x; d2 = dd.y;
#endif
#endif
}

__host__ __device__ __forceinline__ void
i128__u64_to_u32x2__( uint32_t &d1, uint32_t &d2, const uint64_t s )
{
#if 0 && defined(__CUDA_ARCH__)
  asm volatile ( "mov.b64\t{%0, %1}, %2;" \
                 : "=r"(d1), "=r"(d2) : "l"(s) );
#else
#if 0
  union {
    struct {
      uint32_t s1 : 32;
      uint32_t s2 : 32;
    } c;
    uint64_t s : 64;
  } c;
  c.s = s;
  d1 = c.c.s1; d2 = c.c.s2;
#else
  typedef struct { uint32_t x; uint32_t y; } uint32v2_t;
  uint64_t ss = s;
  uint32v2_t dd = *(reinterpret_cast<uint32v2_t *>(&(ss)));
  d1 = dd.x; d2 = dd.y;
#endif
#endif
}

__host__ __device__ __forceinline__ void
i128__u64_to_u64x2__( uint64_t &d1, uint64_t &d2, const uint64_t s0 )
{
#if 0 && defined(__CUDA_ARCH__)
  asm volatile ( "and.b64\t%0, %1, 4294967295;" \
                 : "=l"(d1) : "l"(s0) );
  asm volatile ( "shr.u64\t%0, %1, 32;" \
                 : "=l"(d2) : "l"(s0) );
#else
  const uint64_t s1 = ( s0 & 0xffffffff );
  const uint64_t s2 = ( s0 >> 32 );
  d1 = s1; d2 = s2;
#endif
}

__host__ __device__ __forceinline__ void
i128__s64_to_u64x2__( uint64_t &d1, uint64_t &d2, const int64_t s0 )
{
#if 0 && defined(__CUDA_ARCH__)
  asm volatile ( "and.b64\t%0, %1, 4294967295;" \
                 : "=l"(d1) : "l"(s0) );
  asm volatile ( "shr.u64\t%0, %1, 32;" \
                 : "=l"(d2) : "l"(s0) );
#else
  const uint64_t s1 = ( s0 & 0xffffffff );
  const uint64_t s2 = ( s0 >> 32 );
  d1 = s1; d2 = s2;
#endif
}

__host__ __device__ __forceinline__ void
i128__u32x2_to_s64__( int64_t &d, const uint32_t s1, const uint32_t s2 )
{
#if defined(__CUDA_ARCH__)
  asm volatile ( "mov.b64\t%0, {%1, %2};" \
                 : "=l"(d) : "r"(s1), "r"(s2) );
#else
#if 0
  union {
    struct {
      uint32_t s1 : 32;
      uint32_t s2 : 32;
    } c;
    int64_t s : 64;
  } c;
  c.c.s1 = s1; c.c.s2 = s2;
  d = c.s;
#else
  typedef struct { uint32_t x; uint32_t y; } uint32v2_t;
  uint32v2_t ss = { s1, s2 };
  d = *(reinterpret_cast<int64_t *>(&(ss)));
#endif
#endif
}

__host__ __device__ __forceinline__ void
i128__u32x2_to_u64__( uint64_t &d, const uint32_t s1, const uint32_t s2 )
{
#if defined(__CUDA_ARCH__)
  asm volatile ( "mov.b64\t%0, {%1, %2};" \
                 : "=l"(d) : "r"(s1), "r"(s2) );
#else
#if 0
  union {
    struct {
      uint32_t s1 : 32;
      uint32_t s2 : 32;
    } c;
    uint64_t s : 64;
  } c;
  c.c.s1 = s1; c.c.s2 = s2;
  d = c.s;
#else
  typedef struct { uint32_t x; uint32_t y; } uint32v2_t;
  uint32v2_t ss = { s1, s2 };
  d = *(reinterpret_cast<uint64_t *>(&(ss)));
#endif
#endif
}

__host__ __device__ __forceinline__ void
i128__u64x2_to_s64__( int64_t &d, const uint64_t s1, const uint64_t s2 )
{
#if 0 && defined(__CUDA_ARCH__)
  asm volatile ( "bfi.b64\t%0, %1, %2, 32, 32;" \
                 : "=l"(d) : "l"(s2), "l"(s1) );
#else
#if 0
  union {
    struct {
      uint32_t s1 : 32;
      uint32_t s2 : 32;
    } c;
    int64_t s : 64;
  } c;
  c.c.s1 = (uint32_t)s1; c.c.s2 = (uint32_t)s2;
  d = c.s;
#else
  typedef struct { uint32_t x; uint32_t y; } uint32v2_t;
  uint32v2_t ss = { (uint32_t)s1, (uint32_t)s2 };
  d = *(reinterpret_cast<int64_t *>(&(ss)));
#endif
#endif
}

__host__ __device__ __forceinline__ void
i128__u64x2_to_u64__( uint64_t &d, const uint64_t s1, const uint64_t s2 )
{
#if 0 && defined(__CUDA_ARCH__)
  asm volatile ( "bfi.b64\t%0, %1, %2, 32, 32;" \
                 : "=l"(d) : "l"(s2), "l"(s1) );
#else
#if 0
  union {
    struct {
      uint32_t s1 : 32;
      uint32_t s2 : 32;
    } c;
    uint64_t s : 64;
  } c;
  c.c.s1 = (uint32_t)s1; c.c.s2 = (uint32_t)s2;
  d = c.s;
#else
  typedef struct { uint32_t x; uint32_t y; } uint32v2_t;
  uint32v2_t ss = { (uint32_t)s1, (uint32_t)s2 };
  d = *(reinterpret_cast<uint64_t *>(&(ss)));
#endif
#endif
}

//-------------------------------------------------


#if GPU_ARCH>300
__device__ __forceinline__ int128
__ldg ( const int128 * addr__ )
{
  int128_raw s_;
#if __BYTE_ORDER == __LITTLE_ENDIAN
  asm volatile ("ld.global.nc.v2.u64\t{%1,%0}, [%2];"
                : "=l"(s_.x), "=l"(s_.y) : "l"(addr__) );
#endif
#if __BYTE_ORDER == __BIG_ENDIAN
  asm volatile ("ld.global.nc.v2.u64\t{%0,%1}, [%2];"
                : "=l"(s_.x), "=l"(s_.y) : "l"(addr__) );
#endif
  return s_;
}
#endif

__host__ __device__ __forceinline__ bool
operator== ( const int128 a, const int128 b )
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  const bool ret = (a_.x == b_.x && a_.y == b_.y) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator!= ( const int128 a, const int128 b)
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  const bool ret = (a_.x == b_.x && a_.y == b_.y) ? false : true;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator< ( const int128 a, const int128 b)
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  bool ret;
  if ( a_.x == b_.x ) {
    if ( a_.y == b_.y ) {
      ret = false;
    } else {
      ret = (a_.x >= 0) ^ (a_.y >= b_.y);
    }
  } else {
    ret = (a_.x < b_.x);
  }
  return ret;
}

__host__ __device__ __forceinline__ bool
operator> ( const int128 a, const int128 b)
{
  return ( b < a );
}

__host__ __device__ __forceinline__ bool
operator<= ( const int128 a, const int128 b)
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  bool ret;
  if ( a_.x == b_.x ) {
    if ( a_.y == b_.y ) {
      ret = true;
    } else {
      ret = (a_.x >= 0) ^ (a_.y >= b_.y);
    }
  } else {
    ret = (a_.x < b_.x);
  }
  return ret;
}

__host__ __device__ __forceinline__ bool
operator>= ( const int128 a, const int128 b)
{
  return ( b <= a );
}

__host__ __device__ __forceinline__ int128
operator+ ( const int128 a )
{
  return a;
}

__host__ __device__ __forceinline__ int128
__add ( const int128 a,  const int128 b )
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  int128_raw c_;
#if defined(__CUDA_ARCH__)
  asm volatile ( "add.cc.u64\t%0, %2, %3;\n\t" \
                 "addc.u64\t%1, %4, %5;" \
                 : "=l"(c_.y),"=l"(c_.x)
                 : "l"(a_.y), "l"(b_.y), "l"(a_.x), "l"(b_.x) );
#else
  c_.y = a_.y + b_.y;
  const int64_t  carry = ( a_.y > c_.y ) ? 1 : 0;
  c_.x = a_.x + b_.x + carry;
#endif
  return  c_;
}

__host__ __device__ __forceinline__ int128
operator+ ( const int128 a, const int128 b )
{
  return __add ( a, b );
}

__host__ __device__ __forceinline__ void
operator+= ( int128 & a, const int128 b )
{
  a = __add ( a, b );
}

__host__ __device__ __forceinline__ void
add2 ( const int128 a1, const int128 b1, int128 &d1,
       const int128 a2, const int128 b2, int128 &d2 )
{
  const int128 t1 = __add ( a1, b1 );
  const int128 t2 = __add ( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int128
operator- ( const int128 a )
{
  int128_raw a_ = a;
  int128_raw c_;
#if defined(__CUDA_ARCH__)
  asm volatile ( "sub.cc.u64\t%0, 0, %2;\n\t" \
                 "subc.u64\t%1, 0, %3;" \
                 : "=l"(c_.y), "=l"(c_.x) 
                 : "l"(a_.y), "l"(a_.x) );
#else
  c_.y = i128__s64_to_u64__( -i128__u64_to_s64__( a_.y ) );
  const int64_t x1 = -a_.x;
  const int64_t x2 = ~a_.x;
  c_.x = ( a_.y == 0 ) ? x1 : x2;
#endif
  return c_;
}

__host__ __device__ __forceinline__ int128
__sub ( const int128 a,  const int128 b )
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  int128_raw c_;
#if defined(__CUDA_ARCH__)
  asm volatile ( "sub.cc.u64\t%0, %2, %3;\n\t" \
                 "subc.u64\t%1, %4, %5;" \
                 : "=l"(c_.y),"=l"(c_.x)
                 : "l"(a_.y), "l"(b_.y),
                   "l"(a_.x), "l"(b_.x) );
#else
  c_.y = a_.y - b_.y;
  const int64_t  borrow = ( a_.y < b_.y ) ? 1 : 0;
  c_.x = a_.x - b_.x - borrow;
#endif
  return  c_;
}

__host__ __device__ __forceinline__ int128
operator- ( const int128 a, const int128 b )
{
  return __sub ( a, b );
}

__host__ __device__ __forceinline__ void
operator-= (  int128 & a, const int128 b )
{
  a = __sub ( a, b );
}

__host__ __device__ __forceinline__ void
sub2 ( const int128 a1, const int128 b1, int128 &d1,
       const int128 a2, const int128 b2, int128 &d2 )
{
  const int128 t1 = __sub ( a1, b1 );
  const int128 t2 = __sub ( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
__mul_u64_wide ( const uint64_t a,  const uint64_t b, uint64_t &lo, int64_t &hi )
{
  uint64_t ay_lo;
  uint64_t ay_hi;
  uint64_t by_lo;
  uint64_t by_hi;

  uint64_t udata[2];
  uint64_t carry;

  i128__u64_to_u64x2__ ( ay_lo, ay_hi, a );
  i128__u64_to_u64x2__ ( by_lo, by_hi, b );

  udata[0] = ay_lo * by_lo;				//  0:63

  carry = udata[0] >> 32;				// 32:63
  carry += ay_hi * by_lo;				//  0:63

  udata[1] = (uint32_t)carry;				//  0:31 in 0:63
  udata[1] += ay_lo * by_hi;				//  0:63

  i128__u64x2_to_u64__ ( lo, udata[0], udata[1] );	// [0:31;0:31] -> 0:63

  carry = carry >> 32;					// 32;63 -> 0:31 in 0:63
  carry += ay_hi * by_hi;				//  0:63

  udata[1] = udata[1] >> 32;				// 32:63 -> 0:31 in 0:63
  carry = carry + udata[1];				//  0:63

  hi = i128__u64_to_s64__( carry );
}

__host__ __device__ __forceinline__ int128
__mul ( const int128 a,  const int128 b )
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  int128_raw c_;
#if defined(__CUDA_ARCH__)
  __mul_u64_wide ( a_.y, b_.y, c_.y, c_.x );
  asm volatile (
                "mad.lo.u64\t%0, %1, %4, %0;\n\t" \
                "mad.lo.u64\t%0, %2, %3, %0;" \
                : "+l"(c_.x)
                : "l"(a_.y), "l"(a_.x),
                  "l"(b_.y), "l"(b_.x) );
#else
  uint32_t ay_lo;
  uint32_t ay_hi;
  uint32_t by_lo;
  uint32_t by_hi;
  uint32_t ax_lo;
  uint32_t ax_hi;
  uint32_t bx_lo;
  uint32_t bx_hi;

  uint64_t udata[4];
  uint64_t carry[4];
  uint32_t r[4];

  i128__u64_to_u32x2__ ( ay_lo, ay_hi, a_.y );
  i128__u64_to_u32x2__ ( by_lo, by_hi, b_.y );
  i128__s64_to_u32x2__ ( ax_lo, ax_hi, a_.x );
  i128__s64_to_u32x2__ ( bx_lo, bx_hi, b_.x );

  udata[0] = ((uint64_t)ay_lo) * by_lo;
  udata[1] = ((uint64_t)ay_hi) * by_lo;
  udata[2] = ((uint64_t)ax_lo) * by_lo;
  udata[3] = ((uint64_t)ax_hi) * by_lo;

  carry[0] = udata[0];
  udata[0] = (uint32_t)carry[0];
  carry[1] = carry[0] >> 32;
  carry[1] += udata[1];
  r[1]  = (uint32_t)carry[1];
  carry[2] = carry[1] >> 32;
  carry[2] += udata[2];
  r[2]  = (uint32_t)carry[2];
  carry[3] = carry[2] >> 32;
  carry[3] += udata[3];
  r[3]  = (uint32_t)carry[3];


  udata[1] = ((uint64_t)ay_lo) * by_hi;
  udata[2] = ((uint64_t)ay_hi) * by_hi;
  udata[3] = ((uint64_t)ax_lo) * by_hi;

  carry[1] = r[1] + udata[1];
  udata[1] = carry[1];
  carry[2] = carry[1] >> 32;
  carry[2] += udata[2];
  carry[2] += r[2];
  r[2]  = (uint32_t)carry[2];
  carry[3] = carry[2] >> 32;
  carry[3] += udata[3];
  carry[3] += r[3];
  r[3]  = (uint32_t)carry[3];

  udata[3] = ((uint64_t)ay_lo) * bx_hi;
  carry[3] = r[3] + udata[3];
  udata[3] = carry[3];


  udata[2] = ((uint64_t)ay_lo) * bx_lo;
  udata[3] = ((uint64_t)ay_hi) * bx_lo;

  carry[2] = r[2] + udata[2];
  udata[2] = carry[2];
  carry[3] = carry[2] >> 32;
  udata[3] += carry[3];
  udata[3] += r[3];

  i128__u64x2_to_u64__ ( c_.y, udata[0], udata[1] );
  i128__u64x2_to_s64__ ( c_.x, udata[2], udata[3] );

#endif
  return  c_;
}

__host__ __device__ __forceinline__ int128
operator* ( const int128 a, const int128 b )
{
  return __mul ( a, b );
}

__host__ __device__ __forceinline__ void
operator*= (  int128 & a, const int128 b )
{
  a = __mul ( a, b );
}

__host__ __device__ __forceinline__ void
mul2 ( const int128 a1, const int128 b1, int128 &d1,
       const int128 a2, const int128 b2, int128 &d2 )
{
  const int128 t1 = __mul( a1, b1 );
  const int128 t2 = __mul( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int128
fma ( const int128 a, const int128 b, const int128 c )
{
  return (a * b + c);
}

__host__ __device__ __forceinline__ void
fma2 ( const int128 a1, const int128 b1, const int128 c1, int128 &d1,
       const int128 a2, const int128 b2, const int128 c2, int128 &d2 )
{
  int128 t1, t2;
  mul2 ( a1, b1, t1, a2, b2, t2 );
  add2 ( t1, c1, t1, t2, c2, t2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int
isnan ( const int128 a )
{
  return false;
}

__host__ __device__ __forceinline__ int
isinf ( const int128 a )
{
  return false;
}

__host__ __device__ __forceinline__ int
isfinite ( const int128 a )
{
  return true;
}

__host__ __device__ __forceinline__ int128
Abs ( const int128 a )
{
  return ( a.msb() >= 0 ? a : -a );
}

__host__ __device__ __forceinline__ int128
Conj ( const int128 a )
{
  return ( a );
}

__host__ __device__ __forceinline__ int128
__choose__ ( const bool flag, const int128 a, const int128 b )
{
  int128_raw a_ = a;
  int128_raw b_ = b;
  int128_raw c_;
  c_.x = ( flag ? a_.x : b_.x );
  c_.y = ( flag ? a_.y : b_.y );
  return c_;
}

__forceinline__ __device__ int128
__choose__( const int cond, const int128 case_pos, const int128 case_neg )
{
  int128_raw case_pos_ = case_pos;
  int128_raw case_neg_ = case_neg;
  int128_raw c_;
#if defined(__CUDA_ARCH__)
  asm volatile ( "slct.b64.s32\t%0, %1, %2, %3;"
                 : "=l"(c_.x)
                 : "l"(case_pos_.x), "l"(case_neg_.x), "r"(cond) );
  asm volatile ( "slct.b64.s32\t%0, %1, %2, %3;"
                 : "=l"(c_.y)
                 : "l"(case_pos_.y), "l"(case_neg_.y), "r"(cond) );
#else
  c_.x = ( cond>=0 ? case_pos_.x : case_neg_.x );
  c_.y = ( cond>=0 ? case_pos_.y : case_neg_.y );
#endif
  return c_;
}

#endif
#undef	ASPEN_INT128_struct_body

#endif


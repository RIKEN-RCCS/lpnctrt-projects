#ifndef ASPEN_H_INCLUDED
#define ASPEN_H_INCLUDED	1

#include "aspen_version.h"
#include "aspen_types.h"

#ifdef __cplusplus
extern  "C" {
#endif

  /* User must call ASPEN_init for initialization */
  int
  ASPEN_init ( const int device_id );

  /* User must finalize the ASPEN library by ASPEN_shutdown */
  int
  ASPEN_shutdown ( void );

  /* Get version info ASPEN_get_version_info */
  void
  ASPEN_get_version_info ( int *version, char *codename, char *releasedate );

  void
  ASPEN_wsymv (
               const char                uplo,
               const int                 n,
               const cuddreal            alpha,
               const cuddreal          * a,
               const int                 lda,
               const cuddreal          * x,
               const int                 incx,
               const cuddreal            beta,
               cuddreal          * y,
               const int                 incy
               );
  void
  ASPEN_dsymv (
               const char                uplo,
               const int                 n,
               const double              alpha,
               const double            * a,
               const int                 lda,
               const double            * x,
               const int                 incx,
               const double              beta,
               double            * y,
               const int                 incy
               );
  void
  ASPEN_ssymv (
               const char                uplo,
               const int                 n,
               const float               alpha,
               const float             * a,
               const int                 lda,
               const float             * x,
               const int                 incx,
               const float               beta,
               float             * y,
               const int                 incy
               );
  void
  ASPEN_hsymv (
               const char                uplo,
               const int                 n,
               const half                alpha,
               const half              * a,
               const int                 lda,
               const half              * x,
               const int                 incx,
               const half                beta,
               half              * y,
               const int                 incy
               );
  void
  ASPEN_uhemv (
               const char                uplo,
               const int                 n,
               const cuddcomplex         alpha,
               const cuddcomplex       * a,
               const int                 lda,
               const cuddcomplex       * x,
               const int                 incx,
               const cuddcomplex         beta,
               cuddcomplex       * y,
               const int                 incy
               );
  void
  ASPEN_zhemv (
               const char                uplo,
               const int                 n,
               const cuDoubleComplex     alpha,
               const cuDoubleComplex   * a,
               const int                 lda,
               const cuDoubleComplex   * x,
               const int                 incx,
               const cuDoubleComplex     beta,
               cuDoubleComplex   * y,
               const int                 incy
               );
  void
  ASPEN_chemv (
               const char                uplo,
               const int                 n,
               const cuFloatComplex      alpha,
               const cuFloatComplex    * a,
               const int                 lda,
               const cuFloatComplex    * x,
               const int                 incx,
               const cuFloatComplex      beta,
               cuFloatComplex    * y,
               const int                 incy
               );
  void
  ASPEN_khemv (
               const char                uplo,
               const int                 n,
               const cuHalfComplex       alpha,
               const cuHalfComplex     * a,
               const int                 lda,
               const cuHalfComplex     * x,
               const int                 incx,
               const cuHalfComplex       beta,
               cuHalfComplex     * y,
               const int                 incy
               );
  void
  ASPEN_i128symv (
                  const char                uplo,
                  const int                 n,
                  const int128              alpha,
                  const int128            * a,
                  const int                 lda,
                  const int128            * x,
                  const int                 incx,
                  const int128              beta,
                  int128            * y,
                  const int                 incy
                  );
  void
  ASPEN_i64symv (
                 const char                uplo,
                 const int                 n,
                 const int64               alpha,
                 const int64             * a,
                 const int                 lda,
                 const int64             * x,
                 const int                 incx,
                 const int64               beta,
                 int64             * y,
                 const int                 incy
                 );
  void
  ASPEN_i32symv (
                 const char                uplo,
                 const int                 n,
                 const int32               alpha,
                 const int32             * a,
                 const int                 lda,
                 const int32             * x,
                 const int                 incx,
                 const int32               beta,
                 int32             * y,
                 const int                 incy
                 );
  void
  ASPEN_i16symv (
                 const char                uplo,
                 const int                 n,
                 const int16               alpha,
                 const int16             * a,
                 const int                 lda,
                 const int16             * x,
                 const int                 incx,
                 const int16               beta,
                 int16             * y,
                 const int                 incy
                 );

  void
  ASPEN_waxpy (
               const int                 n,
               const cuddreal            alpha,
               const cuddreal          * x,
               const int                 incx,
               cuddreal          * y,
               const int                 incy
               );
  void
  ASPEN_daxpy (
               const int                 n,
               const double              alpha,
               const double            * x,
               const int                 incx,
               double            * y,
               const int                 incy
               );
  void
  ASPEN_saxpy (
               const int                 n,
               const float               alpha,
               const float             * x,
               const int                 incx,
               float             * y,
               const int                 incy
               );
  void
  ASPEN_haxpy (
               const int                 n,
               const half                alpha,
               const half              * x,
               const int                 incx,
               half              * y,
               const int                 incy
               );
  void
  ASPEN_uaxpy (
               const int                 n,
               const cuddcomplex         alpha,
               const cuddcomplex       * x,
               const int                 incx,
               cuddcomplex       * y,
               const int                 incy
               );
  void
  ASPEN_zaxpy (
               const int                 n,
               const cuDoubleComplex     alpha,
               const cuDoubleComplex   * x,
               const int                 incx,
               cuDoubleComplex   * y,
               const int                 incy
               );
  void
  ASPEN_caxpy (
               const int                 n,
               const cuFloatComplex      alpha,
               const cuFloatComplex    * x,
               const int                 incx,
               cuFloatComplex    * y,
               const int                 incy
               );
  void
  ASPEN_kaxpy (
               const int                 n,
               const cuHalfComplex       alpha,
               const cuHalfComplex     * x,
               const int                 incx,
               cuHalfComplex     * y,
               const int                 incy
               );
  void
  ASPEN_i128axpy (
                  const int                 n,
                  const int128              alpha,
                  const int128            * x,
                  const int                 incx,
                  int128            * y,
                  const int                 incy
                  );
  void
  ASPEN_i64axpy (
                 const int                 n,
                 const int64               alpha,
                 const int64             * x,
                 const int                 incx,
                 int64             * y,
                 const int                 incy
                 );
  void
  ASPEN_i32axpy (
                 const int                 n,
                 const int32               alpha,
                 const int32             * x,
                 const int                 incx,
                 int32             * y,
                 const int                 incy
                 );
  void
  ASPEN_i16axpy (
                 const int                 n,
                 const int16               alpha,
                 const int16             * x,
                 const int                 incx,
                 int16             * y,
                 const int                 incy
                 );

  void
  ASPEN_waxpby (
                const int                 n,
                const cuddreal            alpha,
                const cuddreal          * x,
                const int                 incx,
                const cuddreal            beta,
                cuddreal          * y,
                const int                 incy
                );
  void
  ASPEN_daxpby (
                const int                 n,
                const double              alpha,
                const double            * x,
                const int                 incx,
                const double              beta,
                double            * y,
                const int                 incy
                );
  void
  ASPEN_saxpby (
                const int                 n,
                const float               alpha,
                const float             * x,
                const int                 incx,
                const float               beta,
                float             * y,
                const int                 incy
                );
  void
  ASPEN_haxpby (
                const int                 n,
                const half                alpha,
                const half              * x,
                const int                 incx,
                const half                beta,
                half              * y,
                const int                 incy
                );
  void
  ASPEN_uaxpby (
                const int                 n,
                const cuddcomplex         alpha,
                const cuddcomplex       * x,
                const int                 incx,
                const cuddcomplex         beta,
                cuddcomplex       * y,
                const int                 incy
                );
  void
  ASPEN_zaxpby (
                const int                 n,
                const cuDoubleComplex     alpha,
                const cuDoubleComplex   * x,
                const int                 incx,
                const cuDoubleComplex     beta,
                cuDoubleComplex   * y,
                const int                 incy
                );
  void
  ASPEN_caxpby (
                const int                 n,
                const cuFloatComplex      alpha,
                const cuFloatComplex    * x,
                const int                 incx,
                const cuFloatComplex      beta,
                cuFloatComplex    * y,
                const int                 incy
                );
  void
  ASPEN_kaxpby (
                const int                 n,
                const cuHalfComplex       alpha,
                const cuHalfComplex     * x,
                const int                 incx,
                const cuHalfComplex       beta,
                cuHalfComplex     * y,
                const int                 incy
                );
  void
  ASPEN_i128axpby (
                   const int                 n,
                   const int128              alpha,
                   const int128            * x,
                   const int                 incx,
                   const int128              beta,
                   int128            * y,
                   const int                 incy
                   );
  void
  ASPEN_i64axpby (
                  const int                 n,
                  const int64               alpha,
                  const int64             * x,
                  const int                 incx,
                  const int64               beta,
                  int64             * y,
                  const int                 incy
                  );
  void
  ASPEN_i32axpby (
                  const int                 n,
                  const int32               alpha,
                  const int32             * x,
                  const int                 incx,
                  const int32               beta,
                  int32             * y,
                  const int                 incy
                  );
  void
  ASPEN_i16axpby (
                  const int                 n,
                  const int16               alpha,
                  const int16             * x,
                  const int                 incx,
                  const int16               beta,
                  int16             * y,
                  const int                 incy
                  );

  void
  ASPEN_wswap (
               const int                 n,
               cuddreal          * x,
               const int                 incx,
               cuddreal          * y,
               const int                 incy
               );
  void
  ASPEN_dswap (
               const int                 n,
               double            * x,
               const int                 incx,
               double            * y,
               const int                 incy
               );
  void
  ASPEN_sswap (
               const int                 n,
               float             * x,
               const int                 incx,
               float             * y,
               const int                 incy
               );
  void
  ASPEN_hswap (
               const int                 n,
               half              * x,
               const int                 incx,
               half              * y,
               const int                 incy
               );
  void
  ASPEN_uswap (
               const int                 n,
               cuddcomplex       * x,
               const int                 incx,
               cuddcomplex       * y,
               const int                 incy
               );
  void
  ASPEN_zswap (
               const int                 n,
               cuDoubleComplex   * x,
               const int                 incx,
               cuDoubleComplex   * y,
               const int                 incy
               );
  void
  ASPEN_cswap (
               const int                 n,
               cuFloatComplex    * x,
               const int                 incx,
               cuFloatComplex    * y,
               const int                 incy
               );
  void
  ASPEN_kswap (
               const int                 n,
               cuHalfComplex     * x,
               const int                 incx,
               cuHalfComplex     * y,
               const int                 incy
               );
  void
  ASPEN_i128swap (
                  const int                 n,
                  int128            * x,
                  const int                 incx,
                  int128            * y,
                  const int                 incy
                  );
  void
  ASPEN_i64swap (
                 const int                 n,
                 int64             * x,
                 const int                 incx,
                 int64             * y,
                 const int                 incy
                 );
  void
  ASPEN_i32swap (
                 const int                 n,
                 int32             * x,
                 const int                 incx,
                 int32             * y,
                 const int                 incy
                 );
  void
  ASPEN_i16swap (
                 const int                 n,
                 int16             * x,
                 const int                 incx,
                 int16             * y,
                 const int                 incy
                 );

  void
  ASPEN_wcopy (
               const int                 n,
               const cuddreal          * x,
               const int                 incx,
               cuddreal          * y,
               const int                 incy
               );
  void
  ASPEN_dcopy (
               const int                 n,
               const double            * x,
               const int                 incx,
               double            * y,
               const int                 incy
               );
  void
  ASPEN_scopy (
               const int                 n,
               const float             * x,
               const int                 incx,
               float             * y,
               const int                 incy
               );
  void
  ASPEN_hcopy (
               const int                 n,
               const half              * x,
               const int                 incx,
               half              * y,
               const int                 incy
               );
  void
  ASPEN_ucopy (
               const int                 n,
               const cuddcomplex       * x,
               const int                 incx,
               cuddcomplex       * y,
               const int                 incy
               );
  void
  ASPEN_zcopy (
               const int                 n,
               const cuDoubleComplex   * x,
               const int                 incx,
               cuDoubleComplex   * y,
               const int                 incy
               );
  void
  ASPEN_ccopy (
               const int                 n,
               const cuFloatComplex    * x,
               const int                 incx,
               cuFloatComplex    * y,
               const int                 incy
               );
  void
  ASPEN_kcopy (
               const int                 n,
               const cuHalfComplex     * x,
               const int                 incx,
               cuHalfComplex     * y,
               const int                 incy
               );
  void
  ASPEN_i128copy (
                  const int                 n,
                  const int128            * x,
                  const int                 incx,
                  int128            * y,
                  const int                 incy
                  );
  void
  ASPEN_i64copy (
                 const int                 n,
                 const int64             * x,
                 const int                 incx,
                 int64             * y,
                 const int                 incy
                 );
  void
  ASPEN_i32copy (
                 const int                 n,
                 const int32             * x,
                 const int                 incx,
                 int32             * y,
                 const int                 incy
                 );
  void
  ASPEN_i16copy (
                 const int                 n,
                 const int16             * x,
                 const int                 incx,
                 int16             * y,
                 const int                 incy
                 );

  void
  ASPEN_wscal (
               const int                 n,
               const cuddreal            alpha,
               cuddreal          * x,
               const int                 incx
               );
  void
  ASPEN_dscal (
               const int                 n,
               const double              alpha,
               double            * x,
               const int                 incx
               );
  void
  ASPEN_sscal (
               const int                 n,
               const float               alpha,
               float             * x,
               const int                 incx
               );
  void
  ASPEN_hscal (
               const int                 n,
               const half                alpha,
               half              * x,
               const int                 incx
               );
  void
  ASPEN_uscal (
               const int                 n,
               const cuddcomplex         alpha,
               cuddcomplex       * x,
               const int                 incx
               );
  void
  ASPEN_zscal (
               const int                 n,
               const cuDoubleComplex     alpha,
               cuDoubleComplex   * x,
               const int                 incx
               );
  void
  ASPEN_cscal (
               const int                 n,
               const cuFloatComplex      alpha,
               cuFloatComplex    * x,
               const int                 incx
               );
  void
  ASPEN_kscal (
               const int                 n,
               const cuHalfComplex       alpha,
               cuHalfComplex     * x,
               const int                 incx
               );
  void
  ASPEN_i128scal (
                  const int                 n,
                  const int128              alpha,
                  int128            * x,
                  const int                 incx
                  );
  void
  ASPEN_i64scal (
                 const int                 n,
                 const int64               alpha,
                 int64             * x,
                 const int                 incx
                 );
  void
  ASPEN_i32scal (
                 const int                 n,
                 const int32               alpha,
                 int32             * x,
                 const int                 incx
                 );
  void
  ASPEN_i16scal (
                 const int                 n,
                 const int16               alpha,
                 int16             * x,
                 const int                 incx
                 );

  void
  ASPEN_WZERO (
               cuddreal          * x,
               const int                 n 
               );
  void
  ASPEN_DZERO (
               double            * x,
               const int                 n 
               );
  void
  ASPEN_SZERO (
               float             * x,
               const int                 n 
               );
  void
  ASPEN_HZERO (
               half              * x,
               const int                 n 
               );
  void
  ASPEN_UZERO (
               cuddcomplex       * x,
               const int                 n 
               );
  void
  ASPEN_ZZERO (
               cuDoubleComplex   * x,
               const int                 n 
               );
  void
  ASPEN_CZERO (
               cuFloatComplex    * x,
               const int                 n 
               );
  void
  ASPEN_KZERO (
               cuHalfComplex     * x,
               const int                 n 
               );
  void
  ASPEN_I128ZERO (
                  int128            * x,
                  const int                 n 
                  );
  void
  ASPEN_I64ZERO (
                 int64             * x,
                 const int                 n 
                 );
  void
  ASPEN_I32ZERO (
                 int32             * x,
                 const int                 n 
                 );
  void
  ASPEN_I16ZERO (
                 int16             * x,
                 const int                 n 
                 );

#ifdef __cplusplus
}
#endif

#endif 

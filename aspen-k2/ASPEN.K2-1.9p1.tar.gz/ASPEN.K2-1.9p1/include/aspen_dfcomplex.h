#ifndef ASPEN_DFCOMPLEX_H_INCLUDED
#define ASPEN_DFCOMPLEX_H_INCLUDED		1

#include <stdint.h>
#include <cuComplex.h>
#include "aspen_ddreal.h"

#define	ASPEN_DFCOMPLEX_struct_body             \
  cudfreal x; cudfreal y

typedef struct __align__(16) {
  ASPEN_DFCOMPLEX_struct_body;
} __cudfcomplex_raw__;

#ifndef __cplusplus

typedef	__cudfcomplex_raw__	cudfcomplex_raw;
typedef	__cudfcomplex_raw__	cudfcomplex;

#else

struct __align__(16) __cudfcomplex__
{
 private:
  ASPEN_DFCOMPLEX_struct_body;
 public:
#if __cplusplus >= 201103L
  __cudfcomplex__() = default;
#else
  __host__ __device__ __forceinline__
    __cudfcomplex__() { }
#endif
  __host__ __device__ __forceinline__
    __cudfcomplex__( const __cudfcomplex_raw__ &h ) { x = h.x; y = h.y; }
  __host__ __device__ __forceinline__
    __cudfcomplex__ &operator= ( const __cudfcomplex_raw__ &h ) { x = h.x; y = h.y; return *this; }
  __host__ __device__ __forceinline__
    operator __cudfcomplex_raw__() const { __cudfcomplex_raw__ h; h.x = x; h.y = y; return h; }

  __host__ __device__ __forceinline__
    __cudfcomplex__( const cudfreal &a, const cudfreal &b ) { x = a; y = b; }

  __host__ __device__ __forceinline__
    operator cudfreal() const {
    return x;
  }

  __host__ __device__ __forceinline__
    operator cuFloatComplex() const {
    const cudfreal_raw x_ = x;
    const cudfreal_raw y_ = y;
    const cuFloatComplex t = { x_.x, y_.x };
    return t;
  }

  __host__ __device__ __forceinline__
    cudfreal real() const {
    return x;
  }
  __host__ __device__ __forceinline__
    cudfreal imag() const {
    return y;
  }
  __host__ __device__ __forceinline__
    cudfreal real(const cudfreal x) {
    this->x = x; return x;
  }
  __host__ __device__ __forceinline__
    cudfreal imag(const cudfreal y) {
    this->y = y; return y;
  }
};

typedef	struct __cudfcomplex__		cudfcomplex;
typedef	       __cudfcomplex_raw__	cudfcomplex_raw;


#if GPU_ARCH>300
__device__ __forceinline__ cudfcomplex
__ldg ( const cudfcomplex * a )
{
  cudfcomplex * aa = (cudfcomplex *)a;
  cudfcomplex_raw * p_ = (reinterpret_cast<cudfcomplex_raw *>(aa));
  cudfcomplex_raw t_;
  t_.x = __ldg( (cudfreal *)&(p_->x) );
  t_.y = __ldg( (cudfreal *)&(p_->y) );
  return t_;
}
#endif


__device__ __forceinline__ cudfreal
get_real( cudfcomplex &a )
{ return a.real(); }

__device__ __forceinline__ cudfreal
get_imag( cudfcomplex &a )
{ return a.imag(); }

__device__ __forceinline__ void
set_real( cudfcomplex &a, const cudfreal x )
{ a.real( x ); }

__device__ __forceinline__ void
set_imag( cudfcomplex &a, const cudfreal y )
{ a.imag( y ); }


__host__ __device__ __forceinline__ bool
operator== ( const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  const bool ret = ((a_.x == b_.x) && (a_.y == b_.y)) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator!= ( const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  const bool ret = ((a_.x != b_.x) || (a_.y != b_.y)) ? true : false;
  return ret;
}


__host__ __device__ __forceinline__ cudfcomplex
operator+ ( const cudfcomplex a )
{
  return (a);
}

__host__ __device__ __forceinline__ cudfcomplex
operator+ ( const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  cudfcomplex_raw t_;
  add2 ( a_.x, b_.x, t_.x,  a_.y, b_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ void
operator+= ( cudfcomplex &a, const cudfcomplex b )
{
  a = (a + b);
}

__host__ __device__ __forceinline__ cudfcomplex
operator- ( const cudfcomplex a )
{
  const cudfcomplex_raw a_ = a;
  cudfcomplex_raw t_ = a_;
  t_.x = - t_.x;
  t_.y = - t_.y;
  return t_;
}

__host__ __device__ __forceinline__ cudfcomplex
operator- ( const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  cudfcomplex_raw t_;
  sub2 ( a_.x, b_.x, t_.x,  a_.y, b_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ void
operator-= ( cudfcomplex &a, const cudfcomplex b )
{
  a = (a - b);
}

__host__ __device__ __forceinline__ cudfcomplex
operator* ( const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  cudfcomplex_raw t_;
  cudfreal e = -a_.y;
  mul2 ( a_.x, b_.x, t_.x,  a_.x, b_.y, t_.y );
  fma2 ( e,    b_.y, t_.x, t_.x,  a_.y, b_.x, t_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cudfcomplex
operator* ( const cudfcomplex a, const cudfreal b )
{
  const cudfcomplex_raw a_ = a;
  cudfcomplex_raw t_;
  mul2 ( a_.x, b, t_.x,  a_.y, b, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cudfcomplex
operator* ( const cudfreal a, const cudfcomplex b )
{
  cudfcomplex t = (b * a);
  return t;
}

__host__ __device__ __forceinline__ void
operator*= ( cudfcomplex &a, const cudfcomplex b )
{
  a = (a * b);
}

__host__ __device__ __forceinline__ void
operator*= ( cudfcomplex &a, const cudfreal b )
{
  a = (a * b);
}

__host__ __device__ __forceinline__ cudfcomplex
fma ( const cudfcomplex a, const cudfcomplex b, const cudfcomplex c )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  const cudfcomplex_raw c_ = c;
  cudfcomplex_raw t_;
  cudfreal e = -a_.y;
  fma2 ( a_.x, b_.x, c_.x, t_.x,  a_.x, b_.y, c_.y, t_.y );
  fma2 ( e,    b_.y, t_.x, t_.x,  a_.y, b_.x, t_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cudfcomplex
fma ( const cudfcomplex a, const cudfreal b, const cudfcomplex c )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw c_ = c;
  cudfcomplex_raw t_;
  fma2 ( a_.x, b, c_.x, t_.x,  a_.y, b, c_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cudfcomplex
fma ( const cudfreal a, const cudfcomplex b, const cudfcomplex c )
{
  cudfcomplex t = fma( b, a, c );
  return t;
}

__host__ __device__ __forceinline__ cudfcomplex
CUWDIV ( const cudfcomplex a, const cudfcomplex b )
{
  /*
   * almost similar approach to divide a complex number as cuComplex.h
   */
  const cudfreal     ZERO_   = __cudfreal__( (float)0, (float)0 );
  const cudfcomplex  ZERO    = __cudfcomplex__( ZERO_, ZERO_ );
  const cudfreal     NAN_DF  = __cudfreal__( NAN, NAN );
  const cudfcomplex  NAN_DFC = __cudfcomplex__( NAN_DF, NAN_DF );
  const cudfreal     ONE_    = __cudfreal__( (float)1, (float)0 );
  const cudfcomplex  ONE     = __cudfcomplex__( ONE_, ZERO_ );
  const cudfreal     MONE_   = __cudfreal__( (float)1, (float)0 );
  const cudfcomplex  MONE    = __cudfcomplex__( MONE_, ZERO_ );

  if ( b == ZERO ) { return NAN_DFC; }
  if ( a == ZERO ) { return ZERO; }
  if ( b == ONE  ) { return a; }
  if ( b == MONE ) { return -a; }

  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;

  cudfreal s = Abs(b_.x) + Abs(b_.y);
  cudfreal r = ONE_ / s;
  const cudfreal ar = a_.x * r;
  const cudfreal ai = a_.y * r;
  const cudfreal br = b_.x * r;
  const cudfreal bi = b_.y * r;
  s = (br * br) + (bi * bi);
  r = ONE_ / s;
  const cudfcomplex t = __cudfcomplex__(
                                        ((ar * br) + (ai * bi)) * r,
                                        ((ai * br) - (ar * bi)) * r );
  return t;
}

__host__ __device__ __forceinline__ cudfcomplex
operator/ ( const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex t = CUWDIV ( a, b );
  return t;
}

__host__ __device__ __forceinline__ void
operator/= ( cudfcomplex &a, const cudfcomplex b )
{
  a = ( a / b );
}


__host__ __device__ __forceinline__ void
add2 ( const cudfcomplex a1, const cudfcomplex b1, cudfcomplex &d1,
       const cudfcomplex a2, const cudfcomplex b2, cudfcomplex &d2 )
{
  const cudfcomplex_raw a1_ = a1;
  const cudfcomplex_raw a2_ = a2;
  const cudfcomplex_raw b1_ = b1;
  const cudfcomplex_raw b2_ = b2;
  cudfcomplex_raw t1_, t2_;
  add2 ( a1_.x, b1_.x, t1_.x,  a2_.x, b2_.x, t2_.x );
  add2 ( a1_.y, b1_.y, t1_.y,  a2_.y, b2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ void
sub2 ( const cudfcomplex a1, const cudfcomplex b1, cudfcomplex &d1,
       const cudfcomplex a2, const cudfcomplex b2, cudfcomplex &d2 )
{
  const cudfcomplex_raw a1_ = a1;
  const cudfcomplex_raw a2_ = a2;
  const cudfcomplex_raw b1_ = b1;
  const cudfcomplex_raw b2_ = b2;
  cudfcomplex_raw t1_, t2_;
  sub2 ( a1_.x, b1_.x, t1_.x,  a2_.x, b2_.x, t2_.x );
  sub2 ( a1_.y, b1_.y, t1_.y,  a2_.y, b2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ void
mul2 ( const cudfcomplex a1, const cudfcomplex b1, cudfcomplex &d1,
       const cudfcomplex a2, const cudfcomplex b2, cudfcomplex &d2 )
{
  const cudfcomplex_raw a1_ = a1;
  const cudfcomplex_raw a2_ = a2;
  const cudfcomplex_raw b1_ = b1;
  const cudfcomplex_raw b2_ = b2;
  cudfcomplex_raw t1_, t2_;
  cudfreal e1 = -a1_.y, e2 = -a2_.y;
  mul2 ( a1_.x, b1_.x, t1_.x,  a2_.x, b2_.x, t2_.x );
  mul2 ( a1_.x, b1_.y, t1_.y,  a2_.x, b2_.y, t2_.y );
  fma2 ( e1,    b1_.y, t1_.x, t1_.x,  e2,    b1_.y, t2_.x, t2_.x );
  fma2 ( a1_.y, b1_.x, t1_.y, t1_.y,  a2_.y, b1_.x, t2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ void
fma2 ( const cudfcomplex a1, const cudfcomplex b1, const cudfcomplex c1, cudfcomplex &d1,
       const cudfcomplex a2, const cudfcomplex b2, const cudfcomplex c2, cudfcomplex &d2 )
{
  const cudfcomplex_raw a1_ = a1;
  const cudfcomplex_raw a2_ = a2;
  const cudfcomplex_raw b1_ = b1;
  const cudfcomplex_raw b2_ = b2;
  const cudfcomplex_raw c1_ = c1;
  const cudfcomplex_raw c2_ = c2;
  cudfcomplex_raw t1_, t2_;
  cudfreal e1 = -a1_.y, e2 = -a2_.y;
  fma2( a1_.x, b1_.x, c1_.x, t1_.x,  a2_.x, b2_.x, c2_.x, t2_.x );
  fma2( a1_.x, b1_.y, c1_.y, t1_.y,  a2_.x, b2_.y, c2_.y, t2_.y );
  fma2( e1,    b1_.y, t1_.x, t1_.x,  e2,    b2_.y, t2_.x, t2_.x );
  fma2( a1_.y, b1_.x, t1_.y, t1_.y,  a2_.y, b2_.x, t2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ int
isnan ( const cudfcomplex a )
{
  const cudfcomplex_raw a_ = a;
  return (isnan(a_.x) || isnan(a_.y));
}

__host__ __device__ __forceinline__ int
isinf ( const cudfcomplex a )
{
  const cudfcomplex_raw a_ = a;
  return (isinf(a_.x) || isinf(a_.y));
}

__host__ __device__ __forceinline__ int
isfinite ( const cudfcomplex a )
{
  const cudfcomplex_raw a_ = a;
  return (isfinite(a_.x) && isfinite(a_.y));
}

__host__ __device__ __forceinline__ cudfreal
Abs ( const cudfcomplex a )
{
  const cudfcomplex_raw a_ = a;
  const cudfreal r2 = a_.x*a_.x + a_.y*a_.y;
  const cudfreal t = Sqrt( r2 );
  return t;
}

__host__ __device__ __forceinline__ cudfcomplex
Conj ( const cudfcomplex a )
{
  cudfcomplex_raw t_ = a;
  t_.x =   t_.x;
  t_.y = - t_.y;
  return t_;
}

__host__ __device__ __forceinline__ cudfcomplex
__choose__ ( const bool flag, const cudfcomplex a, const cudfcomplex b )
{
  const cudfcomplex_raw a_ = a;
  const cudfcomplex_raw b_ = b;
  cudfcomplex_raw t_;
  t_.x = __choose__( flag, a_.x, b_.x );
  t_.y = __choose__( flag, a_.y, b_.y );
  return t_;
}

__forceinline__ __device__ cudfcomplex
__select__( const int cond, const cudfcomplex case_pos, const cudfcomplex case_neg )
{
  const cudfcomplex_raw case_pos_ = case_pos;
  const cudfcomplex_raw case_neg_ = case_neg;
  cudfcomplex_raw t_;
  t_.x = __select__( cond, case_pos_.x, case_neg_.x );
  t_.y = __select__( cond, case_pos_.y, case_neg_.y );
  return t_;
}
#endif
#undef	ASPEN_DFCOMPLEX_struct_body

#endif


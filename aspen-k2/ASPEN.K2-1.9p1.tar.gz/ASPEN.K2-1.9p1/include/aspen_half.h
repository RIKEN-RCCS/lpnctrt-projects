#ifndef ASPEN_HALF_H_INCLUDED
#define ASPEN_HALF_H_INCLUDED	1

#include <cuda.h>

#if defined(ASPEN_HALF_ENABLED)
#  undef ASPEN_HALF_ENABLED
#endif

#if defined(__NVCC__)
#  include <cuda.h>
#  if defined(CURRENT_GPU)
#    if CURRENT_GPU==530 ||                     \
  CURRENT_GPU==600 || CURRENT_GPU==620 ||       \
  CURRENT_GPU==700 || CURRENT_GPU==750 ||       \
  CURRENT_GPU==800 || CURRENT_GPU==860
#      if CUDA_VERSION>7000
#        define ASPEN_HALF_ENABLED	1
#      else
#        define ASPEN_HALF_ENABLED	0
#      endif
#    else
#      if CURRENT_GPU==610 && CUDA_VERSION>11000
#        define ASPEN_HALF_ENABLED	1
#      else
#        define ASPEN_HALF_ENABLED	0
#      endif
#    endif
#  else
#    define ASPEN_HALF_ENABLED	0
#  endif
#else
#  define ASPEN_HALF_ENABLED	1
#endif

#if ASPEN_HALF_ENABLED

#include <cuda_fp16.h>

#ifdef __cplusplus

#if CUDA_VERSION==8000

__host__ __device__ __forceinline__ bool
operator== ( const half a, const half b )
{
  half aa = a;
  half bb = b;
  unsigned short  u = *(reinterpret_cast<unsigned short *>(&(aa)));
  unsigned short  v = *(reinterpret_cast<unsigned short *>(&(bb)));
  return ( u == v );
}

__host__ __device__ __forceinline__ bool
operator!= ( const half a, const half b )
{
  half aa = a;
  half bb = b;
  unsigned short  u = *(reinterpret_cast<unsigned short *>(&(aa)));
  unsigned short  v = *(reinterpret_cast<unsigned short *>(&(bb)));
  return ( u != v );
}

__device__ __forceinline__ half
operator+ ( const half a )
{
  return a;
}

__device__ __forceinline__ half
operator+ ( const half a,  const half b )
{
  return __hadd (a, b);
}

__device__ __forceinline__ void
operator+= ( half &a,  const half b )
{
  a = __hadd (a, b);
}

__device__ __forceinline__ half
operator- ( const half a )
{
  return __hneg (a);
}

__device__ __forceinline__ half
operator- ( const half a,  const half b )
{
  return __hsub (a, b);
}

__device__ __forceinline__ void
operator-= ( half &a,  const half  b)
{
  a = __hsub (a, b);
}

__device__ __forceinline__ half
operator* ( const half a,  const half b )
{
  return __hmul (a, b);
}

__device__ __forceinline__ void
operator*= ( half &a,  const half b )
{
  a = __hmul (a, b);
}

#endif

#if CUDA_VERSION>=8000

#if defined(__NVCC__)

#  if CUDA_VERSION>=9000
#    define	hdiv	__hdiv
#  endif

__device__ __forceinline__ half
operator/ ( const half a,  const half b )
{
#if defined(__NVCC__)
  return hdiv (a, b);
#else
  return a / b;
#endif
}

__device__ __forceinline__ void
operator/= ( half &a,  const half b )
{
#if defined(__NVCC__)
  a = hdiv (a, b);
#else
  a = a / b;
#endif
}

__device__ __forceinline__ half
fma( const half a,  const half b, const half c )
{
#if defined(__NVCC__)
  return  __hfma (a, b, c);
#else
  return  a * b + c;
#endif
}

__device__ __forceinline__ void
fma2( const half a1,  const half b1, const half c1, half &d1,
      const half a2,  const half b2, const half c2, half &d2 )
{
  d1 = fma (a1, b1, c1);
  d2 = fma (a2, b2, c2);
}

#endif

__device__ __forceinline__ half
Conj( const half a )
{
  return  a;
}

__device__ __forceinline__ half
Abs( const half a )
{
  half aa = a;
  ushort  u = *(reinterpret_cast<ushort *>(&(aa)));
  u &=0xef;
  return *(reinterpret_cast<half *>(&(u)));
}

__device__ __forceinline__ half
__choose__( const bool flag,  const half a, const half b )
{
  half aa = a, bb = b;
  ushort  u = *(reinterpret_cast<ushort *>(&(aa)));
  ushort  v = *(reinterpret_cast<ushort *>(&(bb)));
  ushort  r = (flag ? u : v);
  return  *(reinterpret_cast<half *>(&(r)));
}

__device__ __forceinline__ half2
__choose__( const bool flag,  const half2 a, const half2 b )
{
  half2 aa = a, bb = b;
  uint u = *(reinterpret_cast<uint *>(&(aa)));
  uint v = *(reinterpret_cast<uint *>(&(bb)));
  uint r = (flag ? u : v);
  return  *(reinterpret_cast<half2 *>(&(r)));
}

__device__ __forceinline__ int
isfinite( const half a ) {
  half aa = a;
  unsigned short  u = *(reinterpret_cast<unsigned short *>(&(aa)));
  u &= 0x7e00;
  return (u != 0x7e00);
}

#endif

#else

typedef	__half_raw	half;

#endif

#endif

#endif


#ifndef ASPEN_GPU_CONF_H_INCLUDED
#define ASPEN_GPU_CONF_H_INCLUDED	1

#if defined(GPU_ARCH)

#if GPU_ARCH == Tesla || GPU_ARCH == Fermi || GPU_ARCH == Kepler
/*
 * obsolated architectures. not supported
 */
#error
error
#error
error
#error
#endif

#if GPU_ARCH == Tesla
// Tesla, GT2xx
#define	GPU_PREFIX		TESLA
#define	MAX_THREAD_BLOCKS       (8)
#define	MAX_REGS_PER_BLOCK	(32768)
#define	MAX_WARP_PER_MP		(32)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(16)
#define	SHMEM_UNIT_SIZE		(512)
#define	REGIS_UNIT_SIZE		(1)
#define	WARP_ALLOC_UNIT		(2)
#define	FENCE(...)		__LOOP_DIVIDER__()
#define	FENCE_BLOCK(...)	__LOOP_DIVIDER__()
#define	FENCE_SYSTEM(...)	__LOOP_DIVIDER__()
#endif

#if GPU_ARCH == Fermi
// Fermi
#define	GPU_PREFIX		FERMI
#define	MAX_THREAD_BLOCKS       (8)
#define	MAX_REGS_PER_BLOCK	(32768)
#define	MAX_WARP_PER_MP		(48)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(48)
#define	SHMEM_UNIT_SIZE		(128)
#define	REGIS_UNIT_SIZE		(64)
#define	WARP_ALLOC_UNIT		(2)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Kepler
// Kepler, GTX680
#define	GPU_PREFIX		KEPLER
#define	MAX_THREAD_BLOCKS       (16)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(48)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Kepler2
// Kepler
#define	GPU_PREFIX		KEPLER2
#define	MAX_THREAD_BLOCKS       (16)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(48)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Kepler3
// Kepler
#define	GPU_PREFIX		KEPLER3
#define	MAX_THREAD_BLOCKS       (16)
#define	MAX_REGS_PER_BLOCK	(65536*2)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(112)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Maxwell
// Maxwell
#define	GPU_PREFIX		MAXWELL
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(96)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Maxwell2
// Maxwell2
#define	GPU_PREFIX		MAXWELL2
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(96)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Maxwell3
// Maxwell3
#define	GPU_PREFIX		MAXWELL3
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(64)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Pascal
// Pascal
#define	GPU_PREFIX		PASCAL
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(16)
#define	SHMEM_CAPACITY_KB	(64)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Pascal1
// Pascal1
#define	GPU_PREFIX		PASCAL1
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(16)
#define	SHMEM_CAPACITY_KB	(96)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Pascal2
// Pascal2
#define	GPU_PREFIX		PASCAL2
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(16)
#define	SHMEM_CAPACITY_KB	(64)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Volta
// Volta
#define	GPU_PREFIX		VOLTA
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(96)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Turing
// Turing
#define	GPU_PREFIX		TURING
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(32)
#define	MAX_LDST_PER_MP		(16)
#define	SHMEM_CAPACITY_KB	(96)
#define	SHMEM_UNIT_SIZE		(256)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Ampere
// Ampere
#define	GPU_PREFIX		AMPERE
#define	MAX_THREAD_BLOCKS       (32)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(64)
#define	MAX_LDST_PER_MP		(32)
#define	SHMEM_CAPACITY_KB	(164)
#define	SHMEM_UNIT_SIZE		(128)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#if GPU_ARCH == Ampere2
// Ampere2
#define	GPU_PREFIX		AMPERE2
#define	MAX_THREAD_BLOCKS       (16)
#define	MAX_REGS_PER_BLOCK	(65536)
#define	MAX_WARP_PER_MP		(48)
#define	MAX_LDST_PER_MP		(16)
#define	SHMEM_CAPACITY_KB	(100)
#define	SHMEM_UNIT_SIZE		(128)
#define	REGIS_UNIT_SIZE		(256)
#define	WARP_ALLOC_UNIT		(4)
#define	FENCE(...)		__threadfence( )
#define	FENCE_BLOCK(...)	__threadfence_block( )
#define	FENCE_SYSTEM(...)	__threadfence_system( )
#endif

#endif  // GPU_ARCH

#endif


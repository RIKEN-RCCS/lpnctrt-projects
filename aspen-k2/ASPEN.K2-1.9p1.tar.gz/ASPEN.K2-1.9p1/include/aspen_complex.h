#ifndef ASPEN_COMPLEX_H_INCLUDED
#define ASPEN_COMPLEX_H_INCLUDED	1

#include <stdint.h>
#include <cuComplex.h>
#include "aspen_real.h"


#ifdef __cplusplus

/*********************************************************************
 * cuFloatComplex
 *********************************************************************/

__device__ __forceinline__ float
get_real( cuFloatComplex &a )
{ return a.x; }

__device__ __forceinline__ float
get_imag( cuFloatComplex &a )
{ return a.y; }

__device__ __forceinline__ void
set_real( cuFloatComplex &a, const float x )
{ a.x = x; }

__device__ __forceinline__ void
set_imag( cuFloatComplex &a, const float y )
{ a.y = y; }


__host__ __device__ __forceinline__ cuFloatComplex
fma ( const cuFloatComplex a, const cuFloatComplex b, const cuFloatComplex c )
{
  cuFloatComplex t;
  t.x = fma( a.x, b.x, c.x );
  t.y = fma( a.x, b.y, c.y );
  const float e = -a.y;
  t.x = fma( e, b.y, t.x );
  t.y = fma( a.y, b.x, t.y );
  return t;
}


__host__ __device__ __forceinline__ bool
operator== ( const cuFloatComplex a, const cuFloatComplex b )
{
  const bool ret = ((a.x == b.x) && (a.y == b.y)) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator!= ( const cuFloatComplex a, const cuFloatComplex b )
{
  const bool ret = ((a.x != b.x) || (a.y != b.y)) ? true : false;
  return ret;
}


__host__ __device__ __forceinline__ cuFloatComplex
operator+  ( const cuFloatComplex a )
{
  return a;
}

__host__ __device__ __forceinline__ cuFloatComplex
operator+  ( const cuFloatComplex a, const cuFloatComplex b )
{
  return cuCaddf ( a, b );
}

__host__ __device__ __forceinline__ void
operator+= ( cuFloatComplex &a, const cuFloatComplex b )
{
  a = cuCaddf ( a, b );
}

__host__ __device__ __forceinline__ cuFloatComplex
operator- ( const cuFloatComplex a )
{
  const cuFloatComplex t = { -a.x, -a.y };
  return  t;
}

__host__ __device__ __forceinline__ cuFloatComplex
operator- ( const cuFloatComplex a, const cuFloatComplex b )
{
  return cuCsubf ( a, b );
}

__host__ __device__ __forceinline__ void
operator-= ( cuFloatComplex &a, const cuFloatComplex b )
{
  a = cuCsubf ( a, b );
}

__host__ __device__ __forceinline__ cuFloatComplex
operator* ( const cuFloatComplex a, const cuFloatComplex b )
{
  return cuCmulf ( a, b );
}

__host__ __device__ __forceinline__ void
operator*= ( cuFloatComplex &a, const cuFloatComplex b )
{
  a = cuCmulf ( a, b );
}

__host__ __device__ __forceinline__ cuFloatComplex
operator/ ( const cuFloatComplex a, const cuFloatComplex b )
{
  return cuCdivf ( a, b );
}

__host__ __device__ __forceinline__ void
operator/= ( cuFloatComplex &a, const cuFloatComplex b )
{
  a = cuCdivf ( a, b );
}


__host__ __device__ __forceinline__ void
add2 ( const cuFloatComplex a1, const cuFloatComplex b1, cuFloatComplex &d1,
       const cuFloatComplex a2, const cuFloatComplex b2, cuFloatComplex &d2 )
{
  cuFloatComplex t1,t2;
  t1 = a1 + b1;
  t2 = a2 + b2;
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
sub2 ( const cuFloatComplex a1, const cuFloatComplex b1, cuFloatComplex &d1,
       const cuFloatComplex a2, const cuFloatComplex b2, cuFloatComplex &d2 )
{
  cuFloatComplex t1,t2;
  t1 = a1 - b1;
  t2 = a2 - b2;
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
mul2 ( const cuFloatComplex a1, const cuFloatComplex b1, cuFloatComplex &d1,
       const cuFloatComplex a2, const cuFloatComplex b2, cuFloatComplex &d2 )
{
  cuFloatComplex t1,t2;
  t1.x = __mul( a1.x, b1.x );
  t1.y = __mul( a1.x, b1.y );
  t2.x = __mul( a2.x, b2.x );
  t2.y = __mul( a2.x, b2.y );
  const float e1 = -a1.y;
  const float e2 = -a2.y;
  t1.x = fma( e1, b1.y, t1.x );
  t2.x = fma( e2, b2.y, t2.x );
  t1.y = fma( a1.y, b1.x, t1.y );
  t2.y = fma( a2.y, b2.x, t2.y );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
fma2 ( const cuFloatComplex a1, const cuFloatComplex b1, const cuFloatComplex c1, cuFloatComplex &d1,
       const cuFloatComplex a2, const cuFloatComplex b2, const cuFloatComplex c2, cuFloatComplex &d2 )
{
  cuFloatComplex t1, t2;
  fma2( a1.x, b1.x, c1.x, t1.x,
        a2.x, b2.x, c2.x, t2.x );
  fma2( a1.x, b1.y, c1.y, t1.y,
        a2.x, b2.y, c2.y, t2.y );
  const float e1 = -a1.y;
  const float e2 = -a2.y;
  fma2( e1, b1.y, t1.x, t1.x,
        e2, b2.y, t2.x, t2.x );
  fma2( a1.y, b1.x, t1.y, t1.y,
        a2.y, b2.x, t2.y, t2.y );
  d1 = t1; d2 = t2;
}


__host__ __device__ __forceinline__ cuFloatComplex
fma ( const cuFloatComplex a, const float b, const cuFloatComplex c )
{
  cuFloatComplex t;
  t.x = fma( a.x, b, c.x );
  t.y = fma( a.y, b, t.y );
  return t;
}

__host__ __device__ __forceinline__ cuFloatComplex
fma ( const float a, const cuFloatComplex b, const cuFloatComplex c )
{
  cuFloatComplex t;
  t.x = fma( a, b.x, c.x );
  t.y = fma( a, b.y, c.y );
  return t;
}

__host__ __device__ __forceinline__ int
isnan ( const cuFloatComplex a )
{
  return (isnan(a.x) || isnan(a.y));
}

__host__ __device__ __forceinline__ int
isinf ( const cuFloatComplex a )
{
  return (isinf(a.x) || isinf(a.y));
}

__host__ __device__ __forceinline__ int
isfinite ( const cuFloatComplex a )
{
#if defined(__CUDA_ARCH__)
  uint b;
  asm volatile ( "and.b32\t%0, %1, %2;" : "=r"(b) : "f"(a.x), "f"(a.y) );
  const uint mask = 0x7f800000;
  return (b & mask) != mask;
#else
  return (isfinite(a.x) && isfinite(a.y));
#endif
}

__host__ __device__ __forceinline__ float
Abs ( const cuFloatComplex a )
{
  return cuCabsf ( a );
}

__host__ __device__ __forceinline__ void
makeConj ( cuFloatComplex & a ) {
  a = cuConjf ( a );
}

__host__ __device__ __forceinline__ cuFloatComplex
Conj ( const cuFloatComplex a ) {
  return cuConjf ( a );
}

__host__ __device__ __forceinline__ cuFloatComplex
__choose__ ( const bool flag, const cuFloatComplex a, const cuFloatComplex b )
{
  cuFloatComplex t = { (flag ? a.x : b.x), (flag ? a.y : b.y) };
  return t;
}

__forceinline__ __device__ cuFloatComplex
__select__( const int cond, const cuFloatComplex case_pos, const cuFloatComplex case_neg )
{
  cuFloatComplex r;
  r.x = __select__( cond, case_pos.x, case_neg.x );
  r.y = __select__( cond, case_pos.y, case_neg.y );
  return r;
}


/*********************************************************************
 * cuDoubleComplex
 *********************************************************************/

__device__ __forceinline__ double
get_real( cuDoubleComplex &a )
{ return a.x; }

__device__ __forceinline__ double
get_imag( cuDoubleComplex &a )
{ return a.y; }

__device__ __forceinline__ void
set_real( cuDoubleComplex &a, const double x )
{ a.x = x; }

__device__ __forceinline__ void
set_imag( cuDoubleComplex &a, const double y )
{ a.y = y; }


__host__ __device__ __forceinline__ cuDoubleComplex
fma ( const cuDoubleComplex a, const cuDoubleComplex b, const cuDoubleComplex c)
{
  cuDoubleComplex t;
  t.x = fma( a.x, b.x, c.x );
  t.y = fma( a.x, b.y, c.y );
  const double e = -a.y;
  t.x = fma( e, b.y, t.x );
  t.y = fma( a.y, b.x, t.y );
  return t;
}


__host__ __device__ __forceinline__ bool
operator== ( const cuDoubleComplex a, const cuDoubleComplex b )
{
  const bool ret = ((a.x == b.x) && (a.y == b.y)) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator!= ( const cuDoubleComplex a, const cuDoubleComplex b )
{
  const bool ret = ((a.x != b.x) || (a.y != b.y)) ? true : false;
  return ret;
}


__host__ __device__ __forceinline__ cuDoubleComplex
operator+ ( const cuDoubleComplex a )
{
  return a;
}

__host__ __device__ __forceinline__ cuDoubleComplex
operator+ ( const cuDoubleComplex a, const cuDoubleComplex b )
{
  return cuCadd ( a, b );
}

__host__ __device__ __forceinline__ void
operator+= ( cuDoubleComplex &a, const cuDoubleComplex b )
{
  a = cuCadd ( a, b );
}

__host__ __device__ __forceinline__ cuDoubleComplex
operator- ( const cuDoubleComplex a )
{
  const cuDoubleComplex t = { -a.x, -a.y };
  return t;
}

__host__ __device__ __forceinline__ cuDoubleComplex
operator- ( const cuDoubleComplex a, const cuDoubleComplex b )
{
  return cuCsub ( a, b );
}

__host__ __device__ __forceinline__ void
operator-= ( cuDoubleComplex &a, const cuDoubleComplex b )
{
  a = cuCsub ( a, b );
}

__host__ __device__ __forceinline__ cuDoubleComplex
operator* ( const cuDoubleComplex a, const cuDoubleComplex b )
{
  return cuCmul ( a, b );
}

__host__ __device__ __forceinline__ void
operator*= ( cuDoubleComplex &a, const cuDoubleComplex b )
{
  a = cuCmul ( a, b );
}

__host__ __device__ __forceinline__ cuDoubleComplex
operator/ ( const cuDoubleComplex a, const cuDoubleComplex b )
{
  return cuCdiv ( a, b );
}

__host__ __device__ __forceinline__ void
operator/= ( cuDoubleComplex &a, const cuDoubleComplex b )
{
  a = cuCdiv ( a, b );
}


__host__ __device__ __forceinline__ void
add2 ( const cuDoubleComplex a1, const cuDoubleComplex b1, cuDoubleComplex &d1,
       const cuDoubleComplex a2, const cuDoubleComplex b2, cuDoubleComplex &d2 )
{
  cuDoubleComplex t1,t2;
  t1 = a1 + b1;
  t2 = a2 + b2;
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
sub2 ( const cuDoubleComplex a1, const cuDoubleComplex b1, cuDoubleComplex &d1,
       const cuDoubleComplex a2, const cuDoubleComplex b2, cuDoubleComplex &d2 )
{
  cuDoubleComplex t1,t2;
  t1 = a1 - b1;
  t2 = a2 - b2;
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
mul2 ( const cuDoubleComplex a1, const cuDoubleComplex b1, cuDoubleComplex &d1,
       const cuDoubleComplex a2, const cuDoubleComplex b2, cuDoubleComplex &d2 )
{
  cuDoubleComplex t1,t2;
  t1.x = __mul( a1.x, b1.x );
  t1.y = __mul( a1.x, b1.y );
  t2.x = __mul( a2.x, b2.x );
  t2.y = __mul( a2.x, b2.y );
  const double e1 = -a1.y;
  const double e2 = -a2.y;
  t1.x = fma( e1, b1.y, t1.x );
  t2.x = fma( e2, b2.y, t2.x );
  t1.y = fma( a1.y, b1.x, t1.y );
  t2.y = fma( a2.y, b2.x, t2.y );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
fma2 ( const cuDoubleComplex a1, const cuDoubleComplex b1, const cuDoubleComplex c1, cuDoubleComplex &d1,
       const cuDoubleComplex a2, const cuDoubleComplex b2, const cuDoubleComplex c2, cuDoubleComplex &d2 )
{
  cuDoubleComplex t1, t2;
  fma2( a1.x, b1.x, c1.x, t1.x,
        a2.x, b2.x, c2.x, t2.x );
  fma2( a1.x, b1.y, c1.y, t1.y,
        a2.x, b2.y, c2.y, t2.y );
  const double e1 = -a1.y;
  const double e2 = -a2.y;
  fma2( e1, b1.y, t1.x, t1.x,
        e2, b2.y, t2.x, t2.x );
  fma2( a1.y, b1.x, t1.y, t1.y,
        a2.y, b2.x, t2.y, t2.y );
  d1 = t1; d2 = t2;
}


__host__ __device__ __forceinline__ cuDoubleComplex
fma ( const cuDoubleComplex a, const double b, const cuDoubleComplex c)
{
  cuDoubleComplex t;
  t.x = fma( a.x, b, c.x );
  t.y = fma( a.y, b, t.y );
  return t;
}

__host__ __device__ __forceinline__ cuDoubleComplex
fma ( const double a, const cuDoubleComplex b, const cuDoubleComplex c)
{
  cuDoubleComplex t;
  t.x = fma( a, b.x, c.x );
  t.y = fma( a, b.y, c.y );
  return t;
}

__host__ __device__ __forceinline__ int
isnan ( const cuDoubleComplex a )
{
  return (isnan(a.x) || isnan(a.y));
}

__host__ __device__ __forceinline__ int
isinf ( const cuDoubleComplex a )
{
  return (isinf(a.x) || isinf(a.y));
}

__host__ __device__ __forceinline__ int
isfinite ( const cuDoubleComplex a )
{
#if defined(__CUDA_ARCH__)
  const uint b  = __double2hiint( a.x ) & __double2hiint( a.y );
  const uint mask = 0x7ff00000;
  return (b & mask) != mask;
#else
  return (isfinite(a.x) && isfinite(a.y));
#endif
}

__host__ __device__ __forceinline__ double
Abs ( const cuDoubleComplex a )
{
  return cuCabs( a );
}

__host__ __device__ __forceinline__ void
makeConj ( cuDoubleComplex & a )
{
  a = cuConj ( a );
}

__host__ __device__ __forceinline__ cuDoubleComplex
Conj ( const cuDoubleComplex a )
{
  return cuConj ( a );
}

__host__ __device__ __forceinline__ cuDoubleComplex
__choose__ ( const bool flag, const cuDoubleComplex a, const cuDoubleComplex b )
{
  cuDoubleComplex t = { (flag ? a.x : b.x), (flag ? a.y : b.y) };
  return t;
}

__forceinline__ __device__ cuDoubleComplex
__select__( const int cond, const cuDoubleComplex case_pos, const cuDoubleComplex case_neg )
{
  cuDoubleComplex r;
  r.x = __select__( cond, case_pos.x, case_neg.x );
  r.y = __select__( cond, case_pos.y, case_neg.y );
  return r;
}

#endif

#endif


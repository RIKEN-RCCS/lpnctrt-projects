#ifndef ASPEN_MAKE_CONST_H_INCLUDED
#define	ASPEN_MAKE_CONST_H_INCLUDED	1

#include "aspen_types.h"
#include "aspen_istypes.h"

// const volatile acess ----------------------------------
#if 0
static
__device__ const uint ASPEN_I32_CONST[2] = {0x00000000,0xffffffff};
#define PTX_LOAD_ZERO(x)                                \
  "ld.global.cv.u32\t%"#x", [ASPEN_I32_CONST+0];\n\t"
#define PTX_LOAD_MONE(x)                                \
  "ld.global.cv.u32\t%"#x", [ASPEN_I32_CONST+4];\n\t"
#else
static
__device__ __constant__ uint ASPEN_I32_CONST[2] = {0x00000000,0xffffffff};
#define PTX_LOAD_ZERO(x)                                \
  "ld.const.u32\t%"#x", [ASPEN_I32_CONST+0];\n\t"
#define PTX_LOAD_MONE(x)                                \
  "ld.const.u32\t%"#x", [ASPEN_I32_CONST+4];\n\t"
#endif

__forceinline__   __device__ uint _ZERO_ ( void )
{
  uint ret;
  asm volatile ( PTX_LOAD_ZERO(0) : "=r"(ret) );
  return ret;
}

__forceinline__   __device__ uint _MONE_ ( void )
{
  uint ret;
  asm volatile ( PTX_LOAD_MONE(0) : "=r"(ret) );
  return ret;
}

// generic ----------------------------------
template < class TYPE, class TYPE_ >
__forceinline__ __host__  __device__ TYPE
makeCONST ( const TYPE_ x )
{
  return static_cast<TYPE>(x);
}

template < class TYPE, class TYPE_ >
__forceinline__ __host__  __device__ TYPE
makeCONST ( const TYPE_ x, const TYPE_ y )
{
  return static_cast<TYPE>(x);
}
// generic ----------------------------------


// half ----------------------------------
#if ASPEN_HALF_ENABLED
template < >
__forceinline__ __host__  __device__ half
makeCONST ( const int x )
{
  const int    xx = (x > 0) ? (+x) : (-x);
  short  c  = (xx & 0x03ff);
  if ( x < 0 ) c |= 0x8000;
  half   y;
#  if CURRENT_GPU==600||CURRENT_GPU==700||CURRENT_GPU==750
#    if CUDA_VERSION==8000
  half  z;
#    else
  __half_raw  z;
#    endif
  z.x = c;
  y = z;
#  else
  y = * (half *)(&c);
#  endif
  return y;
}

#if __NVCC__
#  if CURRENT_GPU==600||CURRENT_GPU==700||CURRENT_GPU==750
#    if CUDA_VERSION>8000
template < >
__forceinline__ __host__  __device__ __half_raw
makeCONST ( const int x )
{
  const half y = makeCONST < half > ( x );
  const __half_raw z = y;
  return z;
}
#    endif
#  endif
#endif

#endif
// half ----------------------------------

// half_complex ----------------------------------
template < >
__forceinline__ __host__  __device__ cuHalfComplex
makeCONST ( const int x )
{
  const half y = makeCONST < half > ( x );
  const half z = makeCONST < half > ( 0 );
  __cuHalfComplex_raw__ t_;
  t_.x = y;
  t_.y = z;
  return t_;
}
// half_complex ----------------------------------


// cuddreal ----------------------------------
template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const int x )
{
  return __cuddreal__( static_cast<double>(x), static_cast<double>(0) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const float x )
{
  return __cuddreal__( static_cast<double>(x), static_cast<double>(0) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const double x )
{
  return __cuddreal__( static_cast<double>(x), static_cast<double>(0) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const cuFloatComplex x )
{
  return __cuddreal__( static_cast<double>(x.x), static_cast<double>(0) );
}
template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const cuDoubleComplex x )
{
  return __cuddreal__( static_cast<double>(x.x), static_cast<double>(0) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const int hi, const int err )
{
  return __cuddreal__( static_cast<double>(hi), static_cast<double>(err) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const float hi, const float err )
{
  return __cuddreal__( static_cast<double>(hi), static_cast<double>(err) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
makeCONST ( const double hi, const double err )
{
  return __cuddreal__( static_cast<double>(hi), static_cast<double>(err) );
}
// cuddreal ----------------------------------


// cudfreal ----------------------------------
template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const int x )
{
  return __cudfreal__( static_cast<float>(x), static_cast<float>(0) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const float x )
{
  return __cudfreal__( static_cast<float>(x), static_cast<float>(0) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const double x )
{
  return __cudfreal__( static_cast<float>(x), static_cast<float>(0) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const cuFloatComplex x )
{
  return __cudfreal__( static_cast<float>(x.x), static_cast<float>(0) );
}
template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const cuDoubleComplex x )
{
  return __cudfreal__( static_cast<float>(x.x), static_cast<float>(0) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const int hi, const int err )
{
  return __cudfreal__( static_cast<float>(hi), static_cast<float>(err) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const float hi, const float err )
{
  return __cudfreal__( static_cast<float>(hi), static_cast<float>(err) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
makeCONST ( const double hi, const double err )
{
  return __cudfreal__( static_cast<float>(hi), static_cast<float>(err) );
}
// cuddreal ----------------------------------


// cuFloatComplex ----------------------------------
template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const int x )
{
  return (cuFloatComplex){ static_cast<float>(x), static_cast<float>(0) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const float x )
{
  return (cuFloatComplex){ static_cast<float>(x), static_cast<float>(0) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const double x )
{
  return (cuFloatComplex){ static_cast<float>(x), static_cast<float>(0) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const cuddreal x )
{
  cuddreal_raw x_ = x;
  return (cuFloatComplex){ static_cast<float>(x_.x), static_cast<float>(0) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const cuDoubleComplex x )
{
  return (cuFloatComplex){ static_cast<float>(x.x), static_cast<float>(x.y) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const cuddcomplex x )
{
  cuddcomplex_raw x_  = x;
  cuddreal_raw x_x = x_.x;
  cuddreal_raw x_y = x_.y;
  return (cuFloatComplex){ static_cast<float>(x_x.x), static_cast<float>(x_y.x) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const int x, const int y )
{
  return (cuFloatComplex){ static_cast<float>(x), static_cast<float>(y) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const float x, const float y )
{
  return (cuFloatComplex){ static_cast<float>(x), static_cast<float>(y) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const double x, const double y )
{
  return (cuFloatComplex){ static_cast<float>(x), static_cast<float>(y) };
}

template < >
__forceinline__ __host__  __device__ cuFloatComplex
makeCONST ( const cuddreal x, const cuddreal y )
{
  cuddreal_raw x_ = x;
  cuddreal_raw y_ = y;
  return (cuFloatComplex){ static_cast<float>(x_.x), static_cast<float>(y_.x) };
}
// cuFloatComplex ----------------------------------


// cuDoubleComplex ----------------------------------
template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const int x )
{
  return (cuDoubleComplex){ static_cast<double>(x), static_cast<double>(0) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const float x )
{
  return (cuDoubleComplex){ static_cast<double>(x), static_cast<double>(0) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const double x )
{
  return (cuDoubleComplex){ static_cast<double>(x), static_cast<double>(0) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const cuddreal x )
{
  cuddreal_raw x_ = x;
  return (cuDoubleComplex){ static_cast<double>(x_.x), static_cast<double>(0) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const cuFloatComplex x )
{
  return (cuDoubleComplex){ static_cast<double>(x.x), static_cast<double>(x.y) };
}

#if 1
template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const cuddcomplex x )
{
  cuddcomplex_raw x_  = x;
  cuddreal_raw x_x = x_.x;
  cuddreal_raw x_y = x_.y;
  return (cuDoubleComplex){ static_cast<double>(x_x.x), static_cast<double>(x_y.x) };
}
#endif

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const int x, const int y )
{
  return (cuDoubleComplex){ static_cast<double>(x), static_cast<double>(y) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const float x, const float y )
{
  return (cuDoubleComplex){ static_cast<double>(x), static_cast<double>(y) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const double x, const double y )
{
  return (cuDoubleComplex){ static_cast<double>(x), static_cast<double>(y) };
}

template < >
__forceinline__ __host__  __device__ cuDoubleComplex
makeCONST ( const cuddreal x, const cuddreal y )
{
  cuddreal_raw x_ = x;
  cuddreal_raw y_ = y;
  return (cuDoubleComplex){ static_cast<double>(x_.x), static_cast<double>(y_.x) };
}
// cuDoubleComplex ----------------------------------


// cuddcomplex ----------------------------------
template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const int x )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x) ), __cuddreal__( static_cast<double>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const float x )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x) ), __cuddreal__( static_cast<double>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const double x )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x) ), __cuddreal__( static_cast<double>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const cuddreal x )
{
  return __cuddcomplex__( x, __cuddreal__( static_cast<double>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const cuFloatComplex x )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x.x) ), __cuddreal__( static_cast<double>(x.y) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const cuDoubleComplex x )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x.x) ), __cuddreal__( static_cast<double>(x.y) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const int x, const int y )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x) ), __cuddreal__( static_cast<double>(y) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const float x, const float y )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x) ), __cuddreal__( static_cast<double>(y) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const double x, const double y )
{
  return __cuddcomplex__( __cuddreal__( static_cast<double>(x) ), __cuddreal__( static_cast<double>(y) ) );
}

template < >
__forceinline__ __host__  __device__ cuddcomplex
makeCONST ( const cuddreal x, const cuddreal y )
{
  return __cuddcomplex__( x, y );
}
// cuddcomplex ----------------------------------


// cudfcomplex ----------------------------------
template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const int x )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x) ), __cuddreal__( static_cast<float>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const float x )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x) ), __cuddreal__( static_cast<float>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const double x )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x) ), __cuddreal__( static_cast<float>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const cuddreal x )
{
  const cuddreal_raw x_ = x;
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x_.x), static_cast<float>(x_.y) ), __cudfreal__( static_cast<float>(0) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const cuFloatComplex x )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x.x) ), __cudfreal__( static_cast<float>(x.y) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const cuDoubleComplex x )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x.x) ), __cudfreal__( static_cast<float>(x.y) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const int x, const int y )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x) ), __cudfreal__( static_cast<float>(y) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const float x, const float y )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x) ), __cudfreal__( static_cast<float>(y) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const double x, const double y )
{
  return __cudfcomplex__( __cudfreal__( static_cast<float>(x) ), __cudfreal__( static_cast<float>(y) ) );
}

template < >
__forceinline__ __host__  __device__ cudfcomplex
makeCONST ( const cuddreal x, const cuddreal y )
{
  return __cudfcomplex__( x, y );
}
// cudfcomplex ----------------------------------


// int16 ----------------------------------
template < >
__forceinline__ __host__  __device__ int16
makeCONST ( const int x )
{
  return __int16__t_( static_cast<int16_t>(x) );
}
// int16 ----------------------------------


// int128 ----------------------------------
template < >
__forceinline__ __host__  __device__ int128
makeCONST ( const int x )
{
  const int128 t = __int128__t_( static_cast<int64_t>(0), static_cast<uint64_t>(x) );
  return t;
}
// int128 ----------------------------------


// bfloat16 ----------------------------------
template < >
__forceinline__ __host__  __device__ bfloat16
makeCONST ( const int x )
{
  union {
    unsigned short x[2];
    float y;
  } u;
  u.y = static_cast<float>(x);
  bfloat16 t; t.x = u.x[1];
  return t;
}
template < >
__forceinline__ __host__  __device__ bfloat16
makeCONST ( const float x )
{
  union {
    unsigned short x[2];
    float y;
  } u;
  u.y = static_cast<float>(x);
  bfloat16 t; t.x = u.x[1];
  return t;
}
template < >
__forceinline__ __host__  __device__ bfloat16
makeCONST ( const double x )
{
  union {
    unsigned short x[2];
    float y;
  } u;
  u.y = static_cast<float>(x);
  bfloat16 t; t.x = u.x[1];
  return t;
}
// bfloat16 ----------------------------------

template < class TYPE >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( TYPE &b )
{ ; }

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( half &b )
{
  __half_raw c = b;
  asm volatile ( "// const volatile" :: "h"(c.x) );
  b = c;
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( float &b )
{
  asm volatile ( "// const volatile" :: "f"(b) );
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( double &b )
{
  asm volatile ( "// const volatile" :: "d"(b) );
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( cuddreal &b )
{
  cuddreal_raw c = b;
  makeCONST_volatile_sub ( c.x );
  makeCONST_volatile_sub ( c.y );
  b = c;
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( cuFloatComplex &b )
{
  makeCONST_volatile_sub ( b.x );
  makeCONST_volatile_sub ( b.y );
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( cuDoubleComplex &b )
{
  makeCONST_volatile_sub ( b.x );
  makeCONST_volatile_sub ( b.y );
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( cuddcomplex &b )
{
  cuddcomplex_raw c = b;
  makeCONST_volatile_sub ( c.x );
  makeCONST_volatile_sub ( c.y );
  b = c;
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( int16 &b )
{
  int16_raw c = b;
  asm volatile ( "// const volatile" :: "h"(c.x) );
  b = c;
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( int32 &b )
{
  asm volatile ( "// const volatile" :: "r"(b) );
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( int64 &b )
{
  asm volatile ( "// const volatile" :: "l"(b) );
}

template < >
__forceinline__ __host__  __device__ void
makeCONST_volatile_sub ( int128 &b )
{
  int128_raw c = b;
  makeCONST_volatile_sub ( c.x );
  makeCONST_volatile_sub ( c.y );
  b = c;
}

template < class TYPE >
__forceinline__ __host__  __device__ TYPE
makeCONST_volatile ( const int x )
{
  TYPE b = makeCONST < TYPE > ( x );
  b = *(reinterpret_cast<TYPE*>(&b));
  makeCONST_volatile_sub ( b );
  return b;
}

// normalization ----------------------------------
template < class TYPE >
__forceinline__ __host__  __device__ TYPE
Normalize ( const double h, const double l )
{ TYPE r; return r; }

template < class TYPE >
__forceinline__ __host__  __device__ TYPE
Normalize ( const int h, const int l )
{ TYPE r; return r; }

template < class TYPE >
__forceinline__ __host__  __device__ TYPE
Normalize ( const float h, const float l )
{ TYPE r; return r; }

template < class TYPE >
__forceinline__ __host__  __device__ TYPE
Normalize ( const TYPE x )
{ TYPE r; return r; }


template < >
__forceinline__ __host__  __device__ cuddreal
Normalize < cuddreal > ( const double h, const double l )
{
  double hi = h, lo = l;
  hi += l;
  const double d = hi - h;
  const cuddreal t = __cuddreal__( static_cast<double>(h+lo), static_cast<double>(lo-d) );
  return t;
}

template < >
__forceinline__ __host__  __device__ cuddreal
Normalize < cuddreal > ( const int h, const int l )
{
  return Normalize < cuddreal > ( static_cast<double>(h), static_cast<double>(l) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
Normalize < cuddreal > ( const float h, const float l )
{
  return Normalize < cuddreal > ( static_cast<double>(h), static_cast<double>(l) );
}

template < >
__forceinline__ __host__  __device__ cuddreal
Normalize < cuddreal > ( const cuddreal x )
{
  cuddreal_raw x_ = x;
  return Normalize < cuddreal > ( static_cast<double>(x_.x), static_cast<double>(x_.y) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
Normalize < cudfreal > ( const float h, const float l )
{
  float hi = h, lo = l;
  hi += l;
  float d = hi - h;
  const cudfreal t = __cudfreal__( static_cast<float>(h+lo), static_cast<float>(lo-d) );
  return t;
}

template < >
__forceinline__ __host__  __device__ cudfreal
Normalize < cudfreal > ( const int h, const int l )
{
  return Normalize < cudfreal > ( static_cast<float>(h), static_cast<float>(l) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
Normalize < cudfreal > ( const double h, const double l )
{
  return Normalize < cudfreal > ( static_cast<float>(h), static_cast<float>(l) );
}

template < >
__forceinline__ __host__  __device__ cudfreal
Normalize < cudfreal > ( const cudfreal x )
{
  cudfreal_raw x_ = x;
  return Normalize < cudfreal > ( static_cast<double>(x_.x), static_cast<double>(x_.y) );
}
// normalization ----------------------------------


// zerofy ----------------------------------
template < class TYPE >
__forceinline__ __host__  __device__ void
zerofy ( TYPE &x )
{ x = makeCONST<TYPE>(0); }

#if __NVCC__
#if ASPEN_HALF_ENABLED
#if CUDA_VERSION>8000
__forceinline__ __host__  __device__ void
zerofy ( __half_raw &x_ )
{
  asm volatile ( "mov.b16\t%0, 0;" : "=h"(x_.x));
}
#endif

template < >
__forceinline__ __host__  __device__ void
zerofy ( half &x )
{
#if CUDA_VERSION==8000
  __half_raw x_;
  asm volatile ( "mov.b16\t%0, 0;" : "=h"(x_.x));
  x = x_;
#else
  zerofy ( x );
#endif
}
#endif
#endif

template < >
__forceinline__ __host__  __device__ void
zerofy ( float &x )
{
  asm volatile ( "mov.b32\t%0, 0;" : "=f"(x) );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( double &x )
{
  asm volatile ( "mov.b64\t%0, 0;" : "=d"(x) );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( cudfreal &x )
{
  float zero;
  zerofy( zero );
  x = __cudfreal__( zero, zero );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( cuddreal &x )
{
  double zero;
  zerofy( zero );
  x = __cuddreal__( zero, zero );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( cuFloatComplex &x )
{
  zerofy( x.x ); zerofy( x.y );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( cuDoubleComplex &x )
{
  zerofy( x.x ); zerofy( x.y );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( cudfcomplex &x )
{
  cudfreal zero;
  zerofy( zero );
  x = __cudfcomplex__( zero, zero );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( cuddcomplex &x )
{
  cuddreal zero;
  zerofy( zero );
  x = __cuddcomplex__( zero, zero );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( int16 &x )
{
  int16_t xx;
  asm volatile ( "mov.b16 %0, 0;" : "=h"(xx) );
  x = xx;
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( int32 &x )
{
  asm volatile ( "mov.b32 %0, 0;" : "=r"(x) );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( int64 &x )
{
  asm volatile ( "mov.b64 %0, 0;" : "=l"(x) );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( int128 &x )
{
  int64_t  cx;
  uint64_t cy;
  asm volatile ( "mov.b64 %0, 0;" : "=l"(cx) );
  asm volatile ( "mov.b64 %0, 0;" : "=l"(cy) );
  x = __int128__t_( cx, cy );
}

template < >
__forceinline__ __host__  __device__ void
zerofy ( bfloat16 &x )
{
  asm volatile ( "mov.b16 %0,0;" : "=h"(x.x) );
}

template < class TYPE >
__forceinline__ __host__  __device__ TYPE
zerofy ( void )
{ TYPE y; zerofy( y ); return y; }
// const_zero ----------------------------------

#endif


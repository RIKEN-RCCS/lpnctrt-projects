#ifndef ASPEN_REAL_H_INCLUDED
#define ASPEN_REAL_H_INCLUDED		1

// ...


#ifdef __cplusplus

// for float

__host__ __device__ __forceinline__ float
__add ( const float a,  const float b )
{
#ifdef __CUDA_ARCH__
  return __fadd_rn ( a, b );
#else
  const float t = (a + b);
  return  t;
#endif
}

__host__ __device__ __forceinline__ void
add2 ( const float a1, const  float b1, float &d1,
       const float a2, const  float b2, float &d2 )
{
  float t1,t2;
  t1 = __add( a1, b1 );
  t2 = __add( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ float
__sub ( const float a,  const float b )
{
#ifdef __CUDA_ARCH__
  return __fsub_rn ( a, b );
#else
  const float t = (a - b);
  return  t;
#endif
}

__host__ __device__ __forceinline__ void
sub2 ( const float a1, const  float b1, float &d1,
       const float a2, const  float b2, float &d2 )
{
  float t1,t2;
  t1 = __sub( a1, b1 );
  t2 = __sub( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ float
__mul ( const float a,  const float b )
{
#ifdef __CUDA_ARCH__
  return __fmul_rn ( a, b );
#else
  const float t = (a * b);
  return  t;
#endif
}

__host__ __device__ __forceinline__ void
mul2 ( const float a1, const  float b1, float &d1,
       const float a2, const  float b2, float &d2 )
{
  float t1,t2;
  t1 = __mul( a1, b1 );
  t2 = __mul( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
fma2 ( const float a1, const  float b1, const  float c1, float &d1,
       const float a2, const  float b2, const  float c2, float &d2 )
{
  float t1,t2;
  t1 = fma( a1, b1, c1 );
  t2 = fma( a2, b2, c2 );
  d1 = t1; d2 = t2;
}

#if !defined(__NVCC__)
#if __GNUC__ < 6
__host__ __device__ __forceinline__ int
isfinite ( const float a )
{
  union {
    float f;
    unsigned int  u;
  } x;
  x.f = a;
  x.u &= 0x7f800000;
  return (x.u != 0x7f800000);
}
#endif
#endif

__host__ __device__ __forceinline__ float
Abs ( const float a )
{
  return (fabsf(a));
}

__host__ __device__ __forceinline__ float
Conj ( const float a )
{
  return (a);
}

__host__ __device__ __forceinline__ float
__choose__ ( const bool flag, const float a, const float b )
{
  return (flag ? a : b);
}

__forceinline__ __device__ float
__select__( const int cond, const float case_pos, const float case_neg )
{
  float r;
  asm volatile ( "slct.f32.s32\t%0, %1, %2, %3;"
                 : "=f"(r) : "f"(case_pos), "f"(case_neg), "r"(cond) );
  return r;
}


// for double

__host__ __device__ __forceinline__ double
__add ( const double a,  const double b )
{
#ifdef __CUDA_ARCH__
  return __dadd_rn ( a, b );
#else
  const double t = (a + b);
  return  t;
#endif
}

__host__ __device__ __forceinline__ void
add2 ( const  double a1, const double b1, double &d1,
       const  double a2, const double b2, double &d2 )
{
  double t1,t2;
  t1 = __add( a1, b1 );
  t2 = __add( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ double
__sub ( const double a,  const double b )
{
#ifdef __CUDA_ARCH__
  return __dsub_rn ( a, b );
#else
  const double t = (a - b);
  return  t;
#endif
}

__host__ __device__ __forceinline__ void
sub2 ( const  double a1, const double b1, double &d1,
       const  double a2, const double b2, double &d2 )
{
  double t1,t2;
  t1 = __sub( a1, b1 );
  t2 = __sub( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ double
__mul ( const double a,  const double b )
{
#ifdef __CUDA_ARCH__
  return __dmul_rn ( a, b );
#else
  const double t = (a * b);
  return  t;
#endif
}

__host__ __device__ __forceinline__ void
mul2 ( const  double a1, const double b1, double &d1,
       const  double a2, const double b2, double &d2 )
{
  double t1,t2;
  t1 = __mul( a1, b1 );
  t2 = __mul( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
fma2 ( const  double a1, const double b1, const  double c1, double &d1,
       const  double a2, const double b2, const  double c2, double &d2 )
{
  double t1,t2;
  t1 = fma( a1, b1, c1 );
  t2 = fma( a2, b2, c2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ double
Abs ( const double a )
{
  return (fabs(a));
}

__host__ __device__ __forceinline__ double
Conj ( const double a )
{
  return (a);
}

__host__ __device__ __forceinline__ double
__choose__ ( const bool flag, const double a, const double b )
{
  return (flag ? a : b);
}

__forceinline__ __device__ double
__select__( const int cond, const double case_pos, const double case_neg )
{
  double r;
  asm volatile ( "slct.f64.s32\t%0, %1, %2, %3;"
                 : "=d"(r) : "d"(case_pos), "d"(case_neg), "r"(cond) );
  return r;
}

#endif

#endif


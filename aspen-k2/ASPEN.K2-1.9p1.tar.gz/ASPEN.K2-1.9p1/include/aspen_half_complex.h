#ifndef ASPEN_HALF_COMPLEX_H_INCLUDED
#define ASPEN_HALF_COMPLEX_H_INCLUDED	1

// minimum functions are preliminary implemented

#include <stdint.h>
#include "aspen_half.h"

#if ASPEN_HALF_ENABLED

typedef struct __align__(4) {
  half x; half y;
} __cuHalfComplex_raw__;

#ifndef __cplusplus

typedef __cuHalfComplex_raw__	cuHalfComplex_raw;
typedef __cuHalfComplex_raw__	cuHalfComplex;

#else

struct __align__(4) __cuHalfComplex__ 
{
 private:
  half x; half y;
 public:
#if __cplusplus >= 201103L
  __cuHalfComplex__() = default;
#else
  __host__ __device__ __forceinline__
    __cuHalfComplex__() { }
#endif
  __host__ __device__ __forceinline__
    __cuHalfComplex__( const __cuHalfComplex_raw__ &h ) { x = h.x; y = h.y; }
  __host__ __device__ __forceinline__
    __cuHalfComplex__ &operator= ( const __cuHalfComplex_raw__ &h ) { x = h.x; y = h.y; return *this; }
  __host__ __device__ __forceinline__
    operator __cuHalfComplex_raw__() const { __cuHalfComplex_raw__ h; h.x = x; h.y = y; return h; }

  __host__ __device__ __forceinline__
    __cuHalfComplex__( const half &a, const half &b ) { x = a; y = b; }

  __host__ __device__ __forceinline__
    __cuHalfComplex_raw__ * raw( void ) { return reinterpret_cast<__cuHalfComplex_raw__*>(this); }

  __host__ __device__ __forceinline__
    operator half() const {
    return x;
  }

  __host__ __device__ __forceinline__
    half real() const {
    return x;
  }
  __host__ __device__ __forceinline__
    half imag() const {
    return y;
  }
  __host__ __device__ __forceinline__
    half real(const half x) {
    this->x = x; return x;
  }
  __host__ __device__ __forceinline__
    half imag(const half y) {
    this->y = y; return y;
  }
};

typedef struct __cuHalfComplex__	cuHalfComplex;
typedef        __cuHalfComplex_raw__	cuHalfComplex_raw;

#if defined(__NVCC__)

__device__ __forceinline__ half
get_real( cuHalfComplex &a )
{ return a.real(); }

__device__ __forceinline__ half
get_imag( cuHalfComplex &a )
{ return a.imag(); }

__device__ __forceinline__ void
set_real( cuHalfComplex &a, const half x )
{ a.real( x ); }

__device__ __forceinline__ void
set_imag( cuHalfComplex &a, const half y )
{ a.imag( y ); }

__device__ __forceinline__ cuHalfComplex
Conj ( const cuHalfComplex a ) {
  cuHalfComplex_raw t_ = a;
  t_.y = (-t_.y);
  return t_;
}


__device__ __forceinline__ cuHalfComplex
fma ( const cuHalfComplex a, const cuHalfComplex b, const cuHalfComplex c )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  const cuHalfComplex_raw c_ = c;
  cuHalfComplex_raw t_;
  t_.x = fma( a_.x, b_.x, c_.x );
  t_.y = fma( a_.x, b_.y, c_.y );
  const half e = -a_.y;
  t_.x = fma( e, b_.y, t_.x );
  t_.y = fma( a_.y, b_.x, t_.y );
  return t_;
}

// comparation operator on host is not supported yet
__device__ __forceinline__ bool
operator== ( const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  const bool ret = ((a_.x == b_.x) && (a_.y == b_.y)) ? true : false;
  return ret;
}

// comparation operator on host is not supported yet
__device__ __forceinline__ bool
operator!= ( const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  const bool ret = ((a_.x != b_.x) || (a_.y != b_.y)) ? true : false;
  return ret;
}

__device__ __forceinline__ cuHalfComplex
operator+  ( const cuHalfComplex a )
{
  return a;
}

__device__ __forceinline__ cuHalfComplex
operator+  ( const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  cuHalfComplex_raw t_;
  t_.x = a_.x + b_.x;
  t_.y = a_.y + b_.y;
  return t_;
}

__device__ __forceinline__ void
operator+= ( cuHalfComplex &a, const cuHalfComplex b )
{
  a = (a + b);
}

__device__ __forceinline__ cuHalfComplex
operator- ( const cuHalfComplex a )
{
  const cuHalfComplex_raw a_ = a;
  cuHalfComplex_raw t_ = a_;
  t_.x = - t_.x;
  t_.y = - t_.y;
  return  t_;
}

__device__ __forceinline__ cuHalfComplex
operator-  ( const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  cuHalfComplex_raw t_;
  t_.x = a_.x - b_.x;
  t_.y = a_.y - b_.y;
  return  t_;
}

__device__ __forceinline__ void
operator-= ( cuHalfComplex &a, const cuHalfComplex b )
{
  a = (a - b);
}

__device__ __forceinline__ cuHalfComplex
operator* ( const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  cuHalfComplex_raw t_;
  half e = -a_.y;
  t_.x = a_.x * b_.x;
  t_.y = a_.x * b_.y;
  t_.x = t_.x + e * b_.y;
  t_.y = t_.y + a_.y * b_.x;
  return  t_;
}

__device__ __forceinline__ cuHalfComplex
operator* ( const cuHalfComplex a, const half b )
{
  const cuHalfComplex_raw a_ = a;
  cuHalfComplex_raw t_;
  t_.x = a_.x * b;
  t_.y = a_.y * b;
  return  t_;
}

__device__ __forceinline__ cuHalfComplex
operator* ( const half a, const cuHalfComplex b )
{
  return (b * a);
}

__device__ __forceinline__ void
operator*= ( cuHalfComplex &a, const cuHalfComplex b )
{
  a = (a * b);
}

__device__ __forceinline__ void
operator*= ( cuHalfComplex &a, const half b )
{
  a = (a * b);
}

__device__ __forceinline__ cuHalfComplex
operator/ ( const cuHalfComplex a, const half b )
{
  const cuHalfComplex_raw a_ = a;
  cuHalfComplex_raw t_;
  t_.x = hdiv(a_.x, b);
  t_.y = hdiv(a_.y, b);
  return  t_;
}

__device__ __forceinline__ cuHalfComplex
operator/ ( const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  const half r = a_.x * b_.x + a_.y * b_.y;
  const cuHalfComplex_raw t_ = (a * Conj(b)) / r;
  return  t_;
}

__device__ __forceinline__ void
operator/= ( cuHalfComplex &a, const cuHalfComplex b )
{
  a = ( a / b );
}

__device__ __forceinline__ void
operator/= ( cuHalfComplex &a, const half b )
{
  a = ( a / b );
}

__device__ __forceinline__ cuHalfComplex
fma ( const cuHalfComplex a, const half b, const cuHalfComplex c )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw c_ = c;
  cuHalfComplex_raw t_;
  t_.x = fma( a_.x, b, c_.x );
  t_.y = fma( a_.y, b, c_.y );
  return t_;
}

__device__ __forceinline__ cuHalfComplex
fma ( const half a, const cuHalfComplex b, const cuHalfComplex c )
{
  return fma( b, a, c );
}

#if 0
__device__ __forceinline__ int
isnan ( const cuHalfComplex a )
{
  const cuHalfComplex_raw a_ = a;
  return (isnan(a_.x) || isnan(a_.y));
}

__device__ __forceinline__ int
isinf ( const cuHalfComplex a )
{
  const cuHalfComplex_raw a_ = a;
  return (isinf(a_.x) || isinf(a_.y));
}
#endif

__device__ __forceinline__ int
isfinite ( const cuHalfComplex a )
{
  const cuHalfComplex_raw a_ = a;
  return (isfinite(a_.x) && isfinite(a_.y));
}

__device__ __forceinline__ half
Abs ( const cuHalfComplex a )
{
  const cuHalfComplex_raw a_ = a;
  const half r2 = a_.x*a_.x + a_.y*a_.y;
  const half t = (half)sqrt( (float)r2 );
  return t;
}

__device__ __forceinline__ void
makeConj ( cuHalfComplex & a ) {
  set_imag(a, -get_imag(a));
}

__device__ __forceinline__ cuHalfComplex
__choose__ ( const bool flag, const cuHalfComplex a, const cuHalfComplex b )
{
  const cuHalfComplex_raw a_ = a;
  const cuHalfComplex_raw b_ = b;
  cuHalfComplex_raw t_;
  t_.x = __choose__( flag, a_.x, b_.x );
  t_.y = __choose__( flag, a_.y, b_.y );
  return t_;
}

#if 0
__forceinline__ __device__ cuHalfComplex
__select__( const int cond, const cuHalfComplex case_pos, const cuHalfComplex case_neg )
{
  const cuHalfComplex_raw case_pos_ = case_pos;
  const cuHalfComplex_raw case_neg_ = case_neg;
  cuHalfComplex_raw t_;
  t_.x = __select__( cond, case_pos_.x, case_neg_.x );
  t_.y = __select__( cond, case_pos_.y, case_neg_.y );
  return t_;
}
#endif

#endif

#endif

#endif

#endif


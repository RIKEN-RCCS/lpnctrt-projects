#ifndef ASPEN_INT32_H_INCLUDED
#define ASPEN_INT32_H_INCLUDED		1

#include <stdint.h>
typedef int32_t	int32;

#ifdef __cplusplus

// for int

__host__ __device__ __forceinline__ int32
__add ( const int32 a,  const int32 b )
{
  const int32 t = (a + b);
  return  t;
}

__host__ __device__ __forceinline__ void
add2 ( const int32 a1, const int32 b1, int32 &d1,
       const int32 a2, const int32 b2, int32 &d2 )
{
  const int32 t1 = __add( a1, b1 );
  const int32 t2 = __add( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int32
__sub ( const int32 a,  const int32 b )
{
  const int32 t = (a - b);
  return  t;
}

__host__ __device__ __forceinline__ void
sub2 ( const int32 a1, const int32 b1, int32 &d1,
       const int32 a2, const int32 b2, int32 &d2 )
{
  const int32 t1 = __sub( a1, b1 );
  const int32 t2 = __sub( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int32
__mul ( const int32 a,  const int32 b )
{
  const int32 t = (a * b);
  return  t;
}

__host__ __device__ __forceinline__ void
mul2 ( const int32 a1, const int32 b1, int32 &d1,
       const int32 a2, const int32 b2, int32 &d2 )
{
  const int32 t1 = __mul( a1, b1 );
  const int32 t2 = __mul( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int32
fma ( const int32 a, const int32 b, const int32 c )
{
  const int32 t = (a * b + c);
  return  t;
}

__host__ __device__ __forceinline__ void
fma2 ( const int32 a1, const int32 b1, const int32 c1, int32 &d1,
       const int32 a2, const int32 b2, const int32 c2, int32 &d2 )
{
  const int32 t1 = fma( a1, b1, c1 );
  const int32 t2 = fma( a2, b2, c2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int
isnan ( const int32 a )
{
  return false;
}

__host__ __device__ __forceinline__ int
isinf ( const int32 a )
{
  return false;
}

__host__ __device__ __forceinline__ int
isfinite ( const int32 a )
{
  return true;
}

__host__ __device__ __forceinline__ int32
Abs ( const int32 a )
{
  int32  t;
#if defined(__CUDA_ARCH__)
  asm volatile ( "abs.s32\t%0, %1;"
                 : "=r"(t) : "r"(a) );
#else
  t = ( a >= 0 ? a : -a );
#endif
  return  t;
}

__host__ __device__ __forceinline__ int32
Conj ( const int32 a )
{
  return ( a );
}

__host__ __device__ __forceinline__ int32
__choose__ ( const bool flag, const int32 a, const int32 b )
{
  return ( flag ? a : b );
}

__forceinline__ __device__ int32
__choose__( const int cond, const int32 case_pos, const int32 case_neg )
{
  int32 r;
#if defined(__CUDA_ARCH__)
  asm volatile ( "slct.b32.s32\t%0, %1, %2, %3;"
                 : "=r"(r) : "r"(case_pos), "r"(case_neg), "r"(cond) );
#else
  r = ( cond>=0 ? case_pos : case_neg );
#endif
  return r;
}

#endif

#endif


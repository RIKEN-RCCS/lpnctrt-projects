#ifndef ASPEN_DDREAL_H_INCLUDED
#define ASPEN_DDREAL_H_INCLUDED		1

#include <stdint.h>
#include <cuComplex.h>
#include "aspen_real.h"

#define ASPEN_DDREAL_struct_body                \
  double x; double y

typedef struct __align__(16) {
  ASPEN_DDREAL_struct_body;
} __cuddreal_raw__;

#ifndef __cplusplus

typedef	__cuddreal_raw__	cuddreal_raw;
typedef	__cuddreal_raw__	cuddreal;

#else

struct __align__(16) __cuddreal__
{
 private:
  ASPEN_DDREAL_struct_body;
 public:
#if __cplusplus >= 201103L
  __cuddreal__() = default;
#else
  __host__ __device__ __forceinline__
    __cuddreal__() { }
#endif
  __host__ __device__ __forceinline__
    __cuddreal__( const __cuddreal_raw__ &h ) { x = h.x; y = h.y; }
  __host__ __device__ __forceinline__
    __cuddreal__ &operator= ( const __cuddreal_raw__ &h ) { x = h.x; y = h.y; return *this; }
  __host__ __device__ __forceinline__
    operator __cuddreal_raw__() const { __cuddreal_raw__ h; h.x = x; h.y = y; return h; }

  __host__ __device__ __forceinline__
    __cuddreal__( const double hi, const double err ) { x = hi; y = err; }
  __host__ __device__ __forceinline__
    __cuddreal__( const double hi ) { x = hi; y = (double)0.; }

  template < class T >
    __host__ __device__ __forceinline__
    operator T() const {
    return (T)(x);
  }

  __host__ __device__ __forceinline__
    __cuddreal_raw__ * raw( void ) { return reinterpret_cast<__cuddreal_raw__*>(this); }

  __host__ __device__ __forceinline__
    double hi(void) const {
    return x;
  }
  __host__ __device__ __forceinline__
    double err(void) const {
    return y;
  }
  __host__ __device__ __forceinline__
    double hi(const double x) {
    this->x = x; return x;
  }
  __host__ __device__ __forceinline__
    double err(const double y) {
    this->y = y; return y;
  }
};

typedef	struct __cuddreal__		cuddreal;
typedef	       __cuddreal_raw__		cuddreal_raw;


#if GPU_ARCH>300
__device__ __forceinline__ cuddreal
__ldg ( const cuddreal * a )
{
  cuddreal * aa = (cuddreal *)a;
  const double2 * p = (reinterpret_cast<double2 *>(aa));
  double2 b = __ldg( p );
  const cuddreal_raw c = *(reinterpret_cast<cuddreal_raw *>(&b));
  return c;
}
#endif


__host__ __device__ __forceinline__ bool
operator== ( const cuddreal a, const cuddreal b )
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  const bool ret = ((a_.x == b_.x) && (a_.y == b_.y)) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator== ( const double a, const cuddreal b )
{
  const cuddreal c = __cuddreal__( a, (double)0. );
  return (c == b);
}

__host__ __device__ __forceinline__ bool
operator== ( const cuddreal a, const double b )
{
  return (b == a);
}

__host__ __device__ __forceinline__ bool
operator!= ( const cuddreal a, const cuddreal b)
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  const bool ret = ((a_.x != b_.x) || (a_.y != b_.y)) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator!= ( const double a, const cuddreal b)
{
  const cuddreal c = __cuddreal__( a, (double)0. );
  return (c != b);
}

__host__ __device__ __forceinline__ bool
operator!= ( const cuddreal a, const double b)
{
  return (b != a);
}

__host__ __device__ __forceinline__ bool
operator< ( const cuddreal a, const cuddreal b)
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  bool ret;
  if ( a_.x == b_.x ) {
    ret = (a_.y < b_.y) ? true : false;
  } else {
    ret = (a_.x < b_.x) ? true : false;
  }
  return ret;
}

__host__ __device__ __forceinline__ bool
operator< ( const double a, const cuddreal b)
{
  const cuddreal c = __cuddreal__( a, (double)0. );
  return (c < b);
}

__host__ __device__ __forceinline__ bool
operator< ( const cuddreal a, const double b)
{
  const cuddreal c = __cuddreal__( b, (double)0. );
  return (a < c);
}

__host__ __device__ __forceinline__ bool
operator> ( const cuddreal a, const cuddreal b)
{
  return (b < a);
}

__host__ __device__ __forceinline__ bool
operator> ( const double a, const cuddreal b)
{
  return (b < a);
}

__host__ __device__ __forceinline__ bool
operator> ( const cuddreal a, const double b)
{
  return (b < a);
}

__host__ __device__ __forceinline__ bool
operator<= ( const cuddreal a, const cuddreal b)
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  bool ret;
  if ( a_.x == b_.x ) {
    ret = (a_.y <= b_.y) ? true : false;
  } else {
    ret = (a_.x < b_.x) ? true : false;
  }
  return ret;
}

__host__ __device__ __forceinline__ bool
operator<= ( const double a, const cuddreal b)
{
  const cuddreal c = __cuddreal__( a, (double)0. );
  return (c <= b);
}

__host__ __device__ __forceinline__ bool
operator<= ( const cuddreal a, const double b)
{
  const cuddreal c = __cuddreal__( b, (double)0. );
  return (a <= c);
}

__host__ __device__ __forceinline__ bool
operator>= ( const cuddreal a, const cuddreal b)
{
  return (b <= a);
}

__host__ __device__ __forceinline__ bool
operator>= ( const double a, const cuddreal b)
{
  return (b <= a);
}

__host__ __device__ __forceinline__ bool
operator>= ( const cuddreal a, const double b)
{
  return (b <= a);
}


__host__ __device__ __forceinline__ double
__fmad ( const double a,  const double b, const double c )
{
  return  fma ( a, b, c );
}


__host__ __device__ __forceinline__ void
cuTwoSum ( const double a, const double b, double &s, double &e )
{
  const double  S = __add ( a, b );
  const double  u = __sub ( S, a );
  const double  v = __sub ( S, u );
  const double  p = __sub ( a, v );
  const double  q = __sub ( b, u );
  const double  E = __add ( p, q );
  s = S; e = E;
}

__host__ __device__ __forceinline__ void
cuTwoSum2 ( const double a1, const double b1, double &s1, double &e1,
            const double a2, const double b2, double &s2, double &e2 )
{
  const double  S1 = __add ( a1, b1 );
  const double  S2 = __add ( a2, b2 );
  const double  u1 = __sub ( S1, a1 );
  const double  u2 = __sub ( S2, a2 );
  const double  v1 = __sub ( S1, u1 );
  const double  v2 = __sub ( S2, u2 );
  const double  p1 = __sub ( a1, v1 );
  const double  p2 = __sub ( a2, v2 );
  const double  q1 = __sub ( b1, u1 );
  const double  q2 = __sub ( b2, u2 );
  const double  E1 = __add ( p1, q1 );
  const double  E2 = __add ( p2, q2 );
  s1 = S1; e1 = E1;
  s2 = S2; e2 = E2;
}

__host__ __device__ __forceinline__ void
cuQuickTwoSum ( const double a, const double b, double &s, double &e )
{
  const double  S = __add ( a, b );
  const double  v = __sub ( S, a );
  const double  E = __sub ( b, v );
  s = S; e = E;
}

__host__ __device__ __forceinline__ void
cuQuickTwoSum2 ( const double a1, const double b1, double &s1, double &e1,
                 const double a2, const double b2, double &s2, double &e2 )
{
  const double  S1 = __add ( a1, b1 );
  const double  S2 = __add ( a2, b2 );
  const double  v1 = __sub ( S1, a1 );
  const double  v2 = __sub ( S2, a2 );
  const double  E1 = __sub ( b1, v1 );
  const double  E2 = __sub ( b2, v2 );
  s1 = S1; e1 = E1;
  s2 = S2; e2 = E2;
}

__host__ __device__ __forceinline__ void
cuTwoProdFMA ( const double a, const double b, double &s, double &e )
{
  const double  S = __mul ( a, b );
  const double  E = __fmad ( a, b, -S );
  s = S; e = E;
}

__host__ __device__ __forceinline__ cuddreal
CUWADD ( const cuddreal a, const cuddreal b )
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  cuddreal_raw t_, c_;
  cuTwoSum ( a_.x, b_.x, t_.x, t_.y );
  const double  r = __add( a_.y, b_.y );
  t_.y = __add ( t_.y, r );
  cuQuickTwoSum ( t_.x, t_.y, c_.x, c_.y );
  return c_;
}

__host__ __device__ __forceinline__ cuddreal
CUwADD ( const double a, const cuddreal b )
{
  const cuddreal_raw b_ = b;
  cuddreal_raw t_, c_;
  cuTwoSum ( a, b_.x, t_.x, t_.y );
  t_.y = __add ( t_.y, b_.y );
  cuQuickTwoSum ( t_.x, t_.y, c_.x, c_.y );
  return c_;
}

__host__ __device__ __forceinline__ cuddreal
CUwADD ( const cuddreal a, const double b )
{
  const cuddreal_raw a_ = a;
  cuddreal_raw t_, c_;
  cuTwoSum ( a_.x, b, t_.x, t_.y );
  t_.y = __add ( t_.y, a_.y );
  cuQuickTwoSum ( t_.x, t_.y, c_.x, c_.y );
  return c_;
}

__host__ __device__ __forceinline__ void
CUWADD2 ( const cuddreal a1, const cuddreal b1, cuddreal &d1,
          const cuddreal a2, const cuddreal b2, cuddreal &d2 )
{
  const cuddreal_raw a1_ = a1;
  const cuddreal_raw a2_ = a2;
  const cuddreal_raw b1_ = b1;
  const cuddreal_raw b2_ = b2;
  cuddreal_raw t1_,t2_, c1_,c2_;
  cuTwoSum2 ( a1_.x, b1_.x, t1_.x, t1_.y,
              a2_.x, b2_.x, t2_.x, t2_.y );
  const double  r1 = __add( a1_.y, b1_.y );
  const double  r2 = __add( a2_.y, b2_.y );
  t1_.y = __add ( t1_.y, r1 );
  t2_.y = __add ( t2_.y, r2 );
  cuQuickTwoSum2 ( t1_.x, t1_.y, c1_.x, c1_.y,
                   t2_.x, t2_.y, c2_.x, c2_.y );
  d1    = c1_;
  d2    = c2_;
}

__host__ __device__ __forceinline__ cuddreal
CUWSUB ( const cuddreal a, const cuddreal b )
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  cuddreal_raw t_, c_;
  cuTwoSum ( a_.x, -b_.x, t_.x, t_.y );
  t_.y = __add ( t_.y, __sub ( a_.y, b_.y ) );
  cuQuickTwoSum ( t_.x, t_.y, c_.x, c_.y );
  return c_;
}

__host__ __device__ __forceinline__ cuddreal
CUwSUB ( const double a, const cuddreal b )
{
  const cuddreal_raw b_ = b;
  cuddreal_raw t_, c_;
  cuTwoSum ( a, -b_.x, t_.x, t_.y );
  t_.y = __sub ( t_.y, b_.y );
  cuQuickTwoSum ( t_.x, t_.y, c_.x, c_.y );
  return c_;
}

__host__ __device__ __forceinline__ cuddreal
CUwSUB ( const cuddreal a, const double b )
{
  const cuddreal_raw a_ = a;
  cuddreal_raw t_, c_;
  cuTwoSum ( a_.x, -b, t_.x, t_.y );
  t_.y = __add ( t_.y, a_.y );
  cuQuickTwoSum ( t_.x, t_.y, c_.x, c_.y );
  return c_;
}

__host__ __device__ __forceinline__ void
CUWSUB2 ( const cuddreal a1, const cuddreal b1, cuddreal &d1,
          const cuddreal a2, const cuddreal b2, cuddreal &d2 )
{
  const cuddreal_raw a1_ = a1;
  const cuddreal_raw a2_ = a2;
  const cuddreal_raw b1_ = b1;
  const cuddreal_raw b2_ = b2;
  cuddreal_raw t1_,t2_, c1_,c2_;
  cuTwoSum ( a1_.x, -b1_.x, t1_.x, t1_.y );
  cuTwoSum ( a2_.x, -b2_.x, t2_.x, t2_.y );
  t1_.y = __add ( t1_.y, __sub ( a1_.y, b1_.y ) );
  t2_.y = __add ( t2_.y, __sub ( a2_.y, b2_.y ) );
  cuQuickTwoSum ( t1_.x, t1_.y, c1_.x, c1_.y );
  cuQuickTwoSum ( t2_.x, t2_.y, c2_.x, c2_.y );
  d1    = c1_;
  d2    = c2_;
}

__host__ __device__ __forceinline__ cuddreal
CUWMUL ( const cuddreal a, const cuddreal b )
{
#if 0
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  double t, e;
  cuddreal_raw c_;
  cuTwoProdFMA ( a_.x, b_.x, t, e );
  e = __add ( e, __add( __mul( a_.x, b_.y ), __mul( a_.y, b_.x ) ) );
  cuQuickTwoSum ( t, e, c_.x, c_.y );
  return c_;
#else
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  double t, e;
  cuddreal_raw c_;
  t    = __fmad ( a_.y, b_.x, __mul( a_.x, b_.y ) );
  c_.x = __fmad ( a_.x, b_.x, t );
  e    = __fmad ( a_.x, b_.x, -c_.x );
  c_.y = __add ( e, t );
  return c_;
#endif
}

__host__ __device__ __forceinline__ cuddreal
CUwMUL ( const double a, const cuddreal b )
{
  const cuddreal_raw b_ = b;
  double t, e;
  cuddreal_raw c_;
  t    = __mul( a, b_.y );
  c_.x = __fmad ( a, b_.x, t );
  e    = __fmad ( a, b_.x, -c_.x );
  c_.y = __add ( e, t );
  return c_;
}

__host__ __device__ __forceinline__ cuddreal
CUwMUL ( const cuddreal a, const double b )
{
  const cuddreal_raw a_ = a;
  double t, e;
  cuddreal_raw c_;
  t    = __mul ( a_.y, b );
  c_.x = __fmad ( a_.x, b, t );
  e    = __fmad ( a_.x, b, -c_.x );
  c_.y = __add ( e, t );
  return c_;
}

__host__ __device__ __forceinline__ void
CUWMUL2 ( const cuddreal a1, const cuddreal b1, cuddreal &d1,
          const cuddreal a2, const cuddreal b2, cuddreal &d2 )
{
  const cuddreal_raw a1_ = a1;
  const cuddreal_raw a2_ = a2;
  const cuddreal_raw b1_ = b1;
  const cuddreal_raw b2_ = b2;
  double t1,t2, e1,e2;
  double s1,s2;
  cuddreal_raw c1_,c2_;
  s1    = __mul( a1_.x, b1_.y );
  s2    = __mul( a2_.x, b2_.y );
  t1    = __fmad ( a1_.y, b1_.x, s1 );
  t2    = __fmad ( a2_.y, b2_.x, s2 );
  c1_.x = __fmad ( a1_.x, b1_.x, t1 );
  c2_.x = __fmad ( a2_.x, b2_.x, t2 );
  s1    = -c1_.x;
  s2    = -c2_.x;
  e1    = __fmad ( a1_.x, b1_.x, s1 );
  e2    = __fmad ( a2_.x, b2_.x, s2 );
  c1_.y = __add ( e1, t1 );
  c2_.y = __add ( e2, t2 );
  d1    = c1_;
  d2    = c2_;
}


__host__ __device__ __forceinline__ cuddreal
operator+ ( const cuddreal a )
{
  return a;
}

__host__ __device__ __forceinline__ cuddreal
operator+ ( const cuddreal a, const cuddreal b )
{
  return CUWADD ( a, b );
}

__host__ __device__ __forceinline__ cuddreal
operator+ ( const double a, const cuddreal b )
{
  return CUwADD ( a, b );
}

__host__ __device__ __forceinline__ cuddreal
operator+ ( const cuddreal a, const double b )
{
  return CUwADD ( a, b );
}

__host__ __device__ __forceinline__ void
operator+= ( cuddreal &a, const cuddreal b )
{
  a = ( a + b );
}

__host__ __device__ __forceinline__ void
operator+= ( cuddreal &a, const double b )
{
  a = ( a + b );
}

__host__ __device__ __forceinline__ cuddreal
operator- ( const cuddreal a )
{
  cuddreal_raw r_ = a;
  r_.x = - r_.x;
  r_.y = - r_.y;
  return r_;
}

__host__ __device__ __forceinline__ cuddreal
operator- ( const cuddreal a, const cuddreal b )
{
  return CUWSUB ( a, b );
}

__host__ __device__ __forceinline__ cuddreal
operator- ( const double a, const cuddreal b )
{
  return CUwSUB ( a, b );
}

__host__ __device__ __forceinline__ cuddreal
operator- ( const cuddreal a, const double b )
{
  return CUwSUB ( a, b );
}

__host__ __device__ __forceinline__ void
operator-= ( cuddreal &a, const cuddreal b )
{
  a = ( a - b );
}

__host__ __device__ __forceinline__ void
operator-= ( cuddreal &a, const double b )
{
  a = ( a - b );
}

__host__ __device__ __forceinline__ cuddreal
operator* ( const cuddreal a, const cuddreal b )
{
  return CUWMUL ( a, b );
}

__host__ __device__ __forceinline__ cuddreal
operator* ( const cuddreal a, const double b )
{
  return CUwMUL ( a, b );
}

__host__ __device__ __forceinline__ cuddreal
operator* ( const double a, const cuddreal b )
{
  return CUwMUL ( a, b );
}

__host__ __device__ __forceinline__ void
operator*= ( cuddreal &a, const cuddreal b )
{
  a = ( a * b );
}

__host__ __device__ __forceinline__ void
operator*= ( cuddreal &a, const double b )
{
  a = ( a * b );
}

__host__ __device__ __forceinline__ cuddreal
fma ( const cuddreal a, const cuddreal b, const cuddreal c )
{
  const cuddreal  t = (a * b) + c;
  return t;
}

__host__ __device__ __forceinline__ cuddreal
fma ( const cuddreal a, const double b, const cuddreal c )
{
  const cuddreal  t = (a * b) + c;
  return t;
}

__host__ __device__ __forceinline__ cuddreal
fma ( const double a, const cuddreal b, const cuddreal c )
{
  const cuddreal  t = (a * b) + c;
  return t;
}

__host__ __device__ __forceinline__ cuddreal
fma ( const double a, const double b, const cuddreal c )
{
  const double    ab  = a*b;
  const cuddreal  ab_ = __cuddreal__( ab, fma(a, b, -ab) );
  const cuddreal  t   = ab_ + c;
  return t;
}

__host__ __device__ __forceinline__ cuddreal
CUWDIV ( const cuddreal a, const cuddreal b )
{
  const cuddreal ZERO   = __cuddreal__( (double)0., (double)0. );
  const cuddreal ONE    = __cuddreal__( (double)1., (double)0. );
  const cuddreal MONE   = __cuddreal__( (double)-1., (double)0. );
  const cuddreal NAN_DD = __cuddreal__( (double)NAN, (double)NAN );

  if ( b == ZERO ) { return NAN_DD; }
  if ( a == ZERO ) { return ZERO; }
  if ( b == ONE  ) { return a; }
  if ( b == MONE ) { return -a; }

  /* A.H.Karp and P.Markstein:
   * High Precision Division and Square Root,
   * ATOMS, 23(4), 1997, p.561-589.
   *
   *  when x=Approx(a/b),
   *  y = b*x
   *  Y = y + x(b-a*y) = goodApprox(a/b)
   */
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = a;
  const double   xn     = a_.x / b_.x;
  const cuddreal yn     = b * xn;
  const cuddreal T      = a * yn;
  cuddreal       t      = b - T;
  t *= xn;
  const cuddreal Y      = yn + t;

  return Y;
}

__host__ __device__ __forceinline__ cuddreal
operator/ ( const cuddreal a, const cuddreal b )
{
  const cuddreal t = CUWDIV ( a, b );
  return t;
}

__host__ __device__ __forceinline__ void
operator/= ( cuddreal &a, const cuddreal b )
{
  a = ( a / b );
}


__host__ __device__ __forceinline__ void
add2 ( const cuddreal a1, const cuddreal b1, cuddreal &d1,
       const cuddreal a2, const cuddreal b2, cuddreal &d2 )
{
  cuddreal  t1,t2;
  CUWADD2 ( a1, b1, t1, a2, b2, t2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
sub2 ( const cuddreal a1, const cuddreal b1, cuddreal &d1,
       const cuddreal a2, const cuddreal b2, cuddreal &d2 )
{
  cuddreal  t1,t2;
  CUWSUB2 ( a1, b1, t1, a2, b2, t2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
mul2 ( const cuddreal a1, const cuddreal b1, cuddreal &d1,
       const cuddreal a2, const cuddreal b2, cuddreal &d2 )
{
  cuddreal  t1,t2;
  CUWMUL2 ( a1, b1, t1, a2, b2, t2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ void
fma2 ( const cuddreal a1, const cuddreal b1, const cuddreal c1, cuddreal &d1,
       const cuddreal a2, const cuddreal b2, const cuddreal c2, cuddreal &d2 )
{
  cuddreal  t1,t2;
  CUWMUL2 ( a1, b1, t1, a2, b2, t2 );
  CUWADD2 ( c1, t1, t1, c2, t2, t2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int
isnan ( const cuddreal a )
{
  const cuddreal_raw a_ = a;
  return (isnan(a_.x) || isnan(a_.y));
}

__host__ __device__ __forceinline__ int
isinf ( const cuddreal a )
{
  const cuddreal_raw a_ = a;
  return (isinf(a_.x) || isinf(a_.y));
}

__host__ __device__ __forceinline__ int
isfinite ( const cuddreal a )
{
  const cuddreal_raw a_ = a;
#if defined(__CUDA_ARCH__)
  const uint32_t mask = 0x7ff00000;
  const uint32_t b1 = __double2hiint( a_.x );
  const uint32_t b2 = __double2hiint( a_.y );
  return ( (b1 & mask) != mask && (b2 & mask) != mask );
#else
  return (isfinite(a_.x) && isfinite(a_.y));
#endif
}

__host__ __device__ __forceinline__ cuddreal
Abs ( const cuddreal a )
{
  const cuddreal_raw a_ = a;
  cuddreal_raw r_;
  r_.x = fabs(a_.x);
  r_.y = fabs(a_.y);
  return r_;
}

__host__ __device__ __forceinline__ cuddreal
Conj ( const cuddreal a )
{
  return a;
}


__host__ __device__ __forceinline__ cuddreal
Sqrt ( const cuddreal a )
{
  const cuddreal ZERO   = __cuddreal__( (double)0., (double)0. );
  const cuddreal NAN_DD = __cuddreal__( (double)NAN, (double)NAN );

  if ( a == ZERO ) { return a; };
  if ( a < ZERO ) { return NAN_DD; }

  /* A.H.Karp and P.Markstein:
   * High Precision Division and Square Root,
   * ATOMS, 23(4), 1997, p.561-589.
   *
   *  when x=Approx(1/sqrt(a)),
   *  y = a*x
   *  Y = y + (x/2)(a-y^2) = goodApprox(sqrt(a))
   */
  const cuddreal_raw a_ = a;
  double         xn     = (double)1. / sqrt(a_.x);
  const cuddreal yn     = a * xn;
  const cuddreal T      = yn * yn;
  cuddreal       t      = a - T;
  xn /= 2; t *= xn;
  const cuddreal Y      = yn + t;

  return Y;
}

__host__ __device__ __forceinline__ cuddreal
__choose__ ( const bool flag, const cuddreal a, const cuddreal b )
{
  const cuddreal_raw a_ = a;
  const cuddreal_raw b_ = b;
  cuddreal_raw r_;
  r_.x = (flag ? a_.x : b_.x);
  r_.y = (flag ? a_.y : b_.y);
  return r_;
}

__forceinline__ __device__ cuddreal
__select__( const int cond, const cuddreal case_pos, const cuddreal case_neg )
{
  const cuddreal_raw case_pos_ = case_pos;
  const cuddreal_raw case_neg_ = case_neg;
  cuddreal_raw r_;
  r_.x = __select__( cond, case_pos_.x, case_neg_.x );
  r_.y = __select__( cond, case_pos_.y, case_neg_.y );
  return r_;
}

#endif
#undef ASPEN_DDREAL_struct_body

#endif


#ifndef ASPEN_TEXTURE_H_INCLUDED
#define ASPEN_TEXTURE_H_INCLUDED		1

// this header will be deprecated in future versions
// definition for Texture memory

#if __isDD__
#define	DEF_TEXTURE( Tex_x, X_, ... )                   \
  texture < uint4, 1 > Tex_x;                           \
  __forceinline__ __device__ scalar_t                   \
  X_ ( const int i )                                    \
  {                                                     \
    const uint4 v = tex1Dfetch ( Tex_x, i );            \
    const double wx = __hiloint2double ( v.y, v.x );    \
    const double wy = __hiloint2double ( v.w, v.z );    \
    const cuddreal V = { wx, wy };                      \
    return V;                                           \
  }
#endif

#if __isDOUBLE__
#define	DEF_TEXTURE( Tex_x, X_, ... )                   \
  texture < uint2, 1 > Tex_x;                           \
  __forceinline__ __device__ scalar_t                   \
  X_ ( const int i )                                    \
  {                                                     \
    const uint2 v = tex1Dfetch ( Tex_x, i );            \
    const double V = __hiloint2double ( v.y, v.x );     \
    return V;                                           \
  }
#endif

#if __isFLOAT__
#define	DEF_TEXTURE( Tex_x, X_, ... )           \
  texture < float, 1 > Tex_x;                   \
  __forceinline__ __device__ scalar_t           \
  X_ ( const int i )                            \
  {                                             \
    const float v = tex1Dfetch ( Tex_x, i );    \
    return (scalar_t) v;                        \
  }
#endif

#if __isDD_COMPLEX__
#define	DEF_TEXTURE( Tex_x, X_, ... )                   \
  texture < uint4, 1 > Tex_x;                           \
  __forceinline__ __device__ scalar_t                   \
  X_ ( const int i )                                    \
  {                                                     \
    const uint4 v1 = tex1Dfetch ( Tex_x, i*2 );         \
    const double w1x = __hiloint2double ( v1.y, v1.x ); \
    const double w1y = __hiloint2double ( v1.w, v1.z ); \
    const cuddreal V1 = { w1x, w1y };                   \
    const uint4 v2 = tex1Dfetch ( Tex_x, i*2+1 );       \
    const double w2x = __hiloint2double ( v2.y, v2.x ); \
    const double w2y = __hiloint2double ( v2.w, v2.z ); \
    const cuddreal V2 = { w2x, w2y };                   \
    const cuddcomplex V = { V1, V2 };                   \
    return V;                                           \
  }
#endif

#if __isDOUBLE_COMPLEX__
#define	DEF_TEXTURE( Tex_x, X_, ... )                   \
  texture < uint4, 1 > Tex_x;                           \
  __forceinline__ __device__ scalar_t                   \
  X_ ( const int i )                                    \
  {                                                     \
    const uint4 v = tex1Dfetch ( Tex_x, i );            \
    const double wx = __hiloint2double ( v.y, v.x );    \
    const double wy = __hiloint2double ( v.w, v.z );    \
    const cuDoubleComplex V = { wx, wy };               \
    return V;                                           \
  }
#endif

#if __isFLOAT_COMPLEX__
#define	DEF_TEXTURE( Tex_x, X_, ... )           \
  texture < float2, 1 > Tex_x;                  \
  __forceinline__ __device__ scalar_t           \
  X_ ( const int i )                            \
  {                                             \
    const float2 v = tex1Dfetch ( Tex_x, i );   \
    const cuFloatComplex V = { v.x, v.y };      \
    return V;                                   \
  }
#endif


#if __isDD__
#define	SETUP_TEXTURE( Tex_x, x, n, offsetX, ... )			\
  _MACRO_BLOCK_ (							\
                 cudaError_t err;                                       \
                 err = cudaBindTexture (                                \
                                        &offsetX, Tex_x,                \
                                        (int4 *)x,                      \
                                        (n)*sizeof( scalar_t ) );       \
                 if ( err != cudaSuccess ) {                            \
                   printf ( "cannot bind to texture :: %d \n", err );   \
                   return;                                              \
                 }                                                      \
                 offsetX /= sizeof( x[0] );                             \
                                                                        )
#endif

#if __isDOUBLE__
#define	SETUP_TEXTURE( Tex_x, x, n, offsetX, ... )			\
  _MACRO_BLOCK_ (							\
                 cudaError_t err;                                       \
                 err = cudaBindTexture (                                \
                                        &offsetX, Tex_x,                \
                                        (int2 *)x,                      \
                                        (n)*sizeof( scalar_t ) );       \
                 if ( err != cudaSuccess ) {                            \
                   printf ( "cannot bind to texture :: %d \n", err );   \
                   return;                                              \
                 }                                                      \
                 offsetX /= sizeof( x[0] );                             \
                                                                        )
#endif

#if __isFLOAT__
#define	SETUP_TEXTURE( Tex_x, x, n, offsetX, ... )			\
  _MACRO_BLOCK_ (							\
                 cudaError_t err;                                       \
                 err = cudaBindTexture(                                 \
                                       &offsetX, Tex_x,                 \
                                       (float *)x,                      \
                                       (n)*sizeof( scalar_t ) );        \
                 if ( err != cudaSuccess ) {                            \
                   printf ( "cannot bind to texture :: %d \n", err );   \
                   return;                                              \
                 }                                                      \
                 offsetX /= sizeof( x[0] );                             \
                                                                        )
#endif

#if __isDD_COMPLEX__
#define	SETUP_TEXTURE( Tex_x, x, n, offsetX, ... )			\
  _MACRO_BLOCK_ (                                                       \
                 cudaError_t err;                                       \
                 err = cudaBindTexture (                                \
                                        &offsetX, Tex_x,                \
                                        (int4 *)x,                      \
                                        (n)*sizeof( scalar_t ) );       \
                 if ( err != cudaSuccess ) {                            \
                   printf ( "cannot bind to texture :: %d \n", err );   \
                   return;                                              \
                 }                                                      \
                 offsetX /= (sizeof( x[0] )/2);                         \
                                                                        )
#endif

#if __isDOUBLE_COMPLEX__
#define	SETUP_TEXTURE( Tex_x, x, n, offsetX, ... )			\
  _MACRO_BLOCK_ (                                                       \
                 cudaError_t err;                                       \
                 err = cudaBindTexture (                                \
                                        &offsetX, Tex_x,                \
                                        (int4 *)x,                      \
                                        (n)*sizeof( scalar_t ) );       \
                 if ( err != cudaSuccess ) {                            \
                   printf ( "cannot bind to texture :: %d \n", err );   \
                   return;                                              \
                 }                                                      \
                 offsetX /= sizeof( x[0] );                             \
                                                                        )
#endif

#if __isFLOAT_COMPLEX__
#define	SETUP_TEXTURE( Tex_x, x, n, offsetX, ... )			\
  _MACRO_BLOCK_ (							\
                 cudaError_t err;                                       \
                 err = cudaBindTexture(                                 \
                                       &offsetX, Tex_x,                 \
                                       (float2 *)x,                     \
                                       (n)*sizeof( scalar_t ) );        \
                 if ( err != cudaSuccess ) {                            \
                   printf ( "cannot bind to texture :: %d \n", err );   \
                   return;                                              \
                 }                                                      \
                 offsetX /= sizeof( x[0] );                             \
                                                                        )
#endif

#endif


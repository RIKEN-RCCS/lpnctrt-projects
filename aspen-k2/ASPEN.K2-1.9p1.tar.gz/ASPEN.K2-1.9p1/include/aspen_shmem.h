#ifndef __ASPEN_SHMEM_H_INCLUDED
#define	__ASPEN_SHMEM_H_INCLUDED		1

typedef	unsigned int		SHMEM_addr_t;

#endif


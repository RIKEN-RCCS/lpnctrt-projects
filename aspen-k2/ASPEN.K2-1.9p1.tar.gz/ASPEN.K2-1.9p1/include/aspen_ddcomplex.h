#ifndef ASPEN_DDCOMPLEX_H_INCLUDED
#define ASPEN_DDCOMPLEX_H_INCLUDED		1

#include <stdint.h>
#include <cuComplex.h>
#include "aspen_ddreal.h"

#define	ASPEN_DDCOMPLEX_struct_body             \
  cuddreal x; cuddreal y

typedef struct __align__(16) {
  ASPEN_DDCOMPLEX_struct_body;
} __cuddcomplex_raw__;

#ifndef __cplusplus

typedef	__cuddcomplex_raw__	cuddcomplex_raw;
typedef	__cuddcomplex_raw__	cuddcomplex;

#else

struct __align__(16) __cuddcomplex__
{
 private:
  ASPEN_DDCOMPLEX_struct_body;
 public:
#if __cplusplus >= 201103L
  __cuddcomplex__() = default;
#else
  __host__ __device__ __forceinline__
    __cuddcomplex__() { }
#endif
  __host__ __device__ __forceinline__
    __cuddcomplex__( const __cuddcomplex_raw__ &h ) { x = h.x; y = h.y; }
  __host__ __device__ __forceinline__
    __cuddcomplex__ &operator= ( const __cuddcomplex_raw__ &h ) { x = h.x; y = h.y; return *this; }
  __host__ __device__ __forceinline__
    operator __cuddcomplex_raw__() const { __cuddcomplex_raw__ h; h.x = x; h.y = y; return h; }

  __host__ __device__ __forceinline__
    __cuddcomplex__( const cuddreal &a, const cuddreal &b ) { x = a; y = b; }

  __host__ __device__ __forceinline__
    __cuddcomplex_raw__ * raw( void ) { return reinterpret_cast<__cuddcomplex_raw__*>(this); }

  __host__ __device__ __forceinline__
    operator cuddreal() const {
    return x;
  }

  __host__ __device__ __forceinline__
    operator cuDoubleComplex() const {
    const cuddreal_raw x_ = x;
    const cuddreal_raw y_ = y;
    const cuDoubleComplex t = { x_.x, y_.x };
    return t;
  }

  __host__ __device__ __forceinline__
    cuddreal real() const {
    return x;
  }
  __host__ __device__ __forceinline__
    cuddreal imag() const {
    return y;
  }
  __host__ __device__ __forceinline__
    cuddreal real(const cuddreal x) {
    this->x = x; return x;
  }
  __host__ __device__ __forceinline__
    cuddreal imag(const cuddreal y) {
    this->y = y; return y;
  }
};

typedef	struct __cuddcomplex__		cuddcomplex;
typedef	       __cuddcomplex_raw__	cuddcomplex_raw;


#if GPU_ARCH>300
__device__ __forceinline__ cuddcomplex
__ldg ( const cuddcomplex * a )
{
  cuddcomplex * aa = (cuddcomplex *)a;
  cuddcomplex_raw * p_ = (reinterpret_cast<cuddcomplex_raw *>(aa));
  cuddcomplex_raw t_;
  t_.x = __ldg( (cuddreal *)&(p_->x) );
  t_.y = __ldg( (cuddreal *)&(p_->y) );
  return t_;
}
#endif


__host__ __device__ __forceinline__ cuddreal
get_real( cuddcomplex &a )
{ return a.real(); }

__host__ __device__ __forceinline__ cuddreal
get_imag( cuddcomplex &a )
{ return a.imag(); }

__host__ __device__ __forceinline__ void
set_real( cuddcomplex &a, const cuddreal x )
{ a.real( x ); }

__host__ __device__ __forceinline__ void
set_imag( cuddcomplex &a, const cuddreal y )
{ a.imag( y ); }


__host__ __device__ __forceinline__ bool
operator== ( const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  const bool ret = ((a_.x == b_.x) && (a_.y == b_.y)) ? true : false;
  return ret;
}

__host__ __device__ __forceinline__ bool
operator!= ( const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  const bool ret = ((a_.x != b_.x) || (a_.y != b_.y)) ? true : false;
  return ret;
}


__host__ __device__ __forceinline__ cuddcomplex
operator+ ( const cuddcomplex a )
{
  return (a);
}

__host__ __device__ __forceinline__ cuddcomplex
operator+ ( const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  cuddcomplex_raw t_;
  add2 ( a_.x, b_.x, t_.x,  a_.y, b_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ void
operator+= ( cuddcomplex &a, const cuddcomplex b )
{
  a = (a + b);
}

__host__ __device__ __forceinline__ cuddcomplex
operator- ( const cuddcomplex a )
{
  const cuddcomplex_raw a_ = a;
  cuddcomplex_raw t_ = a_;
  t_.x = - t_.x;
  t_.y = - t_.y;
  return t_;
}

__host__ __device__ __forceinline__ cuddcomplex
operator- ( const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  cuddcomplex_raw t_;
  sub2 ( a_.x, b_.x, t_.x,  a_.y, b_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ void
operator-= ( cuddcomplex &a, const cuddcomplex b )
{
  a = (a - b);
}

__host__ __device__ __forceinline__ cuddcomplex
operator* ( const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  cuddcomplex_raw t_;
  cuddreal e = -a_.y;
  mul2 ( a_.x, b_.x, t_.x,  a_.x, b_.y, t_.y );
  fma2 ( e,    b_.y, t_.x, t_.x,  a_.y, b_.x, t_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cuddcomplex
operator* ( const cuddcomplex a, const cuddreal b )
{
  const cuddcomplex_raw a_ = a;
  cuddcomplex_raw t_;
  mul2 ( a_.x, b, t_.x,  a_.y, b, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cuddcomplex
operator* ( const cuddreal a, const cuddcomplex b )
{
  cuddcomplex t = (b * a);
  return t;
}

__host__ __device__ __forceinline__ void
operator*= ( cuddcomplex &a, const cuddcomplex b )
{
  a = (a * b);
}

__host__ __device__ __forceinline__ void
operator*= ( cuddcomplex &a, const cuddreal b )
{
  a = (a * b);
}

__host__ __device__ __forceinline__ cuddcomplex
fma ( const cuddcomplex a, const cuddcomplex b, const cuddcomplex c )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  const cuddcomplex_raw c_ = c;
  cuddcomplex_raw t_;
  cuddreal e = -a_.y;
  fma2 ( a_.x, b_.x, c_.x, t_.x,  a_.x, b_.y, c_.y, t_.y );
  fma2 ( e,    b_.y, t_.x, t_.x,  a_.y, b_.x, t_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cuddcomplex
fma ( const cuddcomplex a, const cuddreal b, const cuddcomplex c )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw c_ = c;
  cuddcomplex_raw t_;
  fma2 ( a_.x, b, c_.x, t_.x,  a_.y, b, c_.y, t_.y );
  return t_;
}

__host__ __device__ __forceinline__ cuddcomplex
fma ( const cuddreal a, const cuddcomplex b, const cuddcomplex c )
{
  cuddcomplex t = fma( b, a, c );
  return t;
}

__host__ __device__ __forceinline__ cuddcomplex
CUWDIV ( const cuddcomplex a, const cuddcomplex b )
{
  /*
   * almost similar approach to divide a complex number as cuComplex.h
   */
  const cuddreal     ZERO_   = __cuddreal__( (double)0, (double)0 );
  const cuddcomplex  ZERO    = __cuddcomplex__( ZERO_, ZERO_ );
  const cuddreal     NAN_DD  = __cuddreal__( NAN, NAN );
  const cuddcomplex  NAN_DDC = __cuddcomplex__( NAN_DD, NAN_DD );
  const cuddreal     ONE_    = __cuddreal__( (double)1, (double)0 );
  const cuddcomplex  ONE     = __cuddcomplex__( ONE_, ZERO_ );
  const cuddreal     MONE_   = __cuddreal__( (double)1, (double)0 );
  const cuddcomplex  MONE    = __cuddcomplex__( MONE_, ZERO_ );

  if ( b == ZERO ) { return NAN_DDC; }
  if ( a == ZERO ) { return ZERO; }
  if ( b == ONE  ) { return a; }
  if ( b == MONE ) { return -a; }

  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;

  cuddreal s = Abs(b_.x) + Abs(b_.y);
  cuddreal r = ONE_ / s;
  const cuddreal ar = a_.x * r;
  const cuddreal ai = a_.y * r;
  const cuddreal br = b_.x * r;
  const cuddreal bi = b_.y * r;
  s = (br * br) + (bi * bi);
  r = ONE_ / s;
  const cuddcomplex t = __cuddcomplex__(
                                        ((ar * br) + (ai * bi)) * r,
                                        ((ai * br) - (ar * bi)) * r );
  return t;
}

__host__ __device__ __forceinline__ cuddcomplex
operator/ ( const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex t = CUWDIV ( a, b );
  return t;
}

__host__ __device__ __forceinline__ void
operator/= ( cuddcomplex &a, const cuddcomplex b )
{
  a = ( a / b );
}


__host__ __device__ __forceinline__ void
add2 ( const cuddcomplex a1, const cuddcomplex b1, cuddcomplex &d1,
       const cuddcomplex a2, const cuddcomplex b2, cuddcomplex &d2 )
{
  const cuddcomplex_raw a1_ = a1;
  const cuddcomplex_raw a2_ = a2;
  const cuddcomplex_raw b1_ = b1;
  const cuddcomplex_raw b2_ = b2;
  cuddcomplex_raw t1_, t2_;
  add2 ( a1_.x, b1_.x, t1_.x,  a2_.x, b2_.x, t2_.x );
  add2 ( a1_.y, b1_.y, t1_.y,  a2_.y, b2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ void
sub2 ( const cuddcomplex a1, const cuddcomplex b1, cuddcomplex &d1,
       const cuddcomplex a2, const cuddcomplex b2, cuddcomplex &d2 )
{
  const cuddcomplex_raw a1_ = a1;
  const cuddcomplex_raw a2_ = a2;
  const cuddcomplex_raw b1_ = b1;
  const cuddcomplex_raw b2_ = b2;
  cuddcomplex_raw t1_, t2_;
  sub2 ( a1_.x, b1_.x, t1_.x,  a2_.x, b2_.x, t2_.x );
  sub2 ( a1_.y, b1_.y, t1_.y,  a2_.y, b2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ void
mul2 ( const cuddcomplex a1, const cuddcomplex b1, cuddcomplex &d1,
       const cuddcomplex a2, const cuddcomplex b2, cuddcomplex &d2 )
{
  const cuddcomplex_raw a1_ = a1;
  const cuddcomplex_raw a2_ = a2;
  const cuddcomplex_raw b1_ = b1;
  const cuddcomplex_raw b2_ = b2;
  cuddcomplex_raw t1_, t2_;
  cuddreal e1 = -a1_.y, e2 = -a2_.y;
  mul2 ( a1_.x, b1_.x, t1_.x,  a2_.x, b2_.x, t2_.x );
  mul2 ( a1_.x, b1_.y, t1_.y,  a2_.x, b2_.y, t2_.y );
  fma2 ( e1,    b1_.y, t1_.x, t1_.x,  e2,    b1_.y, t2_.x, t2_.x );
  fma2 ( a1_.y, b1_.x, t1_.y, t1_.y,  a2_.y, b1_.x, t2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ void
fma2 ( const cuddcomplex a1, const cuddcomplex b1, const cuddcomplex c1, cuddcomplex &d1,
       const cuddcomplex a2, const cuddcomplex b2, const cuddcomplex c2, cuddcomplex &d2 )
{
  const cuddcomplex_raw a1_ = a1;
  const cuddcomplex_raw a2_ = a2;
  const cuddcomplex_raw b1_ = b1;
  const cuddcomplex_raw b2_ = b2;
  const cuddcomplex_raw c1_ = c1;
  const cuddcomplex_raw c2_ = c2;
  cuddcomplex_raw t1_, t2_;
  cuddreal e1 = -a1_.y, e2 = -a2_.y;
  fma2( a1_.x, b1_.x, c1_.x, t1_.x,  a2_.x, b2_.x, c2_.x, t2_.x );
  fma2( a1_.x, b1_.y, c1_.y, t1_.y,  a2_.x, b2_.y, c2_.y, t2_.y );
  fma2( e1,    b1_.y, t1_.x, t1_.x,  e2,    b2_.y, t2_.x, t2_.x );
  fma2( a1_.y, b1_.x, t1_.y, t1_.y,  a2_.y, b2_.x, t2_.y, t2_.y );
  d1 = t1_; d2 = t2_;
}

__host__ __device__ __forceinline__ int
isnan ( const cuddcomplex a )
{
  const cuddcomplex_raw a_ = a;
  return (isnan(a_.x) || isnan(a_.y));
}

__host__ __device__ __forceinline__ int
isinf ( const cuddcomplex a )
{
  const cuddcomplex_raw a_ = a;
  return (isinf(a_.x) || isinf(a_.y));
}

__host__ __device__ __forceinline__ int
isfinite ( const cuddcomplex a )
{
  const cuddcomplex_raw a_ = a;
  return (isfinite(a_.x) && isfinite(a_.y));
}

__host__ __device__ __forceinline__ cuddreal
Abs ( const cuddcomplex a )
{
  const cuddcomplex_raw a_ = a;
  const cuddreal r2 = a_.x*a_.x + a_.y*a_.y;
  const cuddreal t = Sqrt( r2 );
  return t;
}

__host__ __device__ __forceinline__ void
makeConj ( cuddcomplex & a )
{
  set_imag(a, -get_imag(a));
}

__host__ __device__ __forceinline__ cuddcomplex
Conj ( const cuddcomplex a )
{
  cuddcomplex_raw t_ = a;
  t_.x =   t_.x;
  t_.y = - t_.y;
  return t_;
}

__host__ __device__ __forceinline__ cuddcomplex
__choose__ ( const bool flag, const cuddcomplex a, const cuddcomplex b )
{
  const cuddcomplex_raw a_ = a;
  const cuddcomplex_raw b_ = b;
  cuddcomplex_raw t_;
  t_.x = __choose__( flag, a_.x, b_.x );
  t_.y = __choose__( flag, a_.y, b_.y );
  return t_;
}

__forceinline__ __device__ cuddcomplex
__select__( const int cond, const cuddcomplex case_pos, const cuddcomplex case_neg )
{
  const cuddcomplex_raw case_pos_ = case_pos;
  const cuddcomplex_raw case_neg_ = case_neg;
  cuddcomplex_raw t_;
  t_.x = __select__( cond, case_pos_.x, case_neg_.x );
  t_.y = __select__( cond, case_pos_.y, case_neg_.y );
  return t_;
}

#endif
#undef	ASPEN_DDCOMPLEX_struct_body

#endif


#ifndef ASPEN_ATOMIC_H_INCLUDED
#define ASPEN_ATOMIC_H_INCLUDED		1

#include "aspen_types.h"

#if GPU_ARCH >= Fermi

//
// atomic Operations are supported on Fermi or later GPU generations
// 
#ifdef __CUDA_ARCH__
#if GPU_ARCH < Pascal
__forceinline__ __device__ double
atomicAdd ( double * address, const double val )
{
  unsigned long long * addr  = reinterpret_cast<unsigned long long *>(address);
  unsigned long long assumed = 0;
  unsigned long long old     = atomicCAS(addr, assumed, assumed );

  do {
    assumed = old;
    const unsigned long long update = 
      __double_as_longlong(val + __longlong_as_double(old));
    old = atomicCAS(addr, assumed, update );
  } while (assumed != old);

  return __longlong_as_double(old);
}
#endif
#endif

#if GPU_ARCH < Pascal
__forceinline__ __device__ double
atomicExch ( double * address, const double val )
{
#if GPU_ARCH < Kepler2
  unsigned long long * addr = reinterpret_cast<unsigned long long *>(address);
  unsigned long long old    = * addr, assumed;
  const unsigned long long update = __double_as_longlong(val);

  do {
    assumed = old;
    old = atomicCAS(addr, assumed, update );
  } while (assumed != old);

  return __longlong_as_double(old);
#else
  unsigned long long * addr = reinterpret_cast<unsigned long long *>(address);
  return __longlong_as_double(atomicExch(addr, __double_as_longlong(val)));
#endif
}
#endif

#if GPU_ARCH < Kepler2
__forceinline__ __device__ uint64_t
atomicOr__ ( uint64_t * address, const uint64_t val )
{
  unsigned long long * addr = reinterpret_cast<unsigned long long *>(address);
  unsigned long long old    = * addr, assumed, update;
  do {
    assumed = old;
    update = old | val;
    old = atomicCAS( addr, assumed, update );
  } while (assumed != old);
  return old;
}
#endif

__forceinline__ __device__ uint64_t
atomicOr ( uint64_t * address, const uint64_t val )
{
  uint64_t r;
  if ( sizeof(unsigned long long) == sizeof(uint64_t) ) {
    unsigned long long rr =
      atomicOr( (unsigned long long *)address, (unsigned long long)val );
    r = *(reinterpret_cast<uint64_t *>(&rr));
  } else
    if ( sizeof(unsigned long) == sizeof(uint64_t) ) {
      unsigned long rr =
        atomicOr( (unsigned long *)address, (unsigned long)val );
      r = *(reinterpret_cast<uint64_t *>(&rr));
    }
  return r;
}
#if __CUDA_ARCH__ >= 600
__forceinline__ __device__ uint64_t
atomicOr_system ( uint64_t * address, const uint64_t val )
{
  uint64_t r;
  if ( sizeof(unsigned long long) == sizeof(uint64_t) ) {
    unsigned long long rr =
      atomicOr_system( (unsigned long long *)address, (unsigned long long)val );
    r = *(reinterpret_cast<uint64_t *>(&rr));
  } else
    if ( sizeof(unsigned long) == sizeof(uint64_t) ) {
      unsigned long rr =
        atomicOr_system( (unsigned long *)address, (unsigned long)val );
      r = *(reinterpret_cast<uint64_t *>(&rr));
    }
  return r;
}
#endif

__forceinline__ __device__ double
atomicLoad ( double * address )
{
  unsigned long long * addr = reinterpret_cast<unsigned long long *>(address);
  const unsigned long long mask = 0;
#if GPU_ARCH < Kepler2
  return __longlong_as_double( atomicOr__( addr, mask ) );
#else
#if __CUDA_ARCH__ >= 600
  return __longlong_as_double( atomicOr_system( addr, mask ) );
#else
  return __longlong_as_double( atomicOr( addr, mask ) );
#endif
#endif
}

__forceinline__ __device__ float
atomicLoad ( float * address )
{
  uint32_t * addr = reinterpret_cast<uint32_t *>(address);
  const uint32_t mask = 0x0;
#if __CUDA_ARCH__ >= 600
  uint32_t t = atomicOr_system( addr, mask );
#else
  uint32_t t = atomicOr( addr, mask );
#endif
  float    s;
#if CUDA_VERSION<7050
  asm volatile ( "mov.f32\t%0, %1;" : "=f"(s) : "r"(t) );
#else
  s = __uint_as_float( t );
#endif
  return s;
}

__forceinline__ __device__ int32_t
atomicLoad ( int32_t * address )
{
  int32_t * addr = reinterpret_cast<int32_t *>(address);
  const int32_t mask = 0;
#if __CUDA_ARCH__ >= 600
  return atomicOr_system( addr, mask );
#else
  return atomicOr( addr, mask );
#endif
}

__forceinline__ __device__ uint32_t
atomicLoad ( uint32_t * address )
{
  uint32_t * addr = reinterpret_cast<uint32_t *>(address);
  const uint32_t mask = 0;
#if __CUDA_ARCH__ >= 600
  return atomicOr_system( addr, mask );
#else
  return atomicOr( addr, mask );
#endif
}

#endif



// atomic Load for non-builtin formats

__forceinline__ __device__ cuFloatComplex
atomicLoad ( cuFloatComplex * address )
{
  cuFloatComplex ret;
  ret.x = atomicLoad( & address->x );
  ret.y = atomicLoad( & address->y );
  return ret;
}

__forceinline__ __device__ cuDoubleComplex
atomicLoad ( cuDoubleComplex * address )
{
  cuDoubleComplex ret;
  ret.x = atomicLoad( & address->x );
  ret.y = atomicLoad( & address->y );
  return ret;
}

__forceinline__ __device__ cuddreal
atomicLoad ( cuddreal * address )
{
  cuddreal_raw ret;
  cuddreal_raw * address_ = reinterpret_cast<cuddreal_raw *>(address);
  ret.x = atomicLoad( & address_->x );
  ret.y = atomicLoad( & address_->y );
  return ret;
}

__forceinline__ __device__ cudfreal
atomicLoad ( cudfreal * address )
{
  cudfreal_raw ret;
  cudfreal_raw * address_ = reinterpret_cast<cudfreal_raw *>(address);
  ret.x = atomicLoad( & address_->x );
  ret.y = atomicLoad( & address_->y );
  return ret;
}

__forceinline__ __device__ cuddcomplex
atomicLoad ( cuddcomplex * address )
{
  cuddcomplex_raw ret;
  cuddcomplex_raw * address_ = reinterpret_cast<cuddcomplex_raw *>(address);
  ret.x = atomicLoad( & address_->x );
  ret.y = atomicLoad( & address_->y );
  return ret;
}

__forceinline__ __device__ cudfcomplex
atomicLoad ( cudfcomplex * address )
{
  cudfcomplex_raw ret;
  cudfcomplex_raw * address_ = reinterpret_cast<cudfcomplex_raw *>(address);
  ret.x = atomicLoad( & address_->x );
  ret.y = atomicLoad( & address_->y );
  return ret;
}

__forceinline__ __device__ uint64_t
atomicLoad ( uint64_t * address )
{
  unsigned long long * address_ = reinterpret_cast<unsigned long long *>(address);
  const unsigned long long mask = 0;
  unsigned long long ret = atomicOr( address_, mask );
  return *(reinterpret_cast<uint64_t *>(&ret));
}

__forceinline__ __device__ int64_t
atomicLoad ( int64_t * address )
{
  unsigned long long * address_ = reinterpret_cast<unsigned long long *>(address);
  const unsigned long long mask = 0;
  unsigned long long ret = atomicOr( address_, mask );
  return *(reinterpret_cast<int64_t *>(&ret));
}

__forceinline__ __device__ int128
atomicLoad ( int128 * address )
{
  int128_raw ret;
  int128_raw * address_ = reinterpret_cast<int128_raw *>(address);
  ret.x = atomicLoad( & address_->x );
  ret.y = atomicLoad( & address_->y );
  return ret;
}

// atomic Exch for non-builtin formats
#if GPU_ARCH >= Pascal
__forceinline__ __device__ double
atomicExch ( double * address, const double val )
{
  unsigned long long * addr = reinterpret_cast<unsigned long long *>(address);
  unsigned long long   val_ = __double_as_longlong(val);
#if GPU_ARCH < Kepler2
  return __longlong_as_double( atomicExch( addr, val_ ) );
#else
#if __CUDA_ARCH__ >= 600
  return __longlong_as_double( atomicExch_system( addr, val_ ) );
#else
  return __longlong_as_double( atomicExch( addr, val_ ) );
#endif
#endif
}
#endif

__forceinline__ __device__ cuFloatComplex
atomicExch ( cuFloatComplex * address, const cuFloatComplex val )
{
  cuFloatComplex ret;
  ret.x = atomicExch( & address->x, val.x );
  ret.y = atomicExch( & address->y, val.y );
  return ret;
}

__forceinline__ __device__ cuDoubleComplex
atomicExch ( cuDoubleComplex * address, const cuDoubleComplex val )
{
  cuDoubleComplex ret;
  ret.x = atomicExch( & address->x, val.x );
  ret.y = atomicExch( & address->y, val.y );
  return ret;
}

__forceinline__ __device__ cuddreal
atomicExch ( cuddreal * address, const cuddreal val )
{
  cuddreal_raw * address_ = reinterpret_cast<cuddreal_raw *>(address);
  const cuddreal_raw val_ = val;

  cuddreal_raw ret;
  ret.x = atomicExch( & address_->x, val_.x );
  ret.y = atomicExch( & address_->y, val_.y );
  return ret;
}

__forceinline__ __device__ cudfreal
atomicExch ( cudfreal * address, const cudfreal val )
{
  cudfreal_raw * address_ = reinterpret_cast<cudfreal_raw *>(address);
  const cudfreal_raw val_ = val;

  cudfreal_raw ret;
  ret.x = atomicExch( & address_->x, val_.x );
  ret.y = atomicExch( & address_->y, val_.y );
  return ret;
}

__forceinline__ __device__ cuddcomplex
atomicExch ( cuddcomplex * address, const cuddcomplex val )
{
  cuddcomplex_raw * address_ = reinterpret_cast<cuddcomplex_raw *>(address);
  const cuddcomplex_raw val_ = val;

  cuddcomplex_raw ret;
  ret.x = atomicExch( & address_->x, val_.x );
  ret.y = atomicExch( & address_->y, val_.y );
  return ret;
}

__forceinline__ __device__ cudfcomplex
atomicExch ( cudfcomplex * address, const cudfcomplex val )
{
  cudfcomplex_raw * address_ = reinterpret_cast<cudfcomplex_raw *>(address);
  const cudfcomplex_raw val_ = val;

  cudfcomplex_raw ret;
  ret.x = atomicExch( & address_->x, val_.x );
  ret.y = atomicExch( & address_->y, val_.y );
  return ret;
}

__forceinline__ __device__ uint64_t
atomicExch ( uint64_t * address, uint64_t val )
{
  unsigned long long * address_ = reinterpret_cast<unsigned long long *>(address);
  const unsigned long long val_ = *(reinterpret_cast<unsigned long long *>(&val));
  unsigned long long ret = atomicExch( address_, val_ );
  return *(reinterpret_cast<unsigned long long *>(&ret));
}

__forceinline__ __device__ int64_t
atomicExch ( int64_t * address, int64_t val )
{
  unsigned long long * address_ = reinterpret_cast<unsigned long long *>(address);
  const signed long long val_ = *(reinterpret_cast<signed long long *>(&val));
  unsigned long long ret = atomicExch( address_, val_ );
  return *(reinterpret_cast<signed long long *>(&ret));
}

__forceinline__ __device__ int128
atomicExch ( int128 * address, int128 val )
{
  int128_raw * address_ = reinterpret_cast<int128_raw *>(address);
  int128_raw val_ = *(reinterpret_cast<int128_raw *>(&val));

  int128_raw ret;
  ret.x = atomicExch( & address_->x, val_.x );
  ret.y = atomicExch( & address_->y, val_.y );
  return ret;
}

// atomic Add for non-builtin formats

__forceinline__ __device__ cuFloatComplex
atomicAdd ( cuFloatComplex * address, const cuFloatComplex val )
{
  cuFloatComplex ret;
  ret.x = atomicAdd( & address->x, val.x );
  ret.y = atomicAdd( & address->y, val.y );
  return ret;
}

__forceinline__ __device__ cuDoubleComplex
atomicAdd ( cuDoubleComplex * address, const cuDoubleComplex val )
{
  cuDoubleComplex ret;
  ret.x = atomicAdd( & address->x, val.x );
  ret.y = atomicAdd( & address->y, val.y );
  return ret;
}

__forceinline__ __device__ cuddreal
atomicAdd ( cuddreal * address, const cuddreal val )
{
  cuddreal ret = atomicLoad( address ) + val;
  ret = atomicExch( address, ret );
  return ret;
}

__forceinline__ __device__ cudfreal
atomicAdd ( cudfreal * address, const cudfreal val )
{
  cudfreal ret = atomicLoad( address ) + val;
  ret = atomicExch( address, ret );
  return ret;
}

__forceinline__ __device__ cuddcomplex
atomicAdd ( cuddcomplex * address, const cuddcomplex val )
{
  cuddcomplex ret = atomicLoad( address ) + val;
  ret = atomicExch( address, ret );
  return ret;
}

__forceinline__ __device__ cudfcomplex
atomicAdd ( cudfcomplex * address, const cudfcomplex val )
{
  cudfcomplex ret = atomicLoad( address ) + val;
  ret = atomicExch( address, ret );
  return ret;
}

__forceinline__ __device__ int64_t
atomicAdd ( int64_t * address, int64_t val )
{
  unsigned long long * address_ = reinterpret_cast<unsigned long long *>(address);
  const signed long long val_ = *(reinterpret_cast<signed long long *>(&val));
  unsigned long long ret = atomicAdd( address_, val_ );
  return *(reinterpret_cast<signed long long *>(&ret));
}

__forceinline__ __device__ int128
atomicAdd ( int128 * address, const int128 val )
{
  int128 ret = atomicLoad( address ) + val;
  ret = atomicExch( address, ret );
  return ret;
}


__forceinline__ __device__ void
pokeAdd ( int32_t * address, int32_t val )
{
  asm volatile ( "red.global.add.s32\t[%0], %1;"
                : : "l"(address), "r"(val) );
}

__forceinline__ __device__ void
pokeOr ( int32_t * address, int32_t val )
{
  asm volatile ( "red.global.or.b32\t[%0], %1;"
                : : "l"(address), "r"(val) );
}

__forceinline__ __device__ void
pokeAnd ( int32_t * address, int32_t val )
{
  asm volatile ( "red.global.and.b32\t[%0], %1;"
                : : "l"(address), "r"(val) );
}
__forceinline__ __device__ void
pokeAdd ( uint32_t * address, uint32_t val )
{
  asm volatile ( "red.global.add.u32\t[%0], %1;"
                : : "l"(address), "r"(val) );
}

__forceinline__ __device__ void
pokeOr ( uint32_t * address, uint32_t val )
{
  asm volatile ( "red.global.or.b32\t[%0], %1;"
                : : "l"(address), "r"(val) );
}

__forceinline__ __device__ void
pokeAnd ( uint32_t * address, uint32_t val )
{
  asm volatile ( "red.global.and.b32\t[%0], %1;"
                : : "l"(address), "r"(val) );
}

#endif


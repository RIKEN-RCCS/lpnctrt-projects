#ifndef ASPEN_FORTRAN_H_INCLUDED
#define ASPEN_FORTRAN_H_INCLUDED	1

#include "aspen_version.h"
#include "aspen_types.h"

typedef size_t devptr_t;

#ifdef __cplusplus
extern  "C" {
#endif

  /* User must call ASPEN_init for initialization */
  void
  aspen_init_ ( const int * device_id );

  /* User must finalize the ASPEN library by ASPEN_shutdown */
  void
  aspen_shutdown_ ( void );

  /* Get version info ASPEN_get_version_info */
  void
  aspen_get_version_info_ ( int *version,
                            char *codename, unsigned int length_codename,
                            char *releasedate, unsigned int length_releasedate );

  void
  aspen_wsymv_ (
                const char              * uplo,
                const int               * n,
                const cuddreal          * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const cuddreal          * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_dsymv_ (
                const char              * uplo,
                const int               * n,
                const double            * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const double            * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_ssymv_ (
                const char              * uplo,
                const int               * n,
                const float             * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const float             * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_hsymv_ (
                const char              * uplo,
                const int               * n,
                const half              * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const half              * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_uhemv_ (
                const char              * uplo,
                const int               * n,
                const cuddcomplex       * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const cuddcomplex       * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_zhemv_ (
                const char              * uplo,
                const int               * n,
                const cuDoubleComplex   * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const cuDoubleComplex   * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_chemv_ (
                const char              * uplo,
                const int               * n,
                const cuFloatComplex    * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const cuFloatComplex    * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_khemv_ (
                const char              * uplo,
                const int               * n,
                const cuHalfComplex     * alpha,
                const devptr_t          * devPtrA,
                const int               * lda,
                const devptr_t          * devPtrx,
                const int               * incx,
                const cuHalfComplex     * beta,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_i128symv_ (
                   const char              * uplo,
                   const int               * n,
                   const int128            * alpha,
                   const devptr_t          * devPtrA,
                   const int               * lda,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const int128            * beta,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );
  void
  aspen_i64symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int64             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i32symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int32             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i16symv_ (
                  const char              * uplo,
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrA,
                  const int               * lda,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const int16             * beta,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );

  void
  aspen_waxpy_ (
                const int               * n,
                const cuddreal          * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_daxpy_ (
                const int               * n,
                const double            * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_saxpy_ (
                const int               * n,
                const float             * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_haxpy_ (
                const int               * n,
                const half              * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_uaxpy_ (
                const int               * n,
                const cuddcomplex       * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_zaxpy_ (
                const int               * n,
                const cuDoubleComplex   * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_caxpy_ (
                const int               * n,
                const cuFloatComplex    * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_kaxpy_ (
                const int               * n,
                const cuHalfComplex     * alpha,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_i128axpy_ (
                   const int               * n,
                   const int128            * alpha,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );
  void
  aspen_i64axpy_ (
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i32axpy_ (
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i16axpy_ (
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );

  void
  aspen_waxpby_ (
                 const int               * n,
                 const cuddreal          * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const cuddreal          * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_daxpby_ (
                 const int               * n,
                 const double            * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const double            * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_saxpby_ (
                 const int               * n,
                 const float             * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const float             * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_haxpby_ (
                 const int               * n,
                 const half              * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const half              * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_uaxpby_ (
                 const int               * n,
                 const cuddcomplex       * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const cuddcomplex       * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_zaxpby_ (
                 const int               * n,
                 const cuDoubleComplex   * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const cuDoubleComplex   * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_caxpby_ (
                 const int               * n,
                 const cuFloatComplex    * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const cuFloatComplex    * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_kaxpby_ (
                 const int               * n,
                 const cuHalfComplex     * alpha,
                 const devptr_t          * devPtrx,
                 const int               * incx,
                 const cuHalfComplex     * beta,
                 const devptr_t          * devPtry,
                 const int               * incy
                 );
  void
  aspen_i128axpby_ (
                    const int               * n,
                    const int128            * alpha,
                    const devptr_t          * devPtrx,
                    const int               * incx,
                    const int128            * beta,
                    const devptr_t          * devPtry,
                    const int               * incy
                    );
  void
  aspen_i64axpby_ (
                   const int               * n,
                   const int64             * alpha,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const int64             * beta,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );
  void
  aspen_i32axpby_ (
                   const int               * n,
                   const int32             * alpha,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const int32             * beta,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );
  void
  aspen_i16axpby_ (
                   const int               * n,
                   const int16             * alpha,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const int16             * beta,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );

  void
  aspen_wswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_dswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_sswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_hswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_uswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_zswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_cswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_kswap_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_i128swap_ (
                   const int               * n,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );
  void
  aspen_i64swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i32swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i16swap_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );

  void
  aspen_wcopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_dcopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_scopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_hcopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_ucopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_zcopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_ccopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_kcopy_ (
                const int               * n,
                const devptr_t          * devPtrx,
                const int               * incx,
                const devptr_t          * devPtry,
                const int               * incy
                );
  void
  aspen_i128copy_ (
                   const int               * n,
                   const devptr_t          * devPtrx,
                   const int               * incx,
                   const devptr_t          * devPtry,
                   const int               * incy
                   );
  void
  aspen_i64copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i32copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );
  void
  aspen_i16copy_ (
                  const int               * n,
                  const devptr_t          * devPtrx,
                  const int               * incx,
                  const devptr_t          * devPtry,
                  const int               * incy
                  );

  void
  aspen_wscal_ (
                const int               * n,
                const cuddreal          * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_dscal_ (
                const int               * n,
                const double            * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_sscal_ (
                const int               * n,
                const float             * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_hscal_ (
                const int               * n,
                const half              * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_uscal_ (
                const int               * n,
                const cuddcomplex       * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_zscal_ (
                const int               * n,
                const cuDoubleComplex   * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_cscal_ (
                const int               * n,
                const cuFloatComplex    * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_kscal_ (
                const int               * n,
                const cuHalfComplex     * alpha,
                const devptr_t          * devPtrx,
                const int               * incx
                );
  void
  aspen_i128scal_ (
                   const int               * n,
                   const int128            * alpha,
                   const devptr_t          * devPtrx,
                   const int               * incx
                   );
  void
  aspen_i64scal_ (
                  const int               * n,
                  const int64             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                  );
  void
  aspen_i32scal_ (
                  const int               * n,
                  const int32             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                  );
  void
  aspen_i16scal_ (
                  const int               * n,
                  const int16             * alpha,
                  const devptr_t          * devPtrx,
                  const int               * incx
                  );

  void
  aspen_wzero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_dzero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_szero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_hzero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_uzero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_zzero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_czero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_kzero_ (
                const devptr_t          * devPtrx,
                const int               * n 
                );
  void
  aspen_i128zero_ (
                   const devptr_t          * devPtrx,
                   const int               * n 
                   );
  void
  aspen_i64zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                  );
  void
  aspen_i32zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                  );
  void
  aspen_i16zero_ (
                  const devptr_t          * devPtrx,
                  const int               * n 
                  );

#ifdef __cplusplus
}
#endif

#endif 

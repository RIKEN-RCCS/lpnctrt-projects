#ifndef ASPEN_LDST_H_INCLUDED
#define ASPEN_LDST_H_INCLUDED           1

#include "aspen_types.h"
#include "aspen_shmem.h"
#include "aspen_const.h"

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Volatile ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Volatile ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Volatile ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.volatile.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Volatile ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.volatile.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Volatile ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.volatile.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.volatile.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Volatile ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Volatile ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.volatile.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Volatile ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.volatile.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Volatile ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.volatile.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Volatile ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.volatile.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Volatile ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.volatile.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Volatile ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.volatile.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Volatile ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.volatile.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_CG ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_CG ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_CG ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.cg.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_CG ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.cg.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_CG ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_CG ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_CG ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.cg.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_CG ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.cg.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_CG ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.cg.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_CG ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.cg.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_CG ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.cg.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_CG ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.cg.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_CG ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.cg.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_CV ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_CV ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_CV ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.cv.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_CV ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.cv.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_CV ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_CV ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_CV ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.cv.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_CV ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.cv.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_CV ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.cv.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_CV ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.cv.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_CV ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.cv.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_CV ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.cv.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_CV ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.cv.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_LU ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_LU ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_LU ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.lu.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_LU ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.lu.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_LU ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_LU ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_LU ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.lu.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_LU ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.lu.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_LU ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.lu.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_LU ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.lu.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_LU ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.lu.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_LU ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.lu.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_LU ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.lu.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_CS ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_CS ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_CS ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.cs.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_CS ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.cs.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_CS ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_CS ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_CS ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.cs.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_CS ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.cs.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_CS ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.cs.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_CS ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.cs.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_CS ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.cs.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_CS ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.cs.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_CS ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.cs.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Global ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Global ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.global.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Global ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.global.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Global ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Global ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Global ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.global.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Global ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.global.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Global ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.global.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Global ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.global.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Global ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.global.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Global ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.global.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Global ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.global.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Volatile_Global ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Volatile_Global ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Volatile_Global ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.volatile.global.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Volatile_Global ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.volatile.global.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Volatile_Global ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.volatile.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.volatile.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Volatile_Global ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Volatile_Global ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.volatile.global.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Volatile_Global ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.volatile.global.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Volatile_Global ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.volatile.global.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Volatile_Global ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.volatile.global.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Volatile_Global ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.volatile.global.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Volatile_Global ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.volatile.global.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Volatile_Global ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.volatile.global.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global_CG ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Global_CG ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Global_CG ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.global.cg.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Global_CG ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.global.cg.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Global_CG ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.global.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.global.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Global_CG ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.cg.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Global_CG ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.global.cg.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Global_CG ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.global.cg.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Global_CG ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.global.cg.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Global_CG ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.global.cg.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Global_CG ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.global.cg.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Global_CG ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.global.cg.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Global_CG ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.global.cg.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global_CV ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Global_CV ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Global_CV ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.global.cv.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Global_CV ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.global.cv.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Global_CV ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.global.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.global.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Global_CV ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.cv.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Global_CV ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.global.cv.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Global_CV ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.global.cv.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Global_CV ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.global.cv.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Global_CV ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.global.cv.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Global_CV ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.global.cv.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Global_CV ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.global.cv.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Global_CV ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.global.cv.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global_LU ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Global_LU ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Global_LU ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.global.lu.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Global_LU ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.global.lu.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Global_LU ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.global.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.global.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Global_LU ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.lu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Global_LU ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.global.lu.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Global_LU ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.global.lu.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Global_LU ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.global.lu.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Global_LU ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.global.lu.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Global_LU ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.global.lu.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Global_LU ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.global.lu.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Global_LU ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.global.lu.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global_CS ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Global_CS ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Global_CS ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.global.cs.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Global_CS ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.global.cs.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Global_CS ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.global.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.global.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Global_CS ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.cs.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Global_CS ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.global.cs.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Global_CS ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.global.cs.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Global_CS ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.global.cs.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Global_CS ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.global.cs.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Global_CS ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.global.cs.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Global_CS ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.global.cs.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Global_CS ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.global.cs.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global_NC ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Global_NC ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.nc.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Global_NC ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.global.nc.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Global_NC ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.global.nc.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Global_NC ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.global.nc.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.global.nc.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Global_NC ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.global.nc.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Global_NC ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.global.nc.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Global_NC ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.global.nc.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Global_NC ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.global.nc.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Global_NC ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.global.nc.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Global_NC ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.global.nc.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Global_NC ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.global.nc.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Global_NC ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.global.nc.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Relaxed ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddreal
Load_Relaxed ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.relaxed.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ double
Load_Relaxed ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.relaxed.gpu.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ float
Load_Relaxed ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.relaxed.gpu.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddcomplex
Load_Relaxed ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.relaxed.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.relaxed.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuDoubleComplex
Load_Relaxed ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.relaxed.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuFloatComplex
Load_Relaxed ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.relaxed.gpu.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuHalfComplex
Load_Relaxed ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.relaxed.gpu.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ half
Load_Relaxed ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.relaxed.gpu.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int128
Load_Relaxed ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.relaxed.gpu.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int64
Load_Relaxed ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.relaxed.gpu.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int32
Load_Relaxed ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.relaxed.gpu.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int16
Load_Relaxed ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.relaxed.gpu.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Acquire ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddreal
Load_Acquire ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.acquire.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ double
Load_Acquire ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.acquire.gpu.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ float
Load_Acquire ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.acquire.gpu.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddcomplex
Load_Acquire ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.acquire.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.acquire.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuDoubleComplex
Load_Acquire ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.acquire.gpu.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuFloatComplex
Load_Acquire ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.acquire.gpu.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuHalfComplex
Load_Acquire ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.acquire.gpu.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ half
Load_Acquire ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.acquire.gpu.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int128
Load_Acquire ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.acquire.gpu.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int64
Load_Acquire ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.acquire.gpu.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int32
Load_Acquire ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.acquire.gpu.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int16
Load_Acquire ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.acquire.gpu.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Relaxed_Global ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddreal
Load_Relaxed_Global ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.relaxed.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ double
Load_Relaxed_Global ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.relaxed.gpu.global.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ float
Load_Relaxed_Global ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.relaxed.gpu.global.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddcomplex
Load_Relaxed_Global ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.relaxed.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.relaxed.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuDoubleComplex
Load_Relaxed_Global ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.relaxed.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuFloatComplex
Load_Relaxed_Global ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.relaxed.gpu.global.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuHalfComplex
Load_Relaxed_Global ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.relaxed.gpu.global.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ half
Load_Relaxed_Global ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.relaxed.gpu.global.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int128
Load_Relaxed_Global ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.relaxed.gpu.global.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int64
Load_Relaxed_Global ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.relaxed.gpu.global.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int32
Load_Relaxed_Global ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.relaxed.gpu.global.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int16
Load_Relaxed_Global ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.relaxed.gpu.global.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Acquire_Global ( const TYPE * addr__ )
{ return makeCONST <TYPE> (0); }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddreal
Load_Acquire_Global ( const cuddreal * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.acquire.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ double
Load_Acquire_Global ( const double * const addr__ )
{

  double u;
  asm volatile ( "ld.acquire.gpu.global.f64 %0, [%1];"
                 : "=d"(u) : "l"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ float
Load_Acquire_Global ( const float * const addr__ )
{

  float u;
  asm volatile ( "ld.acquire.gpu.global.f32 %0, [%1];"
                 : "=f"(u) : "l"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuddcomplex
Load_Acquire_Global ( const cuddcomplex * const addr__ )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double sx; double sy; } v_type;
  cuddcomplex * addr_ = (cuddcomplex *)addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  v_type u, v;
  u_type w;
  asm volatile ( "ld.acquire.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(&addr___->x) );
  w.x = *(reinterpret_cast<cuddreal *>(&u));
  asm volatile ( "ld.acquire.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "l"(&addr___->y) );
  w.y = *(reinterpret_cast<cuddreal *>(&v));
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuDoubleComplex
Load_Acquire_Global ( const cuDoubleComplex * const addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.acquire.gpu.global.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "l"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuFloatComplex
Load_Acquire_Global ( const cuFloatComplex * const addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.acquire.gpu.global.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "l"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ cuHalfComplex
Load_Acquire_Global ( const cuHalfComplex * const addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.acquire.gpu.global.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "l"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ half
Load_Acquire_Global ( const half * const addr__ )
{

  ushort u;
  asm volatile ( "ld.acquire.gpu.global.b16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int128
Load_Acquire_Global ( const int128 * const addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.acquire.gpu.global.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "l"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int64
Load_Acquire_Global ( const int64 * const addr__ )
{

  int64_t u;
  asm volatile ( "ld.acquire.gpu.global.u64 %0, [%1];"
                 : "=l"(u) : "l"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int32
Load_Acquire_Global ( const int32 * const addr__ )
{

  int32_t u;
  asm volatile ( "ld.acquire.gpu.global.u32 %0, [%1];"
                 : "=r"(u) : "l"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ int16
Load_Acquire_Global ( const int16 * const addr__ )
{

  int16_t u;
  asm volatile ( "ld.acquire.gpu.global.u16 %0, [%1];"
                 : "=h"(u) : "l"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store ( TYPE * const addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}

template < >
__forceinline__ __device__ void
Store ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_Volatile ( TYPE * const addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_Volatile ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.volatile.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.volatile.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.volatile.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.volatile.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}

template < >
__forceinline__ __device__ void
Store_Volatile ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.volatile.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.volatile.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.volatile.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.volatile.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_CG ( TYPE * const addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_CG ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_CG ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.cg.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_CG ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.cg.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_CG ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}

template < >
__forceinline__ __device__ void
Store_CG ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_CG ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.cg.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_CG ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.cg.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_CG ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.cg.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_CG ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.cg.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_CG ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.cg.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_CG ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.cg.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_CG ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.cg.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_Global ( TYPE * const addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_Global ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.global.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.global.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}

template < >
__forceinline__ __device__ void
Store_Global ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.global.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.global.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.global.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.global.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_Volatile_Global ( TYPE * const addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.volatile.global.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.volatile.global.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.volatile.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.volatile.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.global.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.global.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.volatile.global.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.global.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.volatile.global.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.volatile.global.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Global ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.volatile.global.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_Global_CG ( TYPE * const addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_Global_CG ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global_CG ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.global.cg.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global_CG ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.global.cg.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global_CG ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.global.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.global.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}

template < >
__forceinline__ __device__ void
Store_Global_CG ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.cg.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global_CG ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.cg.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global_CG ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.cg.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global_CG ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.global.cg.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global_CG ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.global.cg.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Global_CG ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.global.cg.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global_CG ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.global.cg.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Global_CG ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.global.cg.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ void
Store_Release ( TYPE * const addr__, const TYPE s )
{ ; }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.release.gpu.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.release.gpu.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.release.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.release.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.release.gpu.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.release.gpu.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.release.gpu.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.release.gpu.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ void
Store_Relaxed ( TYPE * const addr__, const TYPE s )
{ ; }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.relaxed.gpu.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.relaxed.gpu.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.relaxed.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.relaxed.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.relaxed.gpu.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.relaxed.gpu.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.relaxed.gpu.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.relaxed.gpu.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ void
Store_Release_Global ( TYPE * const addr__, const TYPE s )
{ ; }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.release.gpu.global.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.release.gpu.global.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.release.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.release.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.global.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.global.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.release.gpu.global.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.release.gpu.global.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.release.gpu.global.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.release.gpu.global.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Release_Global ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.release.gpu.global.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
#if CURRENT_GPU>=700
template < class TYPE >
__forceinline__ __device__ void
Store_Relaxed_Global ( TYPE * const addr__, const TYPE s )
{ ; }
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( cuddreal * const addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( double * const addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.f64 [%1], %0;"
                 : : "d"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( float * const addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.f32 [%1], %0;"
                 : : "f"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( cuddcomplex * const addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex * addr_ = addr__;
  const u_type * addr___ = (reinterpret_cast<u_type *>(addr_));
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.relaxed.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "l"(&addr___->x) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  asm volatile ( "st.relaxed.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "l"(&addr___->y) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( cuDoubleComplex * const addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( cuFloatComplex * const addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( cuHalfComplex * const addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( half * const addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.b16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( int128 * const addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "l"(addr__) );

}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( int64 * const addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.u64 [%1], %0;"
                 : : "l"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( int32 * const addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.u32 [%1], %0;"
                 : : "r"(t), "l"(addr__) );
}
#endif

#if CURRENT_GPU>=700
template < >
__forceinline__ __device__ void
Store_Relaxed_Global ( int16 * const addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.relaxed.gpu.global.u16 [%1], %0;"
                 : : "h"(t), "l"(addr__) );
}
#endif

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Shared ( const SHMEM_addr_t addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Shared ( const SHMEM_addr_t addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "r"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Shared ( const SHMEM_addr_t addr__ )
{

  double u;
  asm volatile ( "ld.shared.f64 %0, [%1];"
                 : "=d"(u) : "r"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Shared ( const SHMEM_addr_t addr__ )
{

  float u;
  asm volatile ( "ld.shared.f32 %0, [%1];"
                 : "=f"(u) : "r"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Shared ( const SHMEM_addr_t addr__ )
{
  struct { double sx; double sy; } u;
  asm volatile ( "ld.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "r"(addr__) );
  const cuddreal tx = *(reinterpret_cast<cuddreal *>(&u));
  struct { double sx; double sy; } v;
  const SHMEM_addr_t bddr__ = addr__ + sizeof(cuddreal);
  asm volatile ( "ld.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "r"(bddr__) );
  const cuddreal ty = *(reinterpret_cast<cuddreal *>(&v));
  struct { cuddreal tx; cuddreal ty; } w = { tx, ty };
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Shared ( const SHMEM_addr_t addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "r"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Shared ( const SHMEM_addr_t addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.shared.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "r"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Shared ( const SHMEM_addr_t addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.shared.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "r"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Shared ( const SHMEM_addr_t addr__ )
{

  ushort u;
  asm volatile ( "ld.shared.b16 %0, [%1];"
                 : "=h"(u) : "r"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Shared ( const SHMEM_addr_t addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.shared.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "r"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Shared ( const SHMEM_addr_t addr__ )
{

  int64_t u;
  asm volatile ( "ld.shared.u64 %0, [%1];"
                 : "=l"(u) : "r"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Shared ( const SHMEM_addr_t addr__ )
{

  int32_t u;
  asm volatile ( "ld.shared.u32 %0, [%1];"
                 : "=r"(u) : "r"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Shared ( const SHMEM_addr_t addr__ )
{

  int16_t u;
  asm volatile ( "ld.shared.u16 %0, [%1];"
                 : "=h"(u) : "r"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.shared.f64 [%1], %0;"
                 : : "d"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.shared.f32 [%1], %0;"
                 : : "f"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "r"(addr__) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  const SHMEM_addr_t bddr__ = addr__ + sizeof(cuddreal);
  asm volatile ( "st.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "r"(bddr__) );

}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.shared.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.shared.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.shared.b16 [%1], %0;"
                 : : "h"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.shared.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.shared.u64 [%1], %0;"
                 : : "l"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.shared.u32 [%1], %0;"
                 : : "r"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Shared ( const SHMEM_addr_t addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.shared.u16 [%1], %0;"
                 : : "h"(t), "r"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{ return makeCONST <TYPE> (0); }

template < >
__forceinline__ __device__ cuddreal
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "r"(addr__) );
  const cuddreal t = *(reinterpret_cast<cuddreal *>(&u));
  return t;

}

template < >
__forceinline__ __device__ double
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  double u;
  asm volatile ( "ld.volatile.shared.f64 %0, [%1];"
                 : "=d"(u) : "r"(addr__) );
  const double t = *(reinterpret_cast<double *>(&u));
  return t;
}

template < >
__forceinline__ __device__ float
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  float u;
  asm volatile ( "ld.volatile.shared.f32 %0, [%1];"
                 : "=f"(u) : "r"(addr__) );
  const float t = *(reinterpret_cast<float *>(&u));
  return t;
}

template < >
__forceinline__ __device__ cuddcomplex
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{
  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "r"(addr__) );
  const cuddreal tx = *(reinterpret_cast<cuddreal *>(&u));
  struct { double sx; double sy; } v;
  const SHMEM_addr_t bddr__ = addr__ + sizeof(cuddreal);
  asm volatile ( "ld.volatile.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(v.sx), "=d"(v.sy) : "r"(bddr__) );
  const cuddreal ty = *(reinterpret_cast<cuddreal *>(&v));
  struct { cuddreal tx; cuddreal ty; } w = { tx, ty };
  const cuddcomplex t = *(reinterpret_cast<cuddcomplex *>(&w));
  return t;

}

template < >
__forceinline__ __device__ cuDoubleComplex
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  struct { double sx; double sy; } u;
  asm volatile ( "ld.volatile.shared.v2.f64 {%0,%1}, [%2];"
                 : "=d"(u.sx), "=d"(u.sy) : "r"(addr__) );
  const cuDoubleComplex t = *(reinterpret_cast<cuDoubleComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuFloatComplex
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  struct { float sx; float sy; } u;
  asm volatile ( "ld.volatile.shared.v2.f32 {%0,%1}, [%2];"
                 : "=f"(u.sx), "=f"(u.sy) : "r"(addr__) );
  const cuFloatComplex t = *(reinterpret_cast<cuFloatComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ cuHalfComplex
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  struct { ushort sx; ushort sy; } u;
  asm volatile ( "ld.volatile.shared.v2.b16 {%0,%1}, [%2];"
                 : "=h"(u.sx), "=h"(u.sy) : "r"(addr__) );
  const cuHalfComplex t = *(reinterpret_cast<cuHalfComplex *>(&u));
  return t;

}

template < >
__forceinline__ __device__ half
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  ushort u;
  asm volatile ( "ld.volatile.shared.b16 %0, [%1];"
                 : "=h"(u) : "r"(addr__) );
  const half t = *(reinterpret_cast<half *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int128
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  struct { uint64_t sx; uint64_t sy; } u;
  asm volatile ( "ld.volatile.shared.v2.u64 {%0,%1}, [%2];"
                 : "=l"(u.sx), "=l"(u.sy) : "r"(addr__) );
  const int128 t = *(reinterpret_cast<int128 *>(&u));
  return t;

}

template < >
__forceinline__ __device__ int64
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  int64_t u;
  asm volatile ( "ld.volatile.shared.u64 %0, [%1];"
                 : "=l"(u) : "r"(addr__) );
  const int64 t = *(reinterpret_cast<int64 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int32
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  int32_t u;
  asm volatile ( "ld.volatile.shared.u32 %0, [%1];"
                 : "=r"(u) : "r"(addr__) );
  const int32 t = *(reinterpret_cast<int32 *>(&u));
  return t;
}

template < >
__forceinline__ __device__ int16
Load_Volatile_Shared ( const SHMEM_addr_t addr__ )
{

  int16_t u;
  asm volatile ( "ld.volatile.shared.u16 %0, [%1];"
                 : "=h"(u) : "r"(addr__) );
  const int16 t = *(reinterpret_cast<int16 *>(&u));
  return t;
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const TYPE s )
{ ; }

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const cuddreal s )
{

  typedef struct { double sx; double sy; } u_type;
  cuddreal ss = static_cast<cuddreal>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const double s )
{

  double ss = static_cast<double>(s);
  double t = *(reinterpret_cast<double *>(&ss));
  asm volatile ( "st.volatile.shared.f64 [%1], %0;"
                 : : "d"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const float s )
{

  float ss = static_cast<float>(s);
  float t = *(reinterpret_cast<float *>(&ss));
  asm volatile ( "st.volatile.shared.f32 [%1], %0;"
                 : : "f"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const cuddcomplex s )
{
  typedef struct { cuddreal x; cuddreal y; } u_type;
  typedef struct { double x; double y; } v_type;
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  v_type v1 = *(reinterpret_cast<v_type *>(&u.x));
  asm volatile ( "st.volatile.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(v1.x), "d"(v1.y), "r"(addr__) );
  v_type v2 = *(reinterpret_cast<v_type *>(&u.y));
  const SHMEM_addr_t bddr__ = addr__ + sizeof(cuddreal);
  asm volatile ( "st.volatile.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(v2.x), "d"(v2.y), "r"(bddr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const cuDoubleComplex s )
{

  typedef struct { double sx; double sy; } u_type;
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.shared.v2.f64 [%2], {%0,%1};"
                 : : "d"(u.sx), "d"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const cuFloatComplex s )
{

  typedef struct { float sx; float sy; } u_type;
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.shared.v2.f32 [%2], {%0,%1};"
                 : : "f"(u.sx), "f"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const cuHalfComplex s )
{

  typedef struct { ushort sx; ushort sy; } u_type;
  cuHalfComplex ss = static_cast<cuHalfComplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.shared.v2.b16 [%2], {%0,%1};"
                 : : "h"(u.sx), "h"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const half s )
{

  half ss = static_cast<half>(s);
  ushort t = *(reinterpret_cast<ushort *>(&ss));
  asm volatile ( "st.volatile.shared.b16 [%1], %0;"
                 : : "h"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const int128 s )
{

  typedef struct { uint64_t sx; uint64_t sy; } u_type;
  int128 ss = static_cast<int128>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  asm volatile ( "st.volatile.shared.v2.u64 [%2], {%0,%1};"
                 : : "l"(u.sx), "l"(u.sy), "r"(addr__) );

}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const int64 s )
{

  int64 ss = static_cast<int64>(s);
  int64_t t = *(reinterpret_cast<int64_t *>(&ss));
  asm volatile ( "st.volatile.shared.u64 [%1], %0;"
                 : : "l"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const int32 s )
{

  int32 ss = static_cast<int32>(s);
  int32_t t = *(reinterpret_cast<int32_t *>(&ss));
  asm volatile ( "st.volatile.shared.u32 [%1], %0;"
                 : : "r"(t), "r"(addr__) );
}

template < >
__forceinline__ __device__ void
Store_Volatile_Shared ( const SHMEM_addr_t addr__, const int16 s )
{

  int16 ss = static_cast<int16>(s);
  int16_t t = *(reinterpret_cast<int16_t *>(&ss));
  asm volatile ( "st.volatile.shared.u16 [%1], %0;"
                 : : "h"(t), "r"(addr__) );
}

// ---------------------------------------------------------

// ---------------------------------------------------------
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Global_with_Confirm( TYPE * addr__ )
{
  return Load_Volatile_Global ( addr__ );
}

template < class TYPE >
__forceinline__ __device__ void
Store_Global_with_Confirm( TYPE * addr__, const TYPE s )
{
  while ( true ) {

    Store_Volatile_Global( addr__, s );
    const TYPE x = Load_Global_CV ( addr__ );

    if ( s == x ) break;
  }
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( half * addr__, const half s )
{
  half ss = (half)s;
  int16 t = *(reinterpret_cast<int16 *>(&ss));
  int16 * addr_ = (reinterpret_cast<int16 *>(addr__));
  Store_Global_with_Confirm ( addr_, t );
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( float * addr__, const float s )
{
  float ss = (float)s;
  int32 t = *(reinterpret_cast<int32 *>(&ss));
  int32 * addr_ = (reinterpret_cast<int32 *>(addr__));
  Store_Global_with_Confirm ( addr_, t );
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( double * addr__, const double s )
{
  double ss = (double)s;
  int64 t = *(reinterpret_cast<int64 *>(&ss));
  int64 * addr_ = (reinterpret_cast<int64 *>(addr__));
  Store_Global_with_Confirm ( addr_, t );
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( cuddreal * addr__, const cuddreal s )
{
  cuddreal ss = static_cast<cuddreal>(s);
  int128 t = *(reinterpret_cast<int128 *>(&ss));
  int128 * addr_ = (reinterpret_cast<int128 *>(addr__));
  Store_Global_with_Confirm ( addr_, t );
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( cuFloatComplex * addr__, const cuFloatComplex s )
{
  cuFloatComplex ss = static_cast<cuFloatComplex>(s);
  int64 u = *(reinterpret_cast<int64 *>(&ss));
  int64 * addr_ = (reinterpret_cast<int64 *>(addr__));
  Store_Global_with_Confirm ( addr_, u );
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( cuDoubleComplex * addr__, const cuDoubleComplex s )
{
  cuDoubleComplex ss = static_cast<cuDoubleComplex>(s);
  int128 u = *(reinterpret_cast<int128 *>(&ss));
  int128 * addr_ = (reinterpret_cast<int128 *>(addr__));
  Store_Global_with_Confirm ( addr_, u );
}

template < >
__forceinline__ __device__ void
Store_Global_with_Confirm( cuddcomplex * addr__, const cuddcomplex s )
{
  typedef struct { cuddreal sx; cuddreal sy; } u_type;
  cuddcomplex ss = static_cast<cuddcomplex>(s);
  u_type u = *(reinterpret_cast<u_type *>(&ss));
  u_type * addr_ = (reinterpret_cast<u_type *>(addr__));
  Store_Global_with_Confirm ( &addr_->sx, u.sx );
  Store_Global_with_Confirm ( &addr_->sy, u.sy );
}

// ---------------------------------------------------------
 
// ---------------------------------------------------------

#define	__PROXY_SHMEM_DECL__(...)	extern __shared__ int __shmem[]

__PROXY_SHMEM_DECL__();

__forceinline__ __device__ unsigned int
shared_memory_size_per_block( void )
{
  unsigned int ret;
  asm volatile ( "mov.s32 %0, %dynamic_smem_size;" : "=r"(ret) );
  return ret;
}

__forceinline__ __device__ SHMEM_addr_t
shared_memory_raw_proxy_root( void )
{
  SHMEM_addr_t ret;
  asm volatile ( "mov.u32 %0, __shmem;" : "=r"(ret) );
  return ret;
}

template < class TYPE >
__forceinline__ __device__ TYPE *
shared_memory_proxy_root( void )
{
  return reinterpret_cast<TYPE *>(__shmem);
}

template < class TYPE >
__forceinline__ __device__ SHMEM_addr_t
shared_memory_raw_proxy( const int offset )
{
  return shared_memory_raw_proxy_root ( ) + sizeof(TYPE) * offset;
}

template < class TYPE >
__forceinline__ __device__ TYPE *
shared_memory_proxy( void )
{
  int * ret = shared_memory_proxy_root < int > ( );
  return reinterpret_cast<TYPE *>(ret);
}

template < class TYPE >
__forceinline__ __device__ TYPE *
shared_memory_proxy( const int offset )
{
  return shared_memory_proxy <TYPE> ( ) + offset;
}

#if 0
template < class TYPE >
__forceinline__ __device__ TYPE
Load_Shared_from_BASE ( const int offset )
{
  TYPE * shmem = shared_memory_proxy < TYPE > ( offset );
  return *shmem;
}

template < class TYPE >
__forceinline__ __device__ TYPE
Load_Volatile_Shared_from_BASE ( const int offset )
{
  const SHMEM_addr_t shmem = shared_memory_raw_proxy < TYPE > ( offset );
  return Load_Volatile_Shared < TYPE > ( shmem );
}

template < class TYPE >
__forceinline__ __device__ void
Store_Shared_from_BASE ( const int offset, const TYPE x )
{
  TYPE * shmem = shared_memory_proxy < TYPE > ( offset );
  *shmem = x;
}

template < class TYPE >
__forceinline__ __device__ void
Store_Volatile_Shared_from_BASE ( const int offset, const TYPE x )
{
  const SHMEM_addr_t shmem = shared_memory_raw_proxy < TYPE > ( offset );
  Store_Volatile_Shared ( shmem, x );
}
#endif
// ---------------------------------------------------------

// ---------------------------------------------------------
__forceinline__ __device__ void *
convert_addr_to_global ( const void * const addr__ )
{
  unsigned long long int  global_addr;
  asm volatile ( "cvta.to.global.u64 %0, %1;"
                 : "=l"(global_addr) : "l"(addr__) );
  return (void *)global_addr;
}

__forceinline__ __device__ SHMEM_addr_t
convert_addr_to_shared ( const void * const addr__ )
{
  SHMEM_addr_t  shared_addr;
  asm volatile ( "{\n\t"
                 ".reg .u32 %temp;\n\t"
                 "cvt.u32.u64 %temp, %1;\n\t"
                 "cvta.to.shared.u32 %0, %temp;\n\t"
                 "}"
                 : "=r"(shared_addr) : "l"(addr__) );
  return shared_addr;
}

__forceinline__ __device__ void
prefetch_L1 ( const void * const addr__ )
{
  const unsigned long long int addr = (unsigned long long int) addr__;
  asm volatile ( "prefetch.global.L1 [%0];"
                 : : "l"(addr) );
}

__forceinline__ __device__ void
prefetch_L2 ( const void * const addr__ )
{
  const unsigned long long int addr = (unsigned long long int) addr__;
  asm volatile ( "prefetch.global.L2 [%0];"
                 : : "l"(addr) );
}
// ---------------------------------------------------------

#endif

#ifndef ASPEN_INT64_H_INCLUDED
#define ASPEN_INT64_H_INCLUDED		1

#include <stdint.h>
typedef	int64_t	int64;

#ifdef __cplusplus

// for int

__host__ __device__ __forceinline__ int64
__add ( const int64 a,  const int64 b )
{
  const int64 t = (a + b);
  return  t;
}

__host__ __device__ __forceinline__ void
add2 ( const int64 a1, const int64 b1, int64 &d1,
       const int64 a2, const int64 b2, int64 &d2 )
{
  const int64 t1 = __add( a1, b1 );
  const int64 t2 = __add( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int64
__sub ( const int64 a,  const int64 b )
{
  const int64 t = (a - b);
  return  t;
}

__host__ __device__ __forceinline__ void
sub2 ( const int64 a1, const int64 b1, int64 &d1,
       const int64 a2, const int64 b2, int64 &d2 )
{
  const int64 t1 = __sub( a1, b1 );
  const int64 t2 = __sub( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int64
__mul ( const int64 a,  const int64 b )
{
  const int64 t = (a * b);
  return  t;
}

__host__ __device__ __forceinline__ void
mul2 ( const int64 a1, const int64 b1, int64 &d1,
       const int64 a2, const int64 b2, int64 &d2 )
{
  const int64 t1 = __mul( a1, b1 );
  const int64 t2 = __mul( a2, b2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int64
fma ( const int64 a, const int64 b, const int64 c )
{
  const int64 t = (a * b + c);
  return  t;
}

__host__ __device__ __forceinline__ void
fma2 ( const int64 a1, const int64 b1, const int64 c1, int64 &d1,
       const int64 a2, const int64 b2, const int64 c2, int64 &d2 )
{
  const int64 t1 = fma( a1, b1, c1 );
  const int64 t2 = fma( a2, b2, c2 );
  d1 = t1; d2 = t2;
}

__host__ __device__ __forceinline__ int
isnan ( const int64 a )
{
  return false;
}

__host__ __device__ __forceinline__ int
isinf ( const int64 a )
{
  return false;
}

__host__ __device__ __forceinline__ int
isfinite ( const int64 a )
{
  return true;
}

__host__ __device__ __forceinline__ int64
Abs ( const int64 a )
{
  int64  t;
#if defined(__CUDA_ARCH__)
  asm volatile ( "abs.s64\t%0, %1;"
                 : "=l"(t) : "l"(a) );
#else
  t = ( a >= 0 ? a : -a );
#endif
  return  t;
}

__host__ __device__ __forceinline__ int64
Conj ( const int64 a )
{
  return ( a );
}

__host__ __device__ __forceinline__ int64
__choose__ ( const bool flag, const int64 a, const int64 b )
{
  return ( flag ? a : b );
}

__forceinline__ __device__ int64
__choose__( const int cond, const int64 case_pos, const int64 case_neg )
{
  int64 r;
#if defined(__CUDA_ARCH__)
  asm volatile ( "slct.b64.s32\t%0, %1, %2, %3;"
                 : "=l"(r) : "l"(case_pos), "l"(case_neg), "r"(cond) );
#else
  r = ( cond>=0 ? case_pos : case_neg );
#endif
  return r;
}

#endif

#endif


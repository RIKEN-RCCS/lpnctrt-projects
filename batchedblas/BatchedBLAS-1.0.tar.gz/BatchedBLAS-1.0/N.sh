#!/bin/bash
export OMP_NUM_THREADS=12

./bblas_test/batchedf_blas_srotg_test 10 10 300 1
./bblas_test/batchedf_blas_drotg_test 10 10 300 1
./bblas_test/batchedf_blas_srotmg_test 10 10 300 1
./bblas_test/batchedf_blas_drotmg_test 10 10 300 1
./bblas_test/batchedf_blas_srot_test 10 10 300 1
./bblas_test/batchedf_blas_drot_test 10 10 300 1
./bblas_test/batchedf_blas_srotm_test 10 10 300 1
./bblas_test/batchedf_blas_drotm_test 10 10 300 1
./bblas_test/batchedf_blas_sswap_test 10 10 300 1
./bblas_test/batchedf_blas_dswap_test 10 10 300 1
./bblas_test/batchedf_blas_cswap_test 10 10 300 1
./bblas_test/batchedf_blas_zswap_test 10 10 300 1
./bblas_test/batchedf_blas_sscal_test 10 10 300 1
./bblas_test/batchedf_blas_dscal_test 10 10 300 1
./bblas_test/batchedf_blas_cscal_test 10 10 300 1
./bblas_test/batchedf_blas_zscal_test 10 10 300 1
./bblas_test/batchedf_blas_csscal_test 10 10 300 1
./bblas_test/batchedf_blas_zdscal_test 10 10 300 1
./bblas_test/batchedf_blas_scopy_test 10 10 300 1
./bblas_test/batchedf_blas_dcopy_test 10 10 300 1
./bblas_test/batchedf_blas_ccopy_test 10 10 300 1
./bblas_test/batchedf_blas_zcopy_test 10 10 300 1
./bblas_test/batchedf_blas_saxpy_test 10 10 300 1
./bblas_test/batchedf_blas_daxpy_test 10 10 300 1
./bblas_test/batchedf_blas_caxpy_test 10 10 300 1
./bblas_test/batchedf_blas_zaxpy_test 10 10 300 1
./bblas_test/batchedf_blas_sdot_test 10 10 300 1
./bblas_test/batchedf_blas_ddot_test 10 10 300 1
./bblas_test/batchedf_blas_dsdot_test 10 10 300 1
./bblas_test/batchedf_blas_cdotu_test 10 10 300 1
./bblas_test/batchedf_blas_zdotu_test 10 10 300 1
./bblas_test/batchedf_blas_cdotc_test 10 10 300 1
./bblas_test/batchedf_blas_zdotc_test 10 10 300 1
./bblas_test/batchedf_blas_sdsdot_test 10 10 300 1
./bblas_test/batchedf_blas_snrm2_test 10 10 300 1
./bblas_test/batchedf_blas_dnrm2_test 10 10 300 1
./bblas_test/batchedf_blas_scnrm2_test 10 10 300 1
./bblas_test/batchedf_blas_dznrm2_test 10 10 300 1
./bblas_test/batchedf_blas_sasum_test 10 10 300 1
./bblas_test/batchedf_blas_dasum_test 10 10 300 1
./bblas_test/batchedf_blas_scasum_test 10 10 300 1
./bblas_test/batchedf_blas_dzasum_test 10 10 300 1
./bblas_test/batchedf_blas_isamax_test 10 10 300 1
./bblas_test/batchedf_blas_idamax_test 10 10 300 1
./bblas_test/batchedf_blas_icamax_test 10 10 300 1
./bblas_test/batchedf_blas_izamax_test 10 10 300 1
./bblas_test/batchedf_blas_sgemv_test 10 10 300 1
./bblas_test/batchedf_blas_dgemv_test 10 10 300 1
./bblas_test/batchedf_blas_cgemv_test 10 10 300 1
./bblas_test/batchedf_blas_zgemv_test 10 10 300 1
./bblas_test/batchedf_blas_sgbmv_test 10 10 300 1
./bblas_test/batchedf_blas_dgbmv_test 10 10 300 1
./bblas_test/batchedf_blas_cgbmv_test 10 10 300 1
./bblas_test/batchedf_blas_zgbmv_test 10 10 300 1
./bblas_test/batchedf_blas_chemv_test 10 10 300 1
./bblas_test/batchedf_blas_zhemv_test 10 10 300 1
./bblas_test/batchedf_blas_chbmv_test 10 10 300 1
./bblas_test/batchedf_blas_zhbmv_test 10 10 300 1
./bblas_test/batchedf_blas_chpmv_test 10 10 300 1
./bblas_test/batchedf_blas_zhpmv_test 10 10 300 1
./bblas_test/batchedf_blas_ssymv_test 10 10 300 1
./bblas_test/batchedf_blas_dsymv_test 10 10 300 1
./bblas_test/batchedf_blas_ssbmv_test 10 10 300 1
./bblas_test/batchedf_blas_dsbmv_test 10 10 300 1
./bblas_test/batchedf_blas_sspmv_test 10 10 300 1
./bblas_test/batchedf_blas_dspmv_test 10 10 300 1
./bblas_test/batchedf_blas_strmv_test 10 10 300 1
./bblas_test/batchedf_blas_dtrmv_test 10 10 300 1
./bblas_test/batchedf_blas_ctrmv_test 10 10 300 1
./bblas_test/batchedf_blas_ztrmv_test 10 10 300 1
./bblas_test/batchedf_blas_stbmv_test 10 10 300 1
./bblas_test/batchedf_blas_dtbmv_test 10 10 300 1
./bblas_test/batchedf_blas_ctbmv_test 10 10 300 1
./bblas_test/batchedf_blas_ztbmv_test 10 10 300 1
./bblas_test/batchedf_blas_stpmv_test 10 10 300 1
./bblas_test/batchedf_blas_dtpmv_test 10 10 300 1
./bblas_test/batchedf_blas_ctpmv_test 10 10 300 1
./bblas_test/batchedf_blas_ztpmv_test 10 10 300 1
./bblas_test/batchedf_blas_strsv_test 10 10 300 1
./bblas_test/batchedf_blas_dtrsv_test 10 10 300 1
./bblas_test/batchedf_blas_ctrsv_test 10 10 300 1
./bblas_test/batchedf_blas_ztrsv_test 10 10 300 1
./bblas_test/batchedf_blas_stbsv_test 10 10 300 1
./bblas_test/batchedf_blas_dtbsv_test 10 10 300 1
./bblas_test/batchedf_blas_ctbsv_test 10 10 300 1
./bblas_test/batchedf_blas_ztbsv_test 10 10 300 1
./bblas_test/batchedf_blas_stpsv_test 10 10 300 1
./bblas_test/batchedf_blas_dtpsv_test 10 10 300 1
./bblas_test/batchedf_blas_ctpsv_test 10 10 300 1
./bblas_test/batchedf_blas_ztpsv_test 10 10 300 1
./bblas_test/batchedf_blas_sger_test 10 10 300 1
./bblas_test/batchedf_blas_dger_test 10 10 300 1
./bblas_test/batchedf_blas_cgeru_test 10 10 300 1
./bblas_test/batchedf_blas_zgeru_test 10 10 300 1
./bblas_test/batchedf_blas_cgerc_test 10 10 300 1
./bblas_test/batchedf_blas_zgerc_test 10 10 300 1
./bblas_test/batchedf_blas_cher_test 10 10 300 1
./bblas_test/batchedf_blas_zher_test 10 10 300 1
./bblas_test/batchedf_blas_chpr_test 10 10 300 1
./bblas_test/batchedf_blas_zhpr_test 10 10 300 1
./bblas_test/batchedf_blas_cher2_test 10 10 300 1
./bblas_test/batchedf_blas_zher2_test 10 10 300 1
./bblas_test/batchedf_blas_chpr2_test 10 10 300 1
./bblas_test/batchedf_blas_zhpr2_test 10 10 300 1
./bblas_test/batchedf_blas_ssyr_test 10 10 300 1
./bblas_test/batchedf_blas_dsyr_test 10 10 300 1
./bblas_test/batchedf_blas_sspr_test 10 10 300 1
./bblas_test/batchedf_blas_dspr_test 10 10 300 1
./bblas_test/batchedf_blas_ssyr2_test 10 10 300 1
./bblas_test/batchedf_blas_dsyr2_test 10 10 300 1
./bblas_test/batchedf_blas_sspr2_test 10 10 300 1
./bblas_test/batchedf_blas_dspr2_test 10 10 300 1
./bblas_test/batchedf_blas_sgemm_test 10 10 300 1
./bblas_test/batchedf_blas_dgemm_test 10 10 300 1
./bblas_test/batchedf_blas_cgemm_test 10 10 300 1
./bblas_test/batchedf_blas_zgemm_test 10 10 300 1
./bblas_test/batchedf_blas_ssymm_test 10 10 300 1
./bblas_test/batchedf_blas_dsymm_test 10 10 300 1
./bblas_test/batchedf_blas_csymm_test 10 10 300 1
./bblas_test/batchedf_blas_zsymm_test 10 10 300 1
./bblas_test/batchedf_blas_chemm_test 10 10 300 1
./bblas_test/batchedf_blas_zhemm_test 10 10 300 1
./bblas_test/batchedf_blas_ssyrk_test 10 10 300 1
./bblas_test/batchedf_blas_dsyrk_test 10 10 300 1
./bblas_test/batchedf_blas_csyrk_test 10 10 300 1
./bblas_test/batchedf_blas_zsyrk_test 10 10 300 1
./bblas_test/batchedf_blas_cherk_test 10 10 300 1
./bblas_test/batchedf_blas_zherk_test 10 10 300 1
./bblas_test/batchedf_blas_ssyr2k_test 10 10 300 1
./bblas_test/batchedf_blas_dsyr2k_test 10 10 300 1
./bblas_test/batchedf_blas_csyr2k_test 10 10 300 1
./bblas_test/batchedf_blas_zsyr2k_test 10 10 300 1
./bblas_test/batchedf_blas_cher2k_test 10 10 300 1
./bblas_test/batchedf_blas_zher2k_test 10 10 300 1
./bblas_test/batchedf_blas_strmm_test 10 10 300 1
./bblas_test/batchedf_blas_dtrmm_test 10 10 300 1
./bblas_test/batchedf_blas_ctrmm_test 10 10 300 1
./bblas_test/batchedf_blas_ztrmm_test 10 10 300 1
./bblas_test/batchedf_blas_strsm_test 10 10 300 1
./bblas_test/batchedf_blas_dtrsm_test 10 10 300 1
./bblas_test/batchedf_blas_ctrsm_test 10 10 300 1
./bblas_test/batchedf_blas_ztrsm_test 10 10 300 1
./bblas_test/batched_blas_srotg_test 10 10 10 300 1
./bblas_test/batched_blas_drotg_test 10 10 10 300 1
./bblas_test/batched_blas_srotmg_test 10 10 10 300 1
./bblas_test/batched_blas_drotmg_test 10 10 10 300 1
./bblas_test/batched_blas_srot_test 10 10 10 300 1
./bblas_test/batched_blas_drot_test 10 10 10 300 1
./bblas_test/batched_blas_srotm_test 10 10 10 300 1
./bblas_test/batched_blas_drotm_test 10 10 10 300 1
./bblas_test/batched_blas_sswap_test 10 10 10 300 1
./bblas_test/batched_blas_dswap_test 10 10 10 300 1
./bblas_test/batched_blas_cswap_test 10 10 10 300 1
./bblas_test/batched_blas_zswap_test 10 10 10 300 1
./bblas_test/batched_blas_sscal_test 10 10 10 300 1
./bblas_test/batched_blas_dscal_test 10 10 10 300 1
./bblas_test/batched_blas_cscal_test 10 10 10 300 1
./bblas_test/batched_blas_zscal_test 10 10 10 300 1
./bblas_test/batched_blas_csscal_test 10 10 10 300 1
./bblas_test/batched_blas_zdscal_test 10 10 10 300 1
./bblas_test/batched_blas_scopy_test 10 10 10 300 1
./bblas_test/batched_blas_dcopy_test 10 10 10 300 1
./bblas_test/batched_blas_ccopy_test 10 10 10 300 1
./bblas_test/batched_blas_zcopy_test 10 10 10 300 1
./bblas_test/batched_blas_saxpy_test 10 10 10 300 1
./bblas_test/batched_blas_daxpy_test 10 10 10 300 1
./bblas_test/batched_blas_caxpy_test 10 10 10 300 1
./bblas_test/batched_blas_zaxpy_test 10 10 10 300 1
./bblas_test/batched_blas_sdot_test 10 10 10 300 1
./bblas_test/batched_blas_ddot_test 10 10 10 300 1
./bblas_test/batched_blas_dsdot_test 10 10 10 300 1
./bblas_test/batched_blas_cdotu_test 10 10 10 300 1
./bblas_test/batched_blas_zdotu_test 10 10 10 300 1
./bblas_test/batched_blas_cdotc_test 10 10 10 300 1
./bblas_test/batched_blas_zdotc_test 10 10 10 300 1
./bblas_test/batched_blas_sdsdot_test 10 10 10 300 1
./bblas_test/batched_blas_snrm2_test 10 10 10 300 1
./bblas_test/batched_blas_dnrm2_test 10 10 10 300 1
./bblas_test/batched_blas_scnrm2_test 10 10 10 300 1
./bblas_test/batched_blas_dznrm2_test 10 10 10 300 1
./bblas_test/batched_blas_sasum_test 10 10 10 300 1
./bblas_test/batched_blas_dasum_test 10 10 10 300 1
./bblas_test/batched_blas_scasum_test 10 10 10 300 1
./bblas_test/batched_blas_dzasum_test 10 10 10 300 1
./bblas_test/batched_blas_isamax_test 10 10 10 300 1
./bblas_test/batched_blas_idamax_test 10 10 10 300 1
./bblas_test/batched_blas_icamax_test 10 10 10 300 1
./bblas_test/batched_blas_izamax_test 10 10 10 300 1
./bblas_test/batched_blas_sgemv_test 10 10 10 300 1
./bblas_test/batched_blas_dgemv_test 10 10 10 300 1
./bblas_test/batched_blas_cgemv_test 10 10 10 300 1
./bblas_test/batched_blas_zgemv_test 10 10 10 300 1
./bblas_test/batched_blas_sgbmv_test 10 10 10 300 1
./bblas_test/batched_blas_dgbmv_test 10 10 10 300 1
./bblas_test/batched_blas_cgbmv_test 10 10 10 300 1
./bblas_test/batched_blas_zgbmv_test 10 10 10 300 1
./bblas_test/batched_blas_chemv_test 10 10 10 300 1
./bblas_test/batched_blas_zhemv_test 10 10 10 300 1
./bblas_test/batched_blas_chbmv_test 10 10 10 300 1
./bblas_test/batched_blas_zhbmv_test 10 10 10 300 1
./bblas_test/batched_blas_chpmv_test 10 10 10 300 1
./bblas_test/batched_blas_zhpmv_test 10 10 10 300 1
./bblas_test/batched_blas_ssymv_test 10 10 10 300 1
./bblas_test/batched_blas_dsymv_test 10 10 10 300 1
./bblas_test/batched_blas_ssbmv_test 10 10 10 300 1
./bblas_test/batched_blas_dsbmv_test 10 10 10 300 1
./bblas_test/batched_blas_sspmv_test 10 10 10 300 1
./bblas_test/batched_blas_dspmv_test 10 10 10 300 1
./bblas_test/batched_blas_strmv_test 10 10 10 300 1
./bblas_test/batched_blas_dtrmv_test 10 10 10 300 1
./bblas_test/batched_blas_ctrmv_test 10 10 10 300 1
./bblas_test/batched_blas_ztrmv_test 10 10 10 300 1
./bblas_test/batched_blas_stbmv_test 10 10 10 300 1
./bblas_test/batched_blas_dtbmv_test 10 10 10 300 1
./bblas_test/batched_blas_ctbmv_test 10 10 10 300 1
./bblas_test/batched_blas_ztbmv_test 10 10 10 300 1
./bblas_test/batched_blas_stpmv_test 10 10 10 300 1
./bblas_test/batched_blas_dtpmv_test 10 10 10 300 1
./bblas_test/batched_blas_ctpmv_test 10 10 10 300 1
./bblas_test/batched_blas_ztpmv_test 10 10 10 300 1
./bblas_test/batched_blas_strsv_test 10 10 10 300 1
./bblas_test/batched_blas_dtrsv_test 10 10 10 300 1
./bblas_test/batched_blas_ctrsv_test 10 10 10 300 1
./bblas_test/batched_blas_ztrsv_test 10 10 10 300 1
./bblas_test/batched_blas_stbsv_test 10 10 10 300 1
./bblas_test/batched_blas_dtbsv_test 10 10 10 300 1
./bblas_test/batched_blas_ctbsv_test 10 10 10 300 1
./bblas_test/batched_blas_ztbsv_test 10 10 10 300 1
./bblas_test/batched_blas_stpsv_test 10 10 10 300 1
./bblas_test/batched_blas_dtpsv_test 10 10 10 300 1
./bblas_test/batched_blas_ctpsv_test 10 10 10 300 1
./bblas_test/batched_blas_ztpsv_test 10 10 10 300 1
./bblas_test/batched_blas_sger_test 10 10 10 300 1
./bblas_test/batched_blas_dger_test 10 10 10 300 1
./bblas_test/batched_blas_cgeru_test 10 10 10 300 1
./bblas_test/batched_blas_zgeru_test 10 10 10 300 1
./bblas_test/batched_blas_cgerc_test 10 10 10 300 1
./bblas_test/batched_blas_zgerc_test 10 10 10 300 1
./bblas_test/batched_blas_cher_test 10 10 10 300 1
./bblas_test/batched_blas_zher_test 10 10 10 300 1
./bblas_test/batched_blas_chpr_test 10 10 10 300 1
./bblas_test/batched_blas_zhpr_test 10 10 10 300 1
./bblas_test/batched_blas_cher2_test 10 10 10 300 1
./bblas_test/batched_blas_zher2_test 10 10 10 300 1
./bblas_test/batched_blas_chpr2_test 10 10 10 300 1
./bblas_test/batched_blas_zhpr2_test 10 10 10 300 1
./bblas_test/batched_blas_ssyr_test 10 10 10 300 1
./bblas_test/batched_blas_dsyr_test 10 10 10 300 1
./bblas_test/batched_blas_sspr_test 10 10 10 300 1
./bblas_test/batched_blas_dspr_test 10 10 10 300 1
./bblas_test/batched_blas_ssyr2_test 10 10 10 300 1
./bblas_test/batched_blas_dsyr2_test 10 10 10 300 1
./bblas_test/batched_blas_sspr2_test 10 10 10 300 1
./bblas_test/batched_blas_dspr2_test 10 10 10 300 1
./bblas_test/batched_blas_sgemm_test 10 10 10 300 1
./bblas_test/batched_blas_dgemm_test 10 10 10 300 1
./bblas_test/batched_blas_cgemm_test 10 10 10 300 1
./bblas_test/batched_blas_zgemm_test 10 10 10 300 1
./bblas_test/batched_blas_ssymm_test 10 10 10 300 1
./bblas_test/batched_blas_dsymm_test 10 10 10 300 1
./bblas_test/batched_blas_csymm_test 10 10 10 300 1
./bblas_test/batched_blas_zsymm_test 10 10 10 300 1
./bblas_test/batched_blas_chemm_test 10 10 10 300 1
./bblas_test/batched_blas_zhemm_test 10 10 10 300 1
./bblas_test/batched_blas_ssyrk_test 10 10 10 300 1
./bblas_test/batched_blas_dsyrk_test 10 10 10 300 1
./bblas_test/batched_blas_csyrk_test 10 10 10 300 1
./bblas_test/batched_blas_zsyrk_test 10 10 10 300 1
./bblas_test/batched_blas_cherk_test 10 10 10 300 1
./bblas_test/batched_blas_zherk_test 10 10 10 300 1
./bblas_test/batched_blas_ssyr2k_test 10 10 10 300 1
./bblas_test/batched_blas_dsyr2k_test 10 10 10 300 1
./bblas_test/batched_blas_csyr2k_test 10 10 10 300 1
./bblas_test/batched_blas_zsyr2k_test 10 10 10 300 1
./bblas_test/batched_blas_cher2k_test 10 10 10 300 1
./bblas_test/batched_blas_zher2k_test 10 10 10 300 1
./bblas_test/batched_blas_strmm_test 10 10 10 300 1
./bblas_test/batched_blas_dtrmm_test 10 10 10 300 1
./bblas_test/batched_blas_ctrmm_test 10 10 10 300 1
./bblas_test/batched_blas_ztrmm_test 10 10 10 300 1
./bblas_test/batched_blas_strsm_test 10 10 10 300 1
./bblas_test/batched_blas_dtrsm_test 10 10 10 300 1
./bblas_test/batched_blas_ctrsm_test 10 10 10 300 1
./bblas_test/batched_blas_ztrsm_test 10 10 10 300 1

./bblas_test/batched_blas_hasum_test 10 10 300 1
./bblas_test/batchedf_blas_hasum_test 10 10 300 1
./bblas_test/batched_blas_haxpy_test 10 10 300 1
./bblas_test/batchedf_blas_haxpy_test 10 10 300 1
./bblas_test/batched_blas_hcopy_test 10 10 300 1
./bblas_test/batchedf_blas_hcopy_test 10 10 300 1
./bblas_test/batched_blas_hdot_test 10 10 300 1
./bblas_test/batchedf_blas_hdot_test 10 10 300 1
./bblas_test/batched_blas_hgemm_test 10 10 300 1
./bblas_test/batchedf_blas_hgemm_test 10 10 300 1
./bblas_test/batched_blas_hgemv_test 10 10 300 1
./bblas_test/batchedf_blas_hgemv_test 10 10 300 1
./bblas_test/batched_blas_hger_test 10 10 300 1
./bblas_test/batchedf_blas_hger_test 10 10 300 1
./bblas_test/batched_blas_hscal_test 10 10 300 1
./bblas_test/batchedf_blas_hscal_test 10 10 300 1
./bblas_test/batched_blas_hswap_test 10 10 300 1
./bblas_test/batchedf_blas_hswap_test 10 10 300 1
./bblas_test/batchedf_blas_ihamax_test 10 10 300 1
./bblas_test/batched_blas_ihamax_test 10 10 300 1

import sys
import csv
import os.path
import shutil

src_path = './bblas_src'

if not os.path.exists(src_path):
  os.mkdir(src_path)

# ask whether the argument is pointer
#  return
#   argument is pointer : True
#             not       : False
def pointer_(typ):
  if typ.find('*') >= 0:
    ret = True
  else:
    ret = False
  return ret

# ask whether the argument's category is local
#  return
#   argument is local : True
#             not     : False
def local_(cat):
  if cat.find('l') >= 0:
    ret = True
  else:
    ret = False
  return ret

# ask whether the argument's category is group
#  return
#   argument is group : True
#             not     : False
def group_(cat):
  if cat.find('g') >= 0:
    ret = True
  else:
    ret = False
  return ret

# ask whether fuction doesn't have return value
#  return
#   not have return value : True
#       have return value : Flase
def void_(r):
  if r.find('void') >= 0:
    ret = True
  else:
    ret = False
  return ret

# routine declaration
def routine_declaration(fw,row1,row2):
  fw.write('void ')
  fw.write(row1[0])
  c = 0
  for r in row2:
    if c == 0:
      fw.write('(')
      if '_batchf' in row1[0] :
        fw.write('const int group_size,')
      else :
        fw.write('const int group_count,const int *group_size,')
    # get category
    if c % 3 == 0:
      typ = r 
      cat = row2[c+2]
    # write word
    if c % 3 == 2:
      pass
    else:
      fw.write(r)
    
    if c % 3 == 0:
      if (pointer_(typ) and local_(cat)) or \
            ((not pointer_(typ)) and (group_(cat) or local_(cat))):
        fw.write('*')
      fw.write(' ')
    elif c % 3 == 1:
      fw.write(',')
      
    c = c + 1

  # additional argument for returning result
  if not void_(row1[1]):
    fw.write(row1[1])
    fw.write('*')
    fw.write(' ret_')
    fw.write(row1[2])
    fw.write(',')
    
  fw.write('int *info)')

  return

# routine call
def routine_call(fw,row1,row2):

  if not void_(row1[1]):
    fw.write('ret_')
    fw.write(row1[2])
    fw.write('[group_head[group_no]+local_no]')
    fw.write(' = ')
  
  fw.write(row1[2])
  
  c = 0
  for r in row2:
    if c % 3 == 0:
      if c == 0:
        fw.write('(')
        
      cat = row2[c+2]
      # for complex number
      if cat.find('g') >= 0:
        if cat.find('z') >= 0:
          fw.write('(double *)')
        elif cat.find('c') >= 0:
          fw.write('(float *)')

      # write name
      fw.write(row2[c+1])
      
      if cat.find('l') >= 0:
        fw.write('[group_head[group_no]+local_no]')
      elif cat.find('g') >= 0:
        # for complex number
        if cat.find('z') >= 0 or cat.find('c') >= 0:
          fw.write('+2*group_no')
        else:
          fw.write('[group_no]')
      if c == len(row2) - 3:
        fw.write(');')
      else:
        fw.write(',')
       
    c = c + 1
    
  fw.write('\n')

  return

def routine_fixed(fw_r,row1,row2):
  fw_r.write('  int group_count=1;\n')
  fw_r.write('  '+row1[0].replace('_batchf','_batch'))
  c = 0
  a ='(group_count,&group_size,'
  for r in row2:
    c = c + 1
    if(c == 2):
      a=a + r + ','
    if(c == 3):
      c = 0   

  # additional argument for returning result
  if not void_(row1[1]):
    a = a + 'ret_' + row1[2] +','

  a = a + 'info); \n'
  a=a.replace(',incx,',',&incx,')
  a=a.replace(',incy,',',&incy,')

  a=a.replace(',n,',',&n,')
  a=a.replace(',m,',',&m,')
  a=a.replace(',k,',',&k,')
  a=a.replace(',a1,',',&a1,')
  a=a.replace(',sb,',',&sb,')
  a=a.replace(',c1,',',&c1,')
  a=a.replace(',s1,',',&s1,')
  a=a.replace(',transa,',',&transa,')
  a=a.replace(',transb,',',&transb,')
  a=a.replace(',trans,',',&trans,')
  a=a.replace(',diag,',',&diag,')
  a=a.replace(',kl,',',&kl,')
  a=a.replace(',ku,',',&ku,')
  a=a.replace(',side,',',&side,')

  a=a.replace(',alpha,',',&alpha,')
  a=a.replace(',beta,',',&beta,')
  a=a.replace(',lda,',',&lda,')
  a=a.replace(',ldb,',',&ldb,')
  a=a.replace(',ldc,',',&ldc,')
  a=a.replace(',uplo,',',&uplo,')

  fw_r.write(a)
  fw_r.write('}\n')

def routine_part1(fw_r):
  fw_r.write('#include <stdlib.h>\n')
  fw_r.write('#include <omp.h>\n')
  fw_r.write('\n')
  fw_r.write('#include "batched_blas_common.h"\n')
  fw_r.write('#include "batched_blas_fp16.h"\n')
  fw_r.write('#include "batched_blas_cost.h"\n')
  fw_r.write('#include "batched_blas_schedule.h"\n')
  fw_r.write('#include "bblas_error.h"\n')
  fw_r.write('\n')

  return

# routine declaration
def routine_part2(fw_r,row1,row2):
  routine_declaration(fw_r,row1,row2)
  fw_r.write('\n')
  fw_r.write('{\n')
  return

def routine_part3(fw_r):
  fw_r.write('  int total_batch_count;\n')
  fw_r.write('  int *which_thread;\n') 
  fw_r.write('  const int num_threads = omp_get_max_threads();\n')
  fw_r.write('  int local_no, group_no;\n')
  fw_r.write('  int my_tno;\n')
  fw_r.write('  int group_head[group_count];\n') 
  fw_r.write('  struct _cost_param cost_param;\n')
  fw_r.write('\n')
  fw_r.write('  if (group_count < 0) {\n')
  fw_r.write('    bblas_error("Illegal value of group_count");\n')
  fw_r.write('    info[0] = -1;\n')
  fw_r.write('    return;\n')
  fw_r.write('  }\n')
  fw_r.write('  int offset = 0;\n')
  fw_r.write('  int info_offset = 0;\n')
  fw_r.write('  int info_option = info[0];\n')
  fw_r.write('  int flag = 0;\n')
  fw_r.write('\n')
  fw_r.write('  total_batch_count = 0;\n')
  fw_r.write('  for (group_no = 0; group_no < group_count; group_no++) {\n')
  fw_r.write('    total_batch_count += group_size[group_no];\n') 
  fw_r.write('  }\n')
  fw_r.write('\n')
  fw_r.write('  group_head[0] = 0;\n')
  fw_r.write('  for(group_no = 1; group_no < group_count; group_no++){\n')
  fw_r.write('    group_head[group_no] = group_head[group_no - 1] + group_size[group_no - 1];\n') 
  fw_r.write('  }\n')
  fw_r.write('\n')

  return

def routine_errorcheck_part1(omp):
  fw_r.write('\n') 
  fw_r.write('      int info_local;\n') 
  fw_r.write('      if (info_option == BblasErrorsReportAll) \n') 
  fw_r.write('        info_offset = offset+1;\n') 
  fw_r.write('      else if (info_option == BblasErrorsReportGroup)\n') 
  fw_r.write('        info_offset = group_no+1;\n') 
  fw_r.write('      else\n') 
  fw_r.write('        info_offset = 0;\n') 
  fw_r.write('      info_local = info_option;\n') 
  fw_r.write('      if (group_size[group_no] < 0) {\n') 
  if omp == 'on' :
    fw_r.write('        #pragma omp master \n')
  fw_r.write('        { \n')
  fw_r.write('        bblas_error("Illegal values of group_sizes");\n') 
  fw_r.write('        info[0] = -2;\n') 
  fw_r.write('        } \n')

  return

def routine_errorcheck_part2(row2):
  if row2.count('layout') > 0 :
    fw_r.write('      if ((layout != BblasRowMajor) &&\n')
    fw_r.write('          (layout != BblasColMajor)) {\n')
    fw_r.write('          bblas_error("Illegal value of layout");\n')
    fw_r.write('          if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('            bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 1);\n')
    fw_r.write('          }\n')
    fw_r.write('        return;\n')
    fw_r.write('      }\n')

  if row2.count('transa') > 0 :
    fw_r.write('      if ((transa[group_no] != BblasNoTrans) &&\n')
    fw_r.write('	  (transa[group_no] != BblasTrans) &&\n')
    fw_r.write('	  (transa[group_no] != BblasConjTrans)) {\n')
    fw_r.write('	  bblas_error("Illegal value of transa");\n')
    fw_r.write('	  if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	    bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 2);\n')
    fw_r.write('	  }\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('transb') > 0 :
    fw_r.write('      if ((transb[group_no] != BblasNoTrans) &&\n')
    fw_r.write('	  (transb[group_no] != BblasTrans) &&\n')
    fw_r.write('	  (transb[group_no] != BblasConjTrans)) {\n')
    fw_r.write('	bblas_error("Illegal value of transb");\n')
    fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 3);\n')
    fw_r.write('	}\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('m') > 0 :
    fw_r.write('      if (m[group_no] < 0) {\n')
    fw_r.write('	bblas_error("Illegal value of m");\n')
    fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 4);\n')
    fw_r.write('	}\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('n') > 0 :
    fw_r.write('      if (n[group_no] < 0) {\n')
    fw_r.write('	bblas_error("Illegal value of n");\n')
    fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 5);\n')
    fw_r.write('	}\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('k') > 0 :
    fw_r.write('      if (k[group_no] < 0) {\n')
    fw_r.write('	bblas_error("Illegal value of k");\n')
    fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 6);\n')
    fw_r.write('	}\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('lda') > 0 :
    fw_r.write('      if (lda[group_no] < imax(1, lda[group_no])) {\n')
    fw_r.write('	bblas_error("Illegal value of lda");\n')
    fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 7);\n')
    fw_r.write('	}\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('ldb') > 0 :
    fw_r.write('      if (ldb[group_no] < imax(1, ldb[group_no])) {\n')
    fw_r.write('	bblas_error("Illegal value of ldb");\n')
    fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 8);\n')
    fw_r.write('	}\n')
    fw_r.write('	return;\n')
    fw_r.write('      }\n')

  if row2.count('ldc') > 0 :
    if row2.count('m') > 0 :
      fw_r.write('      if (ldc[group_no] < imax(1, m[group_no])) {\n')
      fw_r.write('	bblas_error("Illegal value of ldc");\n')
      fw_r.write('	if (info[info_offset] != BblasErrorsReportNone) {\n')
      fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 9);\n')
      fw_r.write('	}\n')
      fw_r.write('	return;\n')
      fw_r.write('      }\n')

    return

def routine_errorcheck_part3(row2):
  if row2.count('layout') > 0 :
    fw_r.write('      if ((layout != BblasRowMajor) &&\n')
    fw_r.write('          (layout != BblasColMajor)) {\n')
    fw_r.write('          #pragma omp master \n')
    fw_r.write('          { \n')
    fw_r.write('          bblas_error("Illegal value of layout");\n')
    fw_r.write('          if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('            bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 1);\n')
    fw_r.write('          }\n')
    fw_r.write('          }\n')
    fw_r.write('        break;\n')
    fw_r.write('      }\n')

  if row2.count('transa') > 0 :
    fw_r.write('      if ((transa[group_no] != BblasNoTrans) &&\n')
    fw_r.write('	  (transa[group_no] != BblasTrans) &&\n')
    fw_r.write('	  (transa[group_no] != BblasConjTrans)) {\n')
    fw_r.write('          #pragma omp master \n')
    fw_r.write('          { \n')
    fw_r.write('	  bblas_error("Illegal value of transa");\n')
    fw_r.write('	  if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	    bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 2);\n')
    fw_r.write('	  }\n')
    fw_r.write('          }\n')
    fw_r.write('	break;\n')
    fw_r.write('      }\n')

  if row2.count('transb') > 0 :
    fw_r.write('      if ((transb[group_no] != BblasNoTrans) &&\n')
    fw_r.write('	  (transb[group_no] != BblasTrans) &&\n')
    fw_r.write('	  (transb[group_no] != BblasConjTrans)) {\n')
    fw_r.write('          #pragma omp master \n')
    fw_r.write('          { \n')
    fw_r.write('	  bblas_error("Illegal value of transb");\n')
    fw_r.write('	  if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	    bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 3);\n')
    fw_r.write('	  }\n')
    fw_r.write('          }\n')
    fw_r.write('	  break;\n')
    fw_r.write('        }\n')

  if row2.count('m') > 0 :
    fw_r.write('      if (m[group_no] < 0) {\n')
    fw_r.write('        #pragma omp master \n')
    fw_r.write('        { \n')
    fw_r.write('	bblas_error("Illegal value of m");\n')
    fw_r.write('	if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 4);\n')
    fw_r.write('	}\n')
    fw_r.write('        }\n')
    fw_r.write('	break;\n')
    fw_r.write('      }\n')

  if row2.count('n') > 0 :
    fw_r.write('      if (n[group_no] < 0) {\n')
    fw_r.write('        #pragma omp master \n')
    fw_r.write('        { \n')
    fw_r.write('	bblas_error("Illegal value of n");\n')
    fw_r.write('	if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 5);\n')
    fw_r.write('	}\n')
    fw_r.write('        }\n')
    fw_r.write('	break;\n')
    fw_r.write('      }\n')

  if row2.count('k') > 0 :
    fw_r.write('      if (k[group_no] < 0) {\n')
    fw_r.write('        #pragma omp master \n')
    fw_r.write('        { \n')
    fw_r.write('	bblas_error("Illegal value of k");\n')
    fw_r.write('	if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 6);\n')
    fw_r.write('	}\n')
    fw_r.write('        }\n')
    fw_r.write('	break;\n')
    fw_r.write('      }\n')

  if row2.count('lda') > 0 :
    fw_r.write('      if (lda[group_no] < imax(1, lda[group_no])) {\n')
    fw_r.write('        #pragma omp master \n')
    fw_r.write('        { \n')
    fw_r.write('	bblas_error("Illegal value of lda");\n')
    fw_r.write('	if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 7);\n')
    fw_r.write('	}\n')
    fw_r.write('        }\n')
    fw_r.write('	break;\n')
    fw_r.write('      }\n')

  if row2.count('ldb') > 0 :
    fw_r.write('      if (ldb[group_no] < imax(1, ldb[group_no])) {\n')
    fw_r.write('        #pragma omp master \n')
    fw_r.write('        { \n')
    fw_r.write('	bblas_error("Illegal value of ldb");\n')
    fw_r.write('	if (info_local != BblasErrorsReportNone) {\n')
    fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 8);\n')
    fw_r.write('	}\n')
    fw_r.write('        }\n')
    fw_r.write('	break;\n')
    fw_r.write('      }\n')

  if row2.count('ldc') > 0 :
    if row2.count('m') > 0 :
      fw_r.write('      if (ldc[group_no] < imax(1, m[group_no])) {\n')
      fw_r.write('      #pragma omp master \n')
      fw_r.write('      { \n')
      fw_r.write('	bblas_error("Illegal value of ldc");\n')
      fw_r.write('	if (info_local != BblasErrorsReportNone) {\n')
      fw_r.write('	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 9);\n')
      fw_r.write('	}\n')
      fw_r.write('      }\n')
      fw_r.write('	break;\n')
      fw_r.write('      }\n')

    return


def routine_part3_1(fw_r,row1,row2):

  fw_r.write('  if(!use_batch()){\n')
  fw_r.write('    for (group_no = 0; group_no < group_count; group_no++){\n')
  routine_errorcheck_part1('off')
  fw_r.write('        return;\n') 
  fw_r.write('      }\n') 
  routine_errorcheck_part2(row2)
  fw_r.write('\n')   
  fw_r.write('      for (local_no = 0; local_no < group_size[group_no]; local_no++){\n')
  fw_r.write('        ')
  routine_call(fw_r,row1,row2)
  fw_r.write('        if (info_local == BblasErrorsReportAll)\n')
  fw_r.write('          info[local_no+info_offset] = 0;\n')
  fw_r.write('      }\n')
  fw_r.write('      if (info_local != BblasErrorsReportAll)\n')
  fw_r.write('        info_local = 0;\n')
  fw_r.write('      if (info_local != 0 && flag == 0) {\n')
  fw_r.write('        info[0] = info[info_offset];\n')
  fw_r.write('        flag = 1;\n')
  fw_r.write('      }\n')
  fw_r.write('      offset += group_size[group_no];\n')
  fw_r.write('    }\n')
  fw_r.write('    return;\n')
  fw_r.write('  }\n')
  fw_r.write('\n')

  return

def routine_part4(fw_r,row3):
  
  c = 0
  for r in row3:
    if c == 0:
      pass
    else:
      fw_r.write('  cost_param.ptr[')
      fw_r.write('%d' % (c-1))
      fw_r.write('] = (void *)')
      fw_r.write(r)
      fw_r.write(';')
      fw_r.write('\n')
    c = c + 1
    
  fw_r.write('\n')
  fw_r.write('\n')

  return

def routine_part5(fw_r,row3):
  fw_r.write('  which_thread = (int *) malloc(sizeof(int) * total_batch_count);\n')
  fw_r.write('  schedule_batch(group_count, group_size,')
  fw_r.write(row3[0])
  fw_r.write(',&cost_param, which_thread);\n')
  fw_r.write('\n')
  fw_r.write('#pragma omp parallel default(shared) num_threads(num_threads)	\\\n')
  fw_r.write('  private(group_no, local_no, my_tno) firstprivate(flag, offset, info_offset) \n')
  fw_r.write('  {\n')
  fw_r.write('  my_tno = omp_get_thread_num();\n')
  fw_r.write('  for (group_no = 0; group_no < group_count; group_no++){\n')
  routine_errorcheck_part1('on')
  fw_r.write('        break;\n') 
  fw_r.write('      }\n') 
  routine_errorcheck_part3(row2)
  fw_r.write('\n')   
  fw_r.write('    for (local_no = 0; local_no < group_size[group_no]; local_no++){\n')
  fw_r.write('      if(which_thread[group_head[group_no]+local_no] == my_tno){\n')
  
  return

# subroutine call
def routine_part6(fw_r,row1,row2):
  fw_r.write('        ')
  
  routine_call(fw_r,row1,row2)
  
  return

def routine_part7(fw_r):
  fw_r.write('        if (info_local == BblasErrorsReportAll)\n')
  fw_r.write('          info[local_no+info_offset] = 0;\n')
  fw_r.write('      }\n')
  fw_r.write('    }\n')
  fw_r.write('      if (info_local != BblasErrorsReportAll)\n')
  fw_r.write('        info_local = 0;\n')
  fw_r.write('      if (info_local != 0 && flag == 0) {\n')
  fw_r.write('        #pragma omp critical \n')
  fw_r.write('        { \n')
  fw_r.write('        info[0] = info[info_offset];\n')
  fw_r.write('        } \n')
  fw_r.write('        flag = 1;\n')
  fw_r.write('      }\n')
  fw_r.write('  }\n')
  fw_r.write('      offset += group_size[group_no];\n')
  fw_r.write('  }\n')
  fw_r.write('\n')
  fw_r.write('  free(which_thread);\n')
  fw_r.write('\n')
  fw_r.write('  return;\n')
  fw_r.write('}\n')
  fw_r.write('\n')

  return

def header_part1(fw_h):
  fw_h.write('#ifndef _BATCHED_BLAS_dgemm_H_\n')
  fw_h.write('#define _BATCHED_BLAS_dgemm_H_\n')
  fw_h.write('\n')
  fw_h.write('#include "batched_blas_common.h"\n')
  fw_h.write('\n')

  return

def header_part2(fw_h,row1,row2):
  routine_declaration(fw_h,row1,row2)
  fw_h.write(';')
  fw_h.write('\n')
  return

def header_part3(fw_h):
  fw_h.write('\n')
  fw_h.write('#endif\n')

  return

def make_part1(fw_mk):
  fw_mk.write('ifeq (x$(CC),xcc)\n')
  fw_mk.write('ifdef MKLROOT\n')
  fw_mk.write('CC=icc\n')
  fw_mk.write('else\n')
  fw_mk.write('ifdef FJSVXTCLANGA\n')
  fw_mk.write('CC=fccpx\n')
  fw_mk.write('else\n')
  fw_mk.write('CC=gcc\n')
  fw_mk.write('endif\n')
  fw_mk.write('endif\n')
  fw_mk.write('endif\n')
  fw_mk.write('\n')
  fw_mk.write('ifeq (x$(CC),xicc)\n')
  fw_mk.write('CCFLAG=-Os -xHost -qopenmp -I./\n')
  fw_mk.write('BLAS=-lmkl_rt -lm\n')
  fw_mk.write('else\n')
  fw_mk.write('ifeq (x$(CC),xfccpx)\n')
  fw_mk.write('CCFLAG=-std=gnu11 -Kfast,ocl,openmp -Nclang -D_CBLAS_ -I./\n')
  fw_mk.write('BLAS=-SSL2BLAMP -lm\n')
  fw_mk.write('else\n')
  fw_mk.write('ifeq (x$(CC),xarmclang)\n')
  fw_mk.write('CCFLAG=-O3 -fopenmp -Wall -armpl=sve -mcpu=a64fx -D_CBLAS_ -I./\n')
  fw_mk.write('BLAS=-armpl -lm\n')
  fw_mk.write('else\n')
  fw_mk.write('CCFLAG=-O3 -fopenmp -Wall -D_CBLAS_ -I./ -I/usr/include/openblas\n')
  fw_mk.write('BLAS=-lopenblas -lm\n')
  fw_mk.write('endif\n')
  fw_mk.write('endif\n')
  fw_mk.write('endif\n')
  fw_mk.write('\n')
  fw_mk.write('CCFLAG+=-fPIC\n')
  fw_mk.write('\n')
  #fw_mk.write('CC=icc\n')
  #fw_mk.write('CCFLAG=-O3 -xHost -qopenmp -I./ \n')
  #fw_mk.write('#CC=gcc\n')
  #fw_mk.write('#CCFLAG=-O3 -fopenmp -Wall -D_CBLAS_ -I./ \n')
  #fw_mk.write('#CC=fccpx\n')
  #fw_mk.write('#CCFLAG=-Kfast,ocl,openmp -Nclang -D_CBLAS_ -I./ \n')
  fw_mk.write('\n')
  fw_mk.write('AR=ar\n')
  #fw_mk.write('BLAS=-mkl=parallel\n')
  fw_mk.write('\n')
  #fw_mk.write('LIB_BATCHED_BLAS = libbatched_blas.a\n')
  fw_mk.write('LIB_BATCHED_BLAS = libbblas.a\n')
  fw_mk.write('LIB_BATCHED_BLAS_SO = libbblas.so\n')
  fw_mk.write('\n')
  fw_mk.write('OBJS_COMMON = \\\n')
  fw_mk.write('batched_blas_consts.o \\\n')
  fw_mk.write('batched_blas_common.o \\\n')
  fw_mk.write('batched_blas_schedule.o \\\n')
  fw_mk.write('batched_blas_cost.o\n')
  fw_mk.write('\n')
  fw_mk.write('OBJS_SRC = ')

  return

def make_part2(fw_mk,routine_name):
  fw_mk.write(' \\\n')
  fw_mk.write(routine_name + '.o')
  return

def make_part3(fw_mk):
  fw_mk.write('\n')
  fw_mk.write('\n')
  fw_mk.write('OBJS = $(OBJS_COMMON) $(OBJS_SRC)\n')
  fw_mk.write('\n')
  fw_mk.write('all : $(LIB_BATCHED_BLAS) $(LIB_BATCHED_BLAS_SO)\n')
  fw_mk.write('$(LIB_BATCHED_BLAS) : $(OBJS)\n')
  fw_mk.write('\t$(AR) r $(LIB_BATCHED_BLAS) $(OBJS)\n')
  fw_mk.write('$(LIB_BATCHED_BLAS_SO) : $(OBJS)\n')
  fw_mk.write('\t$(CC) -fPIC -shared -o $(LIB_BATCHED_BLAS_SO) $(OBJS)\n')
  fw_mk.write('\n')
  fw_mk.write('.c.o :\n')
  fw_mk.write('\t$(CC) $(CCFLAG) -c $< $(DEF)\n')
  fw_mk.write('\n')
  fw_mk.write('clean :\n')
  fw_mk.write('\trm -f $(LIB_BATCHED_BLAS) *.o\n')

  return

def copy_files():
  shutil.copy('include/batched_blas_common.c', src_path)
  shutil.copy('include/batched_blas_common.h', src_path)
  shutil.copy('include/batched_blas_cost.c', src_path)
  shutil.copy('include/batched_blas_cost.h', src_path)
  shutil.copy('include/batched_blas_schedule.c', src_path)
  shutil.copy('include/batched_blas_schedule.h', src_path)
  shutil.copy('include/bblas.h', src_path)
  shutil.copy('include/bblas_types.h', src_path)
  shutil.copy('include/bblas_error.h', src_path)
  shutil.copy('include/batched_blas_consts.c', src_path)
  shutil.copy('include/batched_blas_fp16.h', src_path)
  return

def routne_cblas_param(iofile):
  ofile = iofile
  ifile = iofile + '_'
  shutil.copyfile(iofile,ifile)
  fr = open(ifile,'r')
  fw = open(ofile,'w')

  for row in fr:
    if 'cblas_' in row:
      row_rep = row
      if 'diag[group_no]' in row_rep:
        row_rep = row_rep.replace('diag[group_no]','diag_cblas( diag[group_no] ) ')
      if 'side[group_no]' in row_rep:                
        row_rep = row_rep.replace('side[group_no]','side_cblas( side[group_no] ) ')
      if 'trans[group_no]' in row_rep:                
        row_rep = row_rep.replace('trans[group_no]','transpose_cblas( trans[group_no] ) ')
      if 'transa[group_no]' in row_rep:                
        row_rep = row_rep.replace('transa[group_no]','transpose_cblas( transa[group_no] ) ')
      if 'transb[group_no]' in row_rep:                
        row_rep = row_rep.replace('transb[group_no]','transpose_cblas( transb[group_no] ) ')
      if 'uplo[group_no]' in row_rep:                
        row_rep = row_rep.replace('uplo[group_no]','uplo_cblas( uplo[group_no] ) ')
      if 'layout' in row_rep:                
        row_rep = row_rep.replace('layout','layout_cblas( layout ) ')
      fw.write(row_rep)
    else:
      fw.write(row)

  fr.close()
  fw.close()
  os.remove(ifile)
  return

args = sys.argv
argc = len(args)

if (argc < 2):
  print('Usage: python *.py <description_file.csv>')
  quit()

fr = open(args[1],'r')

reader = csv.reader(fr)

# create header file
fw_h = open(src_path + '/' + 'batched_blas.h','w')
# create Make file
fw_mk = open(src_path + '/' + 'Makefile','w')

header_part1(fw_h)
make_part1(fw_mk)

mode = 0
for row in reader:
  if mode == 0:
    row1 = row
  elif mode == 1:
    row2 = row
  else:
    row3 = row
    routine_type = row1[1]
    routine_name = row1[2]
    # make c program
    ofile = src_path + '/' + row1[0] + '.c'
    fw_r = open(ofile,'w')

    if '_batchf' in row1[0] :
      routine_part1(fw_r)
      fw_r.write('#include "batched_blas.h"\n')
      routine_part2(fw_r,row1,row2)
      routine_fixed(fw_r,row1,row2)

    else :
      routine_part1(fw_r)
      routine_part2(fw_r,row1,row2)
      routine_part3(fw_r)
      routine_part3_1(fw_r,row1,row2)
      routine_part4(fw_r,row3)
      routine_part5(fw_r,row3)
      routine_part6(fw_r,row1,row2)
      routine_part7(fw_r)

    fw_r.close()
    routne_cblas_param(ofile)
    # make header file
    header_part2(fw_h,row1,row2)
    # make make file
    make_part2(fw_mk,row1[0])
  
  mode = (mode + 1) % 3
  
make_part3(fw_mk)
fw_mk.close()

header_part3(fw_h)
fw_h.close()

fr.close()

copy_files()

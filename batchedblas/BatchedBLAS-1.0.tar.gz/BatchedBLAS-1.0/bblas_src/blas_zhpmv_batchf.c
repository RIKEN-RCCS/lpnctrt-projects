#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_zhpmv_batchf(const int group_size,const bblas_enum_t layout,const bblas_enum_t uplo,const int n,const bblas_complex64_t  alpha,const bblas_complex64_t ** ap,const bblas_complex64_t ** x,const int incx,const bblas_complex64_t  beta,bblas_complex64_t ** y,const int incy,int *info)
{
  int group_count=1;
  blas_zhpmv_batch(group_count,&group_size,layout,&uplo,&n,&alpha,ap,x,&incx,&beta,y,&incy,info); 
}

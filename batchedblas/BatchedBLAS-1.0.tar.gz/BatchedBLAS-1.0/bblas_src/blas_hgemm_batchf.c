#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_hgemm_batchf(const int group_size,const bblas_enum_t layout,const bblas_enum_t transa,const bblas_enum_t transb,const int m,const int n,const int k,const fp16 alpha,const fp16 ** a,const int lda,const fp16 ** b,const int ldb,const fp16 beta,fp16 ** c,const int ldc,int *info)
{
  int group_count=1;
  blas_hgemm_batch(group_count,&group_size,layout,&transa,&transb,&m,&n,&k,&alpha,a,&lda,b,&ldb,&beta,c,&ldc,info); 
}

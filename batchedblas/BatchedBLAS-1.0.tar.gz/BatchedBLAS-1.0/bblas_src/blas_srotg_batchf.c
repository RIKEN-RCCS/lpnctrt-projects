#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_srotg_batchf(const int group_size,float ** a,float ** b,float ** c,float ** s,int *info)
{
  int group_count=1;
  blas_srotg_batch(group_count,&group_size,a,b,c,s,info); 
}

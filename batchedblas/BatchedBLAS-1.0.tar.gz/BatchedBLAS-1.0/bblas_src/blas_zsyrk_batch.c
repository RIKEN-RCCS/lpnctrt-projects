#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

void blas_zsyrk_batch(const int group_count,const int *group_size,const bblas_enum_t layout,const bblas_enum_t* uplo,const bblas_enum_t* trans,const int* n,const int* k,const bblas_complex64_t * alpha,const bblas_complex64_t ** a,const int* lda,const bblas_complex64_t * beta,bblas_complex64_t ** c,const int* ldc,int *info)
{
  int total_batch_count;
  int *which_thread;
  const int num_threads = omp_get_max_threads();
  int local_no, group_no;
  int my_tno;
  int group_head[group_count];
  struct _cost_param cost_param;

  if (group_count < 0) {
    bblas_error("Illegal value of group_count");
    info[0] = -1;
    return;
  }
  int offset = 0;
  int info_offset = 0;
  int info_option = info[0];
  int flag = 0;

  total_batch_count = 0;
  for (group_no = 0; group_no < group_count; group_no++) {
    total_batch_count += group_size[group_no];
  }

  group_head[0] = 0;
  for(group_no = 1; group_no < group_count; group_no++){
    group_head[group_no] = group_head[group_no - 1] + group_size[group_no - 1];
  }

  if(!use_batch()){
    for (group_no = 0; group_no < group_count; group_no++){

      int info_local;
      if (info_option == BblasErrorsReportAll) 
        info_offset = offset+1;
      else if (info_option == BblasErrorsReportGroup)
        info_offset = group_no+1;
      else
        info_offset = 0;
      info_local = info_option;
      if (group_size[group_no] < 0) {
        { 
        bblas_error("Illegal values of group_sizes");
        info[0] = -2;
        } 
        return;
      }
      if ((layout != BblasRowMajor) &&
          (layout != BblasColMajor)) {
          bblas_error("Illegal value of layout");
          if (info[info_offset] != BblasErrorsReportNone) {
            bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 1);
          }
        return;
      }
      if (n[group_no] < 0) {
	bblas_error("Illegal value of n");
	if (info[info_offset] != BblasErrorsReportNone) {
	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 5);
	}
	return;
      }
      if (k[group_no] < 0) {
	bblas_error("Illegal value of k");
	if (info[info_offset] != BblasErrorsReportNone) {
	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 6);
	}
	return;
      }
      if (lda[group_no] < imax(1, lda[group_no])) {
	bblas_error("Illegal value of lda");
	if (info[info_offset] != BblasErrorsReportNone) {
	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 7);
	}
	return;
      }

      for (local_no = 0; local_no < group_size[group_no]; local_no++){
        zl_cblas_zsyrk(layout_cblas( layout ) ,uplo_cblas( uplo[group_no] ) ,transpose_cblas( trans[group_no] ) ,n[group_no],k[group_no],(double *)alpha+2*group_no,a[group_head[group_no]+local_no],lda[group_no],(double *)beta+2*group_no,c[group_head[group_no]+local_no],ldc[group_no]);
        if (info_local == BblasErrorsReportAll)
          info[local_no+info_offset] = 0;
      }
      if (info_local != BblasErrorsReportAll)
        info_local = 0;
      if (info_local != 0 && flag == 0) {
        info[0] = info[info_offset];
        flag = 1;
      }
      offset += group_size[group_no];
    }
    return;
  }

  cost_param.ptr[0] = (void *)n;
  cost_param.ptr[1] = (void *)n;
  cost_param.ptr[2] = (void *)k;


  which_thread = (int *) malloc(sizeof(int) * total_batch_count);
  schedule_batch(group_count, group_size,get_cost_n3,&cost_param, which_thread);

#pragma omp parallel default(shared) num_threads(num_threads)	\
  private(group_no, local_no, my_tno) firstprivate(flag, offset, info_offset) 
  {
  my_tno = omp_get_thread_num();
  for (group_no = 0; group_no < group_count; group_no++){

      int info_local;
      if (info_option == BblasErrorsReportAll) 
        info_offset = offset+1;
      else if (info_option == BblasErrorsReportGroup)
        info_offset = group_no+1;
      else
        info_offset = 0;
      info_local = info_option;
      if (group_size[group_no] < 0) {
        #pragma omp master 
        { 
        bblas_error("Illegal values of group_sizes");
        info[0] = -2;
        } 
        break;
      }
      if ((layout != BblasRowMajor) &&
          (layout != BblasColMajor)) {
          #pragma omp master 
          { 
          bblas_error("Illegal value of layout");
          if (info_local != BblasErrorsReportNone) {
            bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 1);
          }
          }
        break;
      }
      if (n[group_no] < 0) {
        #pragma omp master 
        { 
	bblas_error("Illegal value of n");
	if (info_local != BblasErrorsReportNone) {
	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 5);
	}
        }
	break;
      }
      if (k[group_no] < 0) {
        #pragma omp master 
        { 
	bblas_error("Illegal value of k");
	if (info_local != BblasErrorsReportNone) {
	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 6);
	}
        }
	break;
      }
      if (lda[group_no] < imax(1, lda[group_no])) {
        #pragma omp master 
        { 
	bblas_error("Illegal value of lda");
	if (info_local != BblasErrorsReportNone) {
	  bblas_set_info(info[info_offset], &info[info_offset], group_size[group_no], 7);
	}
        }
	break;
      }

    for (local_no = 0; local_no < group_size[group_no]; local_no++){
      if(which_thread[group_head[group_no]+local_no] == my_tno){
        zl_cblas_zsyrk(layout_cblas( layout ) ,uplo_cblas( uplo[group_no] ) ,transpose_cblas( trans[group_no] ) ,n[group_no],k[group_no],(double *)alpha+2*group_no,a[group_head[group_no]+local_no],lda[group_no],(double *)beta+2*group_no,c[group_head[group_no]+local_no],ldc[group_no]);
        if (info_local == BblasErrorsReportAll)
          info[local_no+info_offset] = 0;
      }
    }
      if (info_local != BblasErrorsReportAll)
        info_local = 0;
      if (info_local != 0 && flag == 0) {
        #pragma omp critical 
        { 
        info[0] = info[info_offset];
        } 
        flag = 1;
      }
  }
      offset += group_size[group_no];
  }

  free(which_thread);

  return;
}


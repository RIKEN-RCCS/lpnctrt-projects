#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_ccopy_batchf(const int group_size,const int n,const bblas_complex32_t ** x,const int incx,bblas_complex32_t ** y,const int incy,int *info)
{
  int group_count=1;
  blas_ccopy_batch(group_count,&group_size,&n,x,&incx,y,&incy,info); 
}

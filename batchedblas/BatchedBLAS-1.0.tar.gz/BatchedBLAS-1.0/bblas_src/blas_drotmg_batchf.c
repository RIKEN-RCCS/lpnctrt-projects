#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_drotmg_batchf(const int group_size,double ** d1,double ** d2,double ** x1,const double* y1,double ** param,int *info)
{
  int group_count=1;
  blas_drotmg_batch(group_count,&group_size,d1,d2,x1,y1,param,info); 
}

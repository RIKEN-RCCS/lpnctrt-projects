#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_srotmg_batchf(const int group_size,float ** d1,float ** d2,float ** x1,const float* y1,float ** param,int *info)
{
  int group_count=1;
  blas_srotmg_batch(group_count,&group_size,d1,d2,x1,y1,param,info); 
}

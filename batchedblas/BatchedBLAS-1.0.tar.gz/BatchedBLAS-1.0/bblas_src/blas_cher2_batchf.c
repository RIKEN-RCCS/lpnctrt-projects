#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_cher2_batchf(const int group_size,const bblas_enum_t layout,const bblas_enum_t uplo,const int n,const bblas_complex32_t  alpha,const bblas_complex32_t ** x,const int incx,const bblas_complex32_t ** y,const int incy,bblas_complex32_t ** a,const int lda,int *info)
{
  int group_count=1;
  blas_cher2_batch(group_count,&group_size,layout,&uplo,&n,&alpha,x,&incx,y,&incy,a,&lda,info); 
}

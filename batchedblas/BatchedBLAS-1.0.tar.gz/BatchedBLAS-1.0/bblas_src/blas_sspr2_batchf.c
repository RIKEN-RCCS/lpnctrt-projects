#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_sspr2_batchf(const int group_size,const bblas_enum_t layout,const bblas_enum_t uplo,const int n,const float alpha,const float ** x,const int incx,const float ** y,const int incy,float ** ap,int *info)
{
  int group_count=1;
  blas_sspr2_batch(group_count,&group_size,layout,&uplo,&n,&alpha,x,&incx,y,&incy,ap,info); 
}

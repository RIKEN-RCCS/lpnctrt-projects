#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_hger_batchf(const int group_size,const bblas_enum_t layout,const int m,const int n,const fp16 alpha,const fp16 ** x,const int incx,const fp16 ** y,const int incy,fp16 ** a,const int lda,int *info)
{
  int group_count=1;
  blas_hger_batch(group_count,&group_size,layout,&m,&n,&alpha,x,&incx,y,&incy,a,&lda,info); 
}

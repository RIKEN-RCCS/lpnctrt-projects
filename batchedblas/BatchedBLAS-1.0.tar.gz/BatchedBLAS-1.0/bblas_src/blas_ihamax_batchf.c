#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_ihamax_batchf(const int group_size,const int n,const fp16 ** x,const int incx,int* ret_ss_fjcblas_amax_i32_r16,int *info)
{
  int group_count=1;
  blas_ihamax_batch(group_count,&group_size,&n,x,&incx,ret_ss_fjcblas_amax_i32_r16,info); 
}

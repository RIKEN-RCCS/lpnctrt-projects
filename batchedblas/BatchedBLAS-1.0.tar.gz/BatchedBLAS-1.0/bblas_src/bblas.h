#ifndef BBLAS_H
#define BBLAS_H

#include "batched_blas.h"
#include "bblas_error.h"

#endif        // BBLAS_H

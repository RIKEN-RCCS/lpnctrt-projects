#include <stdlib.h>
#include <omp.h>

#include "batched_blas_common.h"
#include "batched_blas_fp16.h"
#include "batched_blas_cost.h"
#include "batched_blas_schedule.h"
#include "bblas_error.h"

#include "batched_blas.h"
void blas_dscal_batchf(const int group_size,const int n,const double a1,double ** x,const int incx,int *info)
{
  int group_count=1;
  blas_dscal_batch(group_count,&group_size,&n,&a1,x,&incx,info); 
}

Batched BLAS implementation


* Tested platforms
For Fugaku and its compatible systems: Fujitsu cross-compiler + SSL-II.
Intel x86 based system: icc + MKL, and GCC + {OpenBLAS, ATLAS}.


* Compilation
For Fugaku and compatible systems, run
```
./make_fugaku.sh
```
Other x86 based systems with icc or GNU compiers: Setup
the environment variable CC = { icc, gcc }, then run
```
./make_others.sh
```
Or set a specific 'icc' compiler, do as follows
```
CC=icc ./make_others.sh
```


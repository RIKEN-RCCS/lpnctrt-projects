#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "bblas.h"
#include "batched_blas_test_common.h"

#define typ double

double getTime(){
  struct timeval t;
  gettimeofday(&t,NULL);
  return t.tv_sec + (double) t.tv_usec*1e-6;
}


int main(int argc, char *argv[])
{
  int i,j,l;
  int nsize,gsize,group_count,*group_size,*group_head;
  bblas_enum_t layout;
  bblas_enum_t *trans;
  bblas_enum_t *uplo;
  bblas_enum_t *diag;
  int *n,*lda;
  int *incx;
  typ **a;
  typ **x,**x_temp;
  double ts,te;
  double error,max_error;
  int try_number;
  int total_batch_count;
  int max_nsize;
  int a_size,x_size;
  int i_try;
  typ abs_val;
  
  if(argc < 5){
    printf("usage : ./(load module) <try_number> <group_count> <group_size (random base) > <n (random base)>\n");
    exit(1);
  }

  try_number = atoi(argv[1]);
  group_count = atoi(argv[2]);
  gsize = atoi(argv[3]);
  nsize = atoi(argv[4]);
  
  printf("name= %s, try_number= %d, group_count= %d, group_size= %d, nsize= %d\n", argv[0], try_number, group_count, gsize, nsize);

  srand48(123L);

  group_size = (int *)malloc(sizeof(int) * group_count);
  group_head = (int *)malloc(sizeof(int) * group_count);
  trans = (bblas_enum_t *)malloc(sizeof(bblas_enum_t) * group_count);
  uplo = (bblas_enum_t *)malloc(sizeof(bblas_enum_t) * group_count);
  diag = (bblas_enum_t *)malloc(sizeof(bblas_enum_t) * group_count);
  n = (int *)malloc(sizeof(int) * group_count);
  lda = (int *)malloc(sizeof(int) * group_count);
  incx = (int *)malloc(sizeof(int) * group_count);

  for(i_try = 0; i_try < try_number; i_try++){
    // set group size
    total_batch_count = 0;
    for(i = 0; i < group_count; i++){
      group_size[i] = random_int((int)((1.0-VAL_RANGE)*gsize),gsize);
      total_batch_count += group_size[i];
    }
    // set group head
    group_head[0] = 0;
    for(i = 1; i < group_count; i++){
      group_head[i] = group_head[i - 1] + group_size[i - 1];
    }

    a = (typ **)malloc(sizeof(typ *) * total_batch_count);
    x = (typ **)malloc(sizeof(typ *) * total_batch_count);
    x_temp = (typ **)malloc(sizeof(typ *) * total_batch_count);

    // set parameter and value
    layout = r_layout_();
    for(i = 0; i < group_count; i++){
      trans[i] = r_transpose_();
      uplo[i] = r_uplo_();
      diag[i] = r_diag_();
      n[i] = random_int((int)((1.0-VAL_RANGE)*nsize),nsize);
      max_nsize = n[i];
      lda[i] = random_int(max_nsize, (int)(max_nsize*(1.0+VAL_RANGE)));
      incx[i] = random_int(1, MAX_INC);
      for(j = 0; j < group_size[i]; j++){
        a_size = lda[i] * n[i];
        x_size = (1+(n[i]-1)*incx[i]);
        a[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * a_size);
        x[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * x_size);
        x_temp[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * x_size);
        for(l = 0; l < 2 * a_size; l++){
          a[group_head[i]+j][l] = drand48();
        }
        for(l = 0; l < 2 * x_size; l++){
          x[group_head[i]+j][l] = x_temp[group_head[i]+j][l] = drand48();
        }
      }
    }

    //Set info
    int info_option =  BblasErrorsReportNone;
    if( 5 < argc ){
      int info_no = atoi(argv[5]);
      switch (info_no) {
      case 1 :
	info_option =  BblasErrorsReportAll;
	break;
      case 2 :
	info_option =  BblasErrorsReportGroup;
	break;
      case 3 :
	info_option =  BblasErrorsReportNone;
	break;
      default:
	info_option =  BblasErrorsReportNone;
	break;	
      }
    }

    int info_size;
    switch (info_option) {
    case BblasErrorsReportAll :
      info_size = total_batch_count +1;
      break;
    case BblasErrorsReportGroup :
      info_size = group_count +1;
      break;
    case BblasErrorsReportAny :
      info_size   = 1;
      info_option = BblasErrorsReportNone;
      break;
    case BblasErrorsReportNone :
      info_size = 1;
      break;
    default :
      info_size   = 1;
      info_option = BblasErrorsReportNone;
      break;
    }

    int *info = (int*) malloc((size_t)info_size*sizeof(int))  ;
    info[0] = info_option;

    // batched
    ts = getTime();
    blas_ztrsv_batch(group_count, group_size, layout, uplo, trans, diag, n, (const bblas_complex64_t **)a, lda, (bblas_complex64_t **)x, incx, info);
    te = getTime();
    printf("batched= %e [s],", te - ts);
    free(info);
  
    // serial
    ts = getTime();
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        cblas_ztrsv(layout_cblas( layout ) , uplo_cblas( uplo[i] ) , transpose_cblas( trans[i] ) , diag_cblas( diag[i] ) , n[i], a[group_head[i]+j], lda[i], x_temp[group_head[i]+j], incx[i]); 
      }
    }
    te = getTime();
    printf("serial= %e [s],", te - ts);

    // check
    max_error = 0.0;
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        x_size = (1+(n[i]-1)*incx[i]);
        for(l = 0; l < x_size; l++){
          abs_val = sqrt(SQR(x_temp[group_head[i]+j][2*l])
                       +SQR(x_temp[group_head[i]+j][2*l+1]))
	    +sqrt(SQR(x[group_head[i]+j][2*l])
		  +SQR(x[group_head[i]+j][2*l+1]));
	  abs_val /= 2.0;
          error = sqrt(SQR(x_temp[group_head[i]+j][2*l]-x[group_head[i]+j][2*l])
                       +SQR(x_temp[group_head[i]+j][2*l+1]-x[group_head[i]+j][2*l+1]));
	  if(abs_val != 0.0)
	    error /= abs_val;
          if(max_error < error)
            max_error = error;
        }
      }
    }
    printf("max_error(diff/abs_val)= %e\n", max_error);
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        free(a[group_head[i]+j]);
        free(x[group_head[i]+j]);
        free(x_temp[group_head[i]+j]);
      }
    }
    free(a);
    free(x);
    free(x_temp);
  }
  free(group_size);
  free(group_head);
  free(trans);
  free(uplo);
  free(diag);
  free(n);
  free(lda);
  free(incx);
  
}



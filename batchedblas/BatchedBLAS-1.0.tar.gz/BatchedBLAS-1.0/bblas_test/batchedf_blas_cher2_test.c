#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "bblas.h"
#include "batched_blas_test_common.h"

#define typ float

double getTime(){
  struct timeval t;
  gettimeofday(&t,NULL);
  return t.tv_sec + (double) t.tv_usec*1e-6;
}


int main(int argc, char *argv[])
{
  int i,j,l;
  int nsize,gsize,group_count,*group_size,*group_head;
  bblas_enum_t layout;
  bblas_enum_t *uplo;
  int *n,*lda;
  int *incx,*incy;
  typ *alpha;
  typ **x,**y;
  typ **a,**a_temp;
  double ts,te;
  double error,max_error;
  int try_number;
  int total_batch_count;
  int max_nsize;
  int a_size,x_size,y_size;
  int i_try;
  
  if(argc < 4){
    printf("usage : ./(load module) <try_number>  <group_size (random base) > <n (random base)>\n");
    exit(1);
  }

  try_number = atoi(argv[1]);
  group_count = 1;
  gsize = atoi(argv[2]);
  nsize = atoi(argv[3]);
  
  printf("name= %s, try_number= %d, group_count= %d, group_size= %d, nsize= %d\n", argv[0], try_number, group_count, gsize, nsize);

  srand48(123L);

  group_size = (int *)malloc(sizeof(int) * group_count);
  group_head = (int *)malloc(sizeof(int) * group_count);
  uplo = (bblas_enum_t *)malloc(sizeof(bblas_enum_t) * group_count);
  n = (int *)malloc(sizeof(int) * group_count);
  lda = (int *)malloc(sizeof(int) * group_count);
  incx = (int *)malloc(sizeof(int) * group_count);
  incy = (int *)malloc(sizeof(int) * group_count);
  alpha = (typ *)malloc(sizeof(typ) * 2 * group_count);


  for(i_try = 0; i_try < try_number; i_try++){
    // set group size
    total_batch_count = 0;
    for(i = 0; i < group_count; i++){
      group_size[i] = random_int((int)((1.0-VAL_RANGE)*gsize),gsize);
      total_batch_count += group_size[i];
    }
    // set group head
    group_head[0] = 0;
    for(i = 1; i < group_count; i++){
      group_head[i] = group_head[i - 1] + group_size[i - 1];
    }

    x = (typ **)malloc(sizeof(typ *) * total_batch_count);
    y = (typ **)malloc(sizeof(typ *) * total_batch_count);
    a = (typ **)malloc(sizeof(typ *) * total_batch_count);
    a_temp = (typ **)malloc(sizeof(typ *) * total_batch_count);

    // set parameter and value
    layout = r_layout_();
    for(i = 0; i < group_count; i++){
      uplo[i] = r_uplo_();
      n[i] = random_int((int)((1.0-VAL_RANGE)*nsize),nsize);
      max_nsize = n[i];
      lda[i] = random_int(max_nsize, (int)(max_nsize*(1.0+VAL_RANGE)));
      incx[i] = random_int(1, MAX_INC);
      incy[i] = random_int(1, MAX_INC);
      alpha[2*i] = drand48();
      alpha[2*i+1] = drand48();
      for(j = 0; j < group_size[i]; j++){
        a_size = lda[i] * n[i];
        x_size = (1+(n[i]-1)*incx[i]);
        y_size = (1+(n[i]-1)*incy[i]);
        x[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * x_size);
        y[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * y_size);
        a[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * a_size);
        a_temp[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * a_size);
        for(l = 0; l < 2 * x_size; l++){
          x[group_head[i]+j][l] = drand48();
        }
        for(l = 0; l < 2 * y_size; l++){
          y[group_head[i]+j][l] = drand48();
        }
        for(l = 0; l < 2 * a_size; l++){
          a_temp[group_head[i]+j][l] = a[group_head[i]+j][l] = drand48();
        }
      }
    }

    //Set info
    int info_option =  BblasErrorsReportNone;
    if( 5 < argc ){
      int info_no = atoi(argv[4]);
      switch (info_no) {
      case 1 :
	info_option =  BblasErrorsReportAll;
	break;
      case 2 :
	info_option =  BblasErrorsReportGroup;
	break;
      case 3 :
	info_option =  BblasErrorsReportNone;
	break;
      default:
	info_option =  BblasErrorsReportNone;
	break;	
      }
    }

    int info_size;
    switch (info_option) {
    case BblasErrorsReportAll :
      info_size = total_batch_count +1;
      break;
    case BblasErrorsReportGroup :
      info_size = group_count +1;
      break;
    case BblasErrorsReportAny :
      info_size   = 1;
      info_option = BblasErrorsReportNone;
      break;
    case BblasErrorsReportNone :
      info_size = 1;
      break;
    default :
      info_size   = 1;
      info_option = BblasErrorsReportNone;
      break;
    }

    int *info = (int*) malloc((size_t)info_size*sizeof(int))  ;
    info[0] = info_option;

    bblas_complex32_t *alpha1 = (bblas_complex32_t *) alpha;
    // batched
    ts = getTime();
    blas_cher2_batchf(group_size[0],layout,*uplo,*n,*alpha1,(const bblas_complex32_t **)x,*incx,(const bblas_complex32_t **)y,*incy,(bblas_complex32_t **)a,*lda,info);
    te = getTime();
    printf("batched= %e [s],", te - ts);
    free(info);
  
    // serial
    ts = getTime();
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        cblas_cher2(layout_cblas( layout ) , uplo_cblas( uplo[i] ) , n[i], alpha+i*2, x[group_head[i]+j], incx[i], y[group_head[i]+j], incy[i], a_temp[group_head[i]+j], lda[i]); 
      }
    }
    te = getTime();
    printf("serial= %e [s],", te - ts);

    // check
    max_error = 0.0;
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        a_size = lda[i] * n[i];
        for(l = 0; l < a_size; l++){
          error = sqrt(SQR(a_temp[group_head[i]+j][2*l]-a[group_head[i]+j][2*l])
                       +SQR(a_temp[group_head[i]+j][2*l+1]-a[group_head[i]+j][2*l+1]));
          if(max_error < error)
            max_error = error;
        }
      }
    }
    printf("max_error= %e\n", max_error);
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        free(x[group_head[i]+j]);
        free(y[group_head[i]+j]);
        free(a[group_head[i]+j]);
        free(a_temp[group_head[i]+j]);
      }
    }
    free(x);
    free(y);
    free(a);
    free(a_temp);
  }
  free(group_size);
  free(group_head);
  free(uplo);
  free(n);
  free(lda);
  free(incx);
  free(incy);
  free(alpha);
  
}



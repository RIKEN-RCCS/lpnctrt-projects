#ifndef BATCHED_BLAS_TEST_COMMON_H
#define BATCHED_BLAS_TEST_COMMON_H

#include <stdlib.h>
#include "batched_blas.h"

// 0.0 <= xxx <= 1.0
#define VAL_RANGE (5.0e-1)
// 0.0 <= xxx <= 1.0
#define MAX_INC 5

#define MAX_2(a,b) ((a) > (b) ? (a) : (b))
#define MIN_2(a,b) ((a) < (b) ? (a) : (b))
#define SQR(a) ((a) * (a))

int random_int(int l_num, int u_num);

// get parameter from character
bblas_enum_t layout_(char l);
bblas_enum_t transpose_(char t);
bblas_enum_t uplo_(char u);
bblas_enum_t diag_(char d);
bblas_enum_t side_(char s);

// CBLAS_TRANSPOSE : N or T or C
bblas_enum_t r_layout_();
bblas_enum_t r_transpose_();
bblas_enum_t r_transpose_t_();
bblas_enum_t r_transpose_c_();
bblas_enum_t r_uplo_();
bblas_enum_t r_diag_();
bblas_enum_t r_side_();

#endif

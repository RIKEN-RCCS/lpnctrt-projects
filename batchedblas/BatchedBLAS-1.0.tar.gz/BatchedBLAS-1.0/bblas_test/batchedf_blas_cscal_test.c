#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "bblas.h"
#include "batched_blas_test_common.h"

#define typ float

double getTime(){
  struct timeval t;
  gettimeofday(&t,NULL);
  return t.tv_sec + (double) t.tv_usec*1e-6;
}


int main(int argc, char *argv[])
{
  int i,j,l;
  int nsize,gsize,group_count,*group_size,*group_head;
  int *n;
  int *incx;
  typ **x;
  typ **x_temp;
  typ *a;
  double ts,te;
  double error,max_error;
  int try_number;
  int total_batch_count;
  int max_nsize;
  int x_size;
  int i_try;
  
  if(argc < 4){
    printf("usage : ./(load module) <try_number>  <group_size (random base) > <n (random base)>\n");
    exit(1);
  }

  try_number = atoi(argv[1]);
  group_count = 1;
  gsize = atoi(argv[2]);
  nsize = atoi(argv[3]);
  
  printf("name= %s, try_number= %d, group_count= %d, group_size= %d, nsize= %d\n", argv[0], try_number, group_count, gsize, nsize);

  srand48(123L);

  group_size = (int *)malloc(sizeof(int) * group_count);
  group_head = (int *)malloc(sizeof(int) * group_count);
  a = (typ *)malloc(sizeof(typ) * 2 * group_count);
  n = (int *)malloc(sizeof(int) * group_count);
  incx = (int *)malloc(sizeof(int) * group_count);
  
  for(i_try = 0; i_try < try_number; i_try++){
    // set group size
    total_batch_count = 0;
    for(i = 0; i < group_count; i++){
      group_size[i] = random_int((int)((1.0-VAL_RANGE)*gsize),gsize);
      total_batch_count += group_size[i];
    }
    // set group head
    group_head[0] = 0;
    for(i = 1; i < group_count; i++){
      group_head[i] = group_head[i - 1] + group_size[i - 1];
    }
  
    x = (typ **)malloc(sizeof(typ *) * total_batch_count);
    x_temp = (typ **)malloc(sizeof(typ *) * total_batch_count);
    
    for(i = 0; i < group_count; i++){
      n[i] = random_int((int)((1.0-VAL_RANGE)*nsize),nsize);
      incx[i] = random_int(1, MAX_INC);
      a[2*i] = drand48();
      a[2*i+1] = drand48();
      for(j = 0; j < group_size[i]; j++){
        x_size = (1+(n[i]-1)*incx[i]);
        x[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * x_size);
        x_temp[group_head[i]+j] = (typ *)malloc(sizeof(typ) * 2 * x_size);
        for(l = 0; l < 2 * x_size; l++){
          x[group_head[i]+j][l] = x_temp[group_head[i]+j][l] = drand48();
        }
      }
    }

    //Set info
    int info_option =  BblasErrorsReportNone;
    if( 5 < argc ){
      int info_no = atoi(argv[4]);
      switch (info_no) {
      case 1 :
	info_option =  BblasErrorsReportAll;
	break;
      case 2 :
	info_option =  BblasErrorsReportGroup;
	break;
      case 3 :
	info_option =  BblasErrorsReportNone;
	break;
      default:
	info_option =  BblasErrorsReportNone;
	break;	
      }
    }

    int info_size;
    switch (info_option) {
    case BblasErrorsReportAll :
      info_size = total_batch_count +1;
      break;
    case BblasErrorsReportGroup :
      info_size = group_count +1;
      break;
    case BblasErrorsReportAny :
      info_size   = 1;
      info_option = BblasErrorsReportNone;
      break;
    case BblasErrorsReportNone :
      info_size = 1;
      break;
    default :
      info_size   = 1;
      info_option = BblasErrorsReportNone;
      break;
    }

    int *info = (int*) malloc((size_t)info_size*sizeof(int))  ;
    info[0] = info_option;
    
    typ *a1=a;
    // batched
    ts = getTime();
    blas_cscal_batchf(*group_size,*n,(bblas_complex32_t *) a1,(bblas_complex32_t **)x,*incx,info);
    te = getTime();
    printf("batched= %e [s],", te - ts);
    free(info);
  
    // serial
    ts = getTime();
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        cblas_cscal(n[i], a + i*2, x_temp[group_head[i]+j], incx[i]);
      }
    }
    te = getTime();
    printf("serial= %e [s],", te - ts);

    max_error = 0.0;
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        x_size = (1+(n[i]-1)*incx[i]);
	for(l = 0; l < x_size; l++){
         error = sqrt(SQR(x_temp[group_head[i]+j][2*l]-x[group_head[i]+j][2*l])
                     + SQR(x_temp[group_head[i]+j][2*l+1]-x[group_head[i]+j][2*l+1]));
         if(max_error < error)
            max_error = error;
	}
      }
    }
    printf("max_error= %e\n", max_error);
    
    for(i = 0; i < group_count; i++){
      for(j = 0; j < group_size[i]; j++){
        free(x[group_head[i]+j]);
        free(x_temp[group_head[i]+j]);
      }
    }
    free(x);
    free(x_temp);
  }
  free(group_size);
  free(group_head);
  free(a);
  free(n);
  free(incx);
   
}

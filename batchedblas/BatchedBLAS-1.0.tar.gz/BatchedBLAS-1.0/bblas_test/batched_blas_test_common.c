#include "bblas.h"
#include "batched_blas_test_common.h"

// return random integer l_num <= xxx <= u_num
int random_int(int l_num, int u_num)
{
  return l_num + (lrand48() % (u_num - l_num + 1));
}

// BBLAS_LAYOUT : C or R
bblas_enum_t layout_(char l)
{
  if(l == 'r' || l == 'R')
    return BblasRowMajor;
  else
    return BblasColMajor;
}

bblas_enum_t r_layout_()
{
  double r_num = drand48();
  
  if(r_num > 0.5)
    return BblasRowMajor;
  else
    return BblasColMajor;
}

// bblas_enum_t : N or T or C
bblas_enum_t transpose_(char t)
{
  if(t == 't' || t == 'T')
    return BblasTrans;
  else if(t == 'c' || t == 'C')
    return BblasConjTrans;
  else  
    return BblasNoTrans;
}

bblas_enum_t r_transpose_()
{
  double r_num = drand48();
  
  if(r_num > 2.0 / 3.0)
    return BblasTrans;
  else if(r_num > 1.0 / 3.0)
    return BblasNoTrans;
  else
    return BblasConjTrans;
}

bblas_enum_t r_transpose_t_()
{
  double r_num = drand48();
  
  if(r_num > 0.5)
    return BblasTrans;
  else  
    return BblasNoTrans;
}

bblas_enum_t r_transpose_c_()
{
  double r_num = drand48();
  
  if(r_num > 0.5)
    return BblasConjTrans;
  else  
    return BblasNoTrans;
}

// bblas_enum_t : U or L
bblas_enum_t uplo_(char u)
{
  if(u == 'l' || u == 'L')
    return BblasLower;
  else  
    return BblasUpper;
}

bblas_enum_t r_uplo_()
{
  double r_num = drand48();
  
  if(r_num > 0.5)
    return BblasLower;
  else  
    return BblasUpper;
}

// U or N
bblas_enum_t diag_(char d)
{
  if(d == 'u' || d == 'U')
    return BblasUnit;
  else  
    return BblasNonUnit;
}

bblas_enum_t r_diag_()
{
  double r_num = drand48();
  
  if(r_num > 0.5)
    return BblasUnit;
  else  
    return BblasNonUnit;
}

// L or R
bblas_enum_t side_(char s)
{
  if(s == 'r' || s == 'R')
    return BblasRight;
  else  
    return BblasLeft;
}

bblas_enum_t r_side_()
{
  double r_num = drand48();
  
  if(r_num > 0.5)
    return BblasRight;
  else  
    return BblasLeft;
}


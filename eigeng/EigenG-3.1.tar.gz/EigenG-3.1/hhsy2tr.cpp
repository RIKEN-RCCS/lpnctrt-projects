#include <cuda.h>
#include <cuda_runtime.h>
#include <cublas.h>
#include <stdio.h>
#include <math.h>


cudaStream_t ASPEN_get_Stream( void );
void ASPEN_dsymv( char, int, double, double *, int, double *, int, double, double *, int);
void t2xx( const int i, double * dev_ux, const int ldu, double * beta, double * d_i, double * e_i, cudaStream_t stream );
void t2xxx( const int mdone, const int i, double * dev_ux, const int ldu, double * vb, const int ldv, double * beta, double * d_i, double * e_i, cudaStream_t stream );
void t6xx( const int i, double * beta, double * dev_ux, double * dev_vx, cudaStream_t stream );

size_t size1( int dim0 ) {
  return (size_t)dim0;
}
size_t size2( int dim0, int dim1 ) {
  return (size_t)dim0 * (size_t)dim1;
}

//--
int min(const int x, const int y) { return x<=y ? x : y; }
int max(const int x, const int y) { return x>=y ? x : y; }
//--


template < class T >
void
hhsy2tr (
  int const n_,
  T * const a_host,
  int const lda_,
  T * const d_host,
  T * const e_host,
  int const mb_,
  T * const ROOT_dev,
  const cudaStream_t stream
)
{
  int const n   = n_;
  int const lda = lda_;
  int const mb  = min(mb_, n - 1);

#define	A(i,j)	*( a_host + size1((i)-1) + size2((j)-1,lda) )
#define	D(i)	*( d_host + size1((i)-1) )
#define	E(i)	*( e_host + size1((i)-1) )

#define	a(i,j)	*( a_dev  + size1((i)-1) + size2((j)-1,lda) )
#define	d(i)	*( d_dev  + size1((i)-1) )
#define	e(i)	*( e_dev  + size1((i)-1) )
#define	uu(i,j)	*( uu_dev + size1((i)-1) + size2((j)-1,ldu) )
#define	vv(i,j)	*( vv_dev + size1((i)-1) + size2((j)-1,ldv) )
#define	u(i)	*( u_dev  + size1((i)-1) )
#define	v(i)	*( v_dev  + size1((i)-1) )
#define	ub(i)	*( ub_dev + size1((i)-1) )
#define	vb(i)	*( vb_dev + size1((i)-1) )
#define	s0(i)	*( s0_dev + size1((i)-1) )
#define	s1(i)	*( s1_dev + size1((i)-1) )

#define	GEMVN(...)	cublasDgemv_v2(handle, CUBLAS_OP_N, __VA_ARGS__)
#define	GEMVT(...)	cublasDgemv_v2(handle, CUBLAS_OP_T, __VA_ARGS__)
#define	SYMVU(...)	ASPEN_dsymv('U', __VA_ARGS__)
//#define	SYMVU(...)	cublasDsymv_v2(handle, CUBLAS_FILL_MODE_UPPER, __VA_ARGS__)
#define	SYR2KUN(...)	cublasDsyr2k_v2(handle, CUBLAS_FILL_MODE_UPPER, CUBLAS_OP_N, __VA_ARGS__)



  T const ONE  = (T)(1);
  T const ZERO = (T)(0);

  if (n <= 0) {
    return;
  }

  if (n == 1) {
    D(1) = A(1,1);
    E(1) = ZERO;
    return;
  }

  if (n == 2) {
    const T t = fabs(A(1,2));
    D(1) = A(1,1);
    D(2) = A(2,2);
    A(1,1) = ZERO;
    A(2,2) = -t;
    A(1,2) = 2*t;
    E(1) = ZERO;
    E(2) = -t;
    return;
  }

{
  T * a_dev  = ROOT_dev;
  T * d_dev  = a_dev  + size2(lda,n);
  T * e_dev  = d_dev  + size1(lda);
  T * vv_dev = e_dev  + size1(lda);
  T * beta   = vv_dev + size2(lda,mb);
  T * s0_dev = beta   + size1(4);
  T * s1_dev = s0_dev + size1(mb);
  T * uu_dev = NULL;

  cublasHandle_t handle;
  cublasCreate_v2( &handle );
  cublasSetAtomicsMode( handle, CUBLAS_ATOMICS_ALLOWED );

  cudaStream_t dpipe;
  cudaStreamCreate( &dpipe );
  cublasSetStream_v2( handle, stream );

  cudaMemcpyAsync( &a(1,1), &A(1,1), size2(n,lda)*sizeof(T), cudaMemcpyHostToDevice, stream );

  int const ib0 = (n - 1) / mb + 1;
  int const ib1 = max(1, 2 - mb);
  int cond_i = n;
  int nxx = 0;

  for(int ib=ib0; ib>=ib1; ib--) {

    //
    // Regular panel distribution [1:i1] x [i0+1,i1]
    //
    //   u(:,1:m0) => map on to a(:,i0+1:i1), i1=i0+m0
    //   v(:,1:m0) => map on to vv(:,1:m0), ldv=ceil(i0+mb,8)
    //
    //      0 1         i0    i1
    //        v         v     v
    //       +-----+-----+-----+
    //     1>|     |     |o o o|
    //       |     |     |o o o|
    //    i0>|     |     |o o o|
    //       +-----+-----+-----+
    //       |     |     |o o o|
    //       |     |     |  o o|
    //    i1>|     |     |    o|
    //       +-----+-----+-----+
    //

    int const i0 = (ib - 1) * mb;
    int const i1 = min(i0 + mb, n);

    int const m0 = i1 - i0;
    int const m1 = max(1, 2 * (2 - ib));

    int const ldu = lda;
    int const ldv = min(((i0 + mb - 1) / 8 + 1) * 8, lda);

    uu_dev = &a(1, i0+1);

    int mdone = 0;
    for(int m=m0; m>=m1; m--, mdone++) {

      int const i = i0 + m;
      int const l = i - 1;

      T * const u_dev = &uu(1, m);
      T * const v_dev = &vv(1, m);

#define	USE_COMBINED_T2XX	(1)

      //
      // u = u + U V[i,:]^T + V U[i,:]^T
      //
#if !USE_COMBINED_T3XX
      if (mdone > 0) {
        T * const ub_dev = &uu(1,m+1);
        T * const vb_dev = &vv(1,m+1);
        GEMVN(i, mdone, &ONE, &ub(1), ldu, &vb(i), ldv, &ONE, &u(1), 1);
        GEMVN(i, mdone, &ONE, &vb(1), ldv, &ub(i), ldu, &ONE, &u(1), 1);
      }
#endif

      //
      // This source does not care the case of tiny norm
      // as LAPACK or other libraries do rescale by ONE/SAFEMIN
      // but scale vector u by ONE/uL is employed to avoid over/
      // under-flow
      //
      {
        T * const ub_dev = &uu(1,m+1);
        T * const vb_dev = &vv(1,m+1);
#if USE_COMBINED_T3XX
        t3xx( mdone, i, &u(1), ldu, &vb(1), ldv, beta, &d(i), &e(i), stream );
#else
        t2xx( i, &u(1), ldu, beta, &d(i), &e(i), stream );
#endif
      }

      T alpha = ZERO;
      if (mdone > 0) {
        //
        // v = (U V^T + V U^T) u
        //
	T * const ub_dev = &uu(1,m+1);
        T * const vb_dev = &vv(1,m+1);

        GEMVT(l, mdone, &ONE, &vb(1), ldv, &u(1),  1, &ZERO, &s0(1), 1);
        GEMVT(l, mdone, &ONE, &ub(1), ldu, &u(1),  1, &ZERO, &s1(1), 1);
        GEMVN(l, mdone, &ONE, &ub(1), ldu, &s0(1), 1, &ZERO, &v(1),  1);
        GEMVN(l, mdone, &ONE, &vb(1), ldv, &s1(1), 1, &ONE,  &v(1),  1);

        alpha = ONE;
      }

      //
      // v = A u + v
      //
      {

        SYMVU(l, ONE, &a(1,1), lda, &u(1), 1, alpha, &v(1), 1);
//        SYMVU(l, &ONE, &a(1,1), lda, &u(1), 1, &alpha, &v(1), 1);
      }

      //
      // v = v * beta
      // gamma = (u, v) * beta / 2
      // v = gamma * u + v
      //
      {
        t6xx( l, beta, &u(1), &v(1), stream );
      }

    }

    {
      int mx = i0+m1-1;
      int nx = m0-m1+1;

      nxx += nx;
//      const int DDX = 8000;
      const int DDX = 10000;
      if ( min( mx, nxx ) >= DDX ) {
        cudaStreamSynchronize( stream );
        cudaMemcpyAsync( &A(1,mx+1), &a(1,mx+1), size2(lda,nxx)*sizeof(T), cudaMemcpyDeviceToHost, dpipe );
	nxx = 0;
        cond_i = mx;
      }

      //
      // A = A + UV^t + VU^t
      //

      T * const u_dev = &uu(1, m1);
      T * const v_dev = &vv(1, m1);

      SYR2KUN(mx, nx, &ONE, &u(1), ldu, &v(1), ldv, &ONE, &a(1,1), lda);

    }

  }

  {
    cudaStreamSynchronize( stream );

    cudaMemcpyAsync( &A(1,1), &a(1,1), size2(cond_i,lda)*sizeof(T), cudaMemcpyDeviceToHost, dpipe );
    cudaMemcpyAsync( &D(2), &d(2), size1(n-1)*sizeof(T), cudaMemcpyDeviceToHost, dpipe );
    cudaMemcpyAsync( &E(2), &e(2), size1(n-1)*sizeof(T), cudaMemcpyDeviceToHost, dpipe );

    cudaStreamSynchronize( dpipe );

    D(1) =  A(1,1);
    E(1) =  ZERO;
  }

  cublasDestroy_v2( handle );
  cudaStreamDestroy( dpipe );
}

#undef	a
#undef	d
#undef	e
#undef	uu
#undef	vv
#undef	u
#undef	v
#undef	ub
#undef	vb
#undef	s0
#undef	s1

#undef	GEMVN
#undef	GEMVT
#undef	SYMVU
#undef	SYR2KUN
}

void
hhsy2tr_ (
  int    * n_,
  double * a_,
  int    * lda_,
  double * d_,
  double * e_,
  int    * mb_
)
{
  size_t len_a = size2(*lda_, *n_);
  size_t len_d = size1(*lda_);
  size_t len_e = size1(*lda_);
  size_t len_v = size2(*lda_, *mb_);
  size_t len_s = size2(*mb_, 2) + size1(4);
  size_t len = (len_a + len_d + len_e + len_v + len_s) * sizeof(double);
  double * ROOT_dev;

  const cudaStream_t stream = ASPEN_get_Stream();
  if ( *n_ >= 3 ) {
    cudaError_t err_code = cudaMallocAsync( (void *)&ROOT_dev, len, stream );
    if ( err_code != cudaSuccess ) {
      fprintf(stderr, "Memory allocation fault [HHSY2TR]\n");
      fflush(stderr);
      exit(1);
    }
  }

  hhsy2tr ( *n_, a_, *lda_, d_, e_, *mb_, ROOT_dev, stream );

  if ( *n_ >= 3 ) {
    cudaFreeAsync( ROOT_dev, stream );
  }
}


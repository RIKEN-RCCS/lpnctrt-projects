#include <cuda.h>
#include <cuda_runtime.h>
#include <cublas.h>
#include <stdio.h>
#include <math.h>

#include "hh_buffer.h"


long
hhsy2tr_buffersize_ (
  int    * n_,
  int    * lda_,
  int    * mb_
)
{
  size_t len;
  if ( *n_ >= 3 ) {
    size_t len_a = size2(*lda_, *n_);
    size_t len_d = size1(*lda_);
    size_t len_e = size1(*lda_);
    size_t len_v = size2(*lda_, *mb_);
    size_t len_beta = size1(1);
    size_t len_workspace = size2(*mb_, 2); // s0, s1
    size_t len_taskcntrl = size1(8); // task control variables

           len = (len_a + len_d + len_e + len_v + len_beta + len_workspace) * sizeof(double) + len_taskcntrl * sizeof(TB_control_t);
  } else {
           len = 0;
  }
  return (long)len;
}

long
dc_buffersize_ (
  int * n_,
  int * ldz_
)
{
  size_t len = (size2((*ldz_)/2+1, *n_) * 2
              + size2((*ldz_)/2+1, (*n_)/2+1)) * sizeof(T);
  return (long)len;
}

long
hhtr2sy_buffersize_ (
  int * n_,
  int * nv_,
  int * lda_,
  int * ldz_,
  int * mb_
)
{
  size_t len = (size2(*lda_, *mb_) * 2
              + size2(*ldz_, *nv_)
              + size2(*mb_,  *mb_)
              + size2(*nv_,  *mb_)) * sizeof(T);
  return (long)len;
}

long
eigen_buffersize_(
  int *n_,
  int *nvec_,
  int *lda_,
  int *ldz_,
  int *mf_,
  int *mb_
)
{
  const long b1 = hhsy2tr_buffersize_ (n_, lda_, mf_);
  const long b2 = dc_buffersize_ (n_, ldz_);
  const long b3 = hhtr2sy_buffersize_ (n_, nvec_, lda_, ldz_, mb_);

  const long z1 = (b1 >= b2 ? b1 : b2);
  const long z2 = (z1 >= b3 ? z1 : b3);

  return z2;
}


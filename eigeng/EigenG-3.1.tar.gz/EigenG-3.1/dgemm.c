#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#if defined(__GNUC__)
#include <stdint.h>
#endif /* __GNUC__ */
#include "cublas.h"   /* CUBLAS public header file  */

#define imin(a,b) (((a)<(b))?(a):(b))
#define imax(a,b) (((a)<(b))?(b):(a))

#include "fortran_common.h"
#include "fortran_thunking.h"

void dgemm_( const char *, ... );
void cuda_sync_( int * );

#define CUBLAS_WRAPPER_ERROR_NOERR      0
#define CUBLAS_WRAPPER_ERROR_ALLOC      1
#define CUBLAS_WRAPPER_ERROR_SET        2
#define CUBLAS_WRAPPER_ERROR_GET        3
#define CUBLAS_WRAPPER_ERROR_STUB       4

#include <omp.h>

static char *errMsg[5] = 
{
    "no error",
    "allocation error",
    "setVector/setMatrix error",
    "getVector/getMatrix error",
    "not implemented"
};

#if 0
//#define MIN_NKM         (1024)
//#define MIN_NKM         (256)
//128 > 112 , 96, ...
//#define MIN_NKM         (128)
//#define MIN_NKM         (112)
// 112 ~ 96
#define MIN_NKM         (96)
// 96 > 64
//#define MIN_NKM         (64)
//#define MIN_NKM         (64000)
#else
#define MAX_NKM         (96)
#define MIN_NKM         (16)
#endif

//
// CUDA_PTR__MANAGE is the common name declaired in trd.h
// 
struct cuda_ptr_manage {
   double *devPtr;
   long size;
   double *devPtr_1;
   double *devPtr_2;
   double *devPtr_3;
   double *devPtr_4;
};

extern struct cuda_ptr_manage cuda_ptr_manage_;

double *dev_PRE[3];


static void wrapperError (const char *funcName, int error)
{
    printf ("cublas%s wrapper: %s\n", funcName, errMsg[error]);
    fflush (stdout);
}

/*---------------------------------------------------------------------------*/
/*---------------------------------- BLAS3 ----------------------------------*/
/*---------------------------------------------------------------------------*/


double static log_dgemm_s_[3];

void dgemm_gpu_(const char *transa, const char *transb, const int *m,
                const int *n, const int *k, const double *alpha,
                const double *A, const int *lda, const double *B,
                const int *ldb, const double *beta, double *C,
                const int *ldc,
		void *devPtrA, void *devPtrB, void *devPtrC)
{

  cublasStatus stat1, stat2, stat3;
  int sizeOF = sizeof(double);

  { int i=2; cuda_sync_( &i ); }
#if 0
  double s2 = omp_get_wtime();
#endif

  stat1=cublasSetMatrix(imin(*m,*lda),*k,sizeOF,A,*lda,devPtrA,*lda);
  stat2=cublasSetMatrix(imin(*k,*ldb),*n,sizeOF,B,*ldb,devPtrB,*ldb);
  if ( (*beta) != 0.0 ) {
  stat3=cublasSetMatrix(imin(*m,*ldc),*n,sizeOF,C,*ldc,devPtrC,*ldc);
  } else {
  stat3 = CUBLAS_STATUS_SUCCESS;
  }
  if ((stat1 != CUBLAS_STATUS_SUCCESS) || 
      (stat2 != CUBLAS_STATUS_SUCCESS) ||
      (stat3 != CUBLAS_STATUS_SUCCESS)) {
    wrapperError ("Dgemm", CUBLAS_WRAPPER_ERROR_SET);
    return;
  }

#if 0
  { int i=1; cuda_sync_( &i ); }
  double e2 = omp_get_wtime();
  log_dgemm_s_[2] += (e2 - s2);

  double s1 = e2;
#endif

  cublasDgemm(transa[0], transb[0], *m, *n, *k, *alpha, devPtrA, *lda, 
              devPtrB, *ldb, *beta, devPtrC, *ldc);

#if 0
  { int i=1; cuda_sync_( &i ); }
  double e1 = omp_get_wtime();
  log_dgemm_s_[1] += (e1 - s1);

  s2 = omp_get_wtime();
#endif

  stat1=cublasGetMatrix(imin(*m,*ldc),*n,sizeOF,devPtrC,*ldc,C,*ldc);
  if (stat1 != CUBLAS_STATUS_SUCCESS) {
    wrapperError ("Dgemm", CUBLAS_WRAPPER_ERROR_GET);
  }

  { int i=1; cuda_sync_( &i ); }
#if 0
  e2 = omp_get_wtime();
  log_dgemm_s_[2] += (e2 - s2);
#endif

}

__inline__ int int_max( int x, int y ) {
  return (x >= y ? x : y);
}
__inline__ int int_min( int x, int y ) {
  return (x <= y ? x : y);
}

void xdgemm_ (const char *transa, const char *transb, const int *m,
                   const int *n, const int *k, const double *alpha,
                   const double *A, const int *lda, const double *B,
                   const int *ldb, const double *beta, double *C,
                   const int *ldc)
{
   if ( *transa == '0' ) {
      log_dgemm_s_[0] = 0.0;
      log_dgemm_s_[1] = 0.0;
      log_dgemm_s_[2] = 0.0;
      return;
   }

   if ( *transa == '1' ) {
      C[0] = log_dgemm_s_[0];
      C[1] = log_dgemm_s_[1];
      C[2] = log_dgemm_s_[2];
      return;
   }

   long size = (long)(*lda)*(long)(*k)
	   +(long)(*ldb)*(long)(*n)
	   +(long)(*ldc)*(long)(*n);

   double s0 = omp_get_wtime();
   int max_nkm = int_max(*n, int_max(*k, *m));
   int min_nkm = int_min(*n, int_min(*k, *m));

   if ( (*transa != 'N' && *transa != 'n') ||
        (*transb != 'N' && *transb != 'n') ||
//      (*n<MIN_NKM && *k<MIN_NKM && *m<MIN_NKM) ||
      (max_nkm < MAX_NKM) ||
      (min_nkm < MIN_NKM) ||
      (size>cuda_ptr_manage_.size) ) {

      dgemm_ (transa, transb, m, n, k,
              alpha, A, lda, B, ldb, beta, C, ldc);

   } else {

      double	*devPtr_A = cuda_ptr_manage_.devPtr;
      double	*devPtr_B = devPtr_A + (long)(*lda) * (long)(*k);
      double	*devPtr_C = devPtr_B + (long)(*ldb) * (long)(*n);

      dgemm_gpu_ (transa, transb, m, n, k,
                  alpha, A, lda, B, ldb, beta, C, ldc,
                  devPtr_A, devPtr_B, devPtr_C);

   }

   double e0 = omp_get_wtime();
   log_dgemm_s_[0] += (e0 - s0);
}


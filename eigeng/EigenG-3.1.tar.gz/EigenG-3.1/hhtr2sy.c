#include <cuda.h>
#include <cuda_runtime.h>
#include <cublas.h>
#include <stdio.h>
#include <malloc.h>
#include <math.h>

#include "hh_buffer.h"


void
hhtr2sy (
  int const n_,
  int const nv_,
  T * const a_host,
  int const lda_,
  T * const z_host,
  int const ldz_,
  int const mb_,
  T * const ROOT_dev,
  cudaStream_t const stream
)
{
  int const n   = n_;
  int const nv  = nv_;
  int const lda = lda_;
  int const ldz = ldz_;
  int const mb  = min(mb_, n-1);

  T const ONE  = (T)(1);
  T const MONE = (T)(-1);
  T const ZERO = (T)(0);

  T * const a_dev = (T*)ROOT_dev;
  T * const z_dev = a_dev + size2(lda,mb)*2;
  T * const G_dev = z_dev + size2(ldz,nv);
  T * const v_dev = G_dev + size2(mb,mb);

  T * const a_[2] = { a_dev, a_dev + size2(lda,mb) };
  int sw = 0;
  int const ldu = lda;

  cublasHandle_t handle = get_cublas_handler();

  cudaStream_t dpipe = get_extra_stream();

  cudaMemcpyAsync( z_dev, z_host, size2(nv,ldz)*sizeof(T),
                cudaMemcpyHostToDevice, stream );
  {
    size_t const offset = lda;
    int const mm = min(n, mb)-1;
    cudaMemcpyAsync( a_[sw], a_host+offset, size2(mm,lda)*sizeof(T),
                cudaMemcpyHostToDevice, dpipe );
  }

{
  int const ib0 = (mb > 1 ? 1 : 2);
  int const ib1 = (n - 1) / mb + 1;

  for(int ib=ib0; ib<=ib1; ib++) {

    int const i0 = max((ib - 1) * mb, 1);
    int const i1 = min(ib * mb, n);

    int const m    = i1 - i0;
    int const L    = i1 - 1;
    int const incx = m + 1;

    double * const u_dev = a_[sw];
    sw = 1 - sw;

    {
      zero_triangle_gpu( m, u_dev+i0, lda, dpipe );
      cudaStreamSynchronize( dpipe ); // guarantee Host2Dev + triangle

      if ( ib < ib1 ) {
        size_t const offset = size2(mb*ib,lda);
        int const mm = min(mb, n - mb*ib);
        cudaMemcpyAsync( a_[sw], a_host+offset, size2(mm,lda)*sizeof(T),
                        cudaMemcpyHostToDevice, dpipe );
      }
    }


#define TYPE_NT	(1)

#if TYPE_NT
    int const ldv = nv;
    cublasDgemm( 'T', 'N',
          nv, m, L, ONE, z_dev, ldz, u_dev, ldu, ZERO, v_dev, ldv );
#else
    int const ldv = m;
    cublasDgemm( 'T', 'N',
          m, nv, L, ONE, u_dev, ldu, z_dev, ldz, ZERO, v_dev, ldv );
#endif

    cublasDsyrk( 'L', 'T',
          m, L, MONE, u_dev, lda, ZERO, G_dev, m );
    mul_diag_gpu( m, G_dev, incx, stream );
    cublasDtrsm( 'R', 'L', 'N', 'N',
          L, m, ONE, G_dev, m, u_dev, ldu );

#if TYPE_NT
    cublasDgemm( 'N', 'T',
          L, nv, m, ONE, u_dev, ldu, v_dev, ldv, ONE, z_dev, ldz );
#else
    cublasDgemm( 'N', 'N',
          L, nv, m, ONE, u_dev, ldu, v_dev, ldv, ONE, z_dev, ldz );
#endif

  }
}

  cudaMemcpyAsync( z_host, z_dev, size2(nv,ldz)*sizeof(T),
                cudaMemcpyDeviceToHost, stream );
}


void
hhtr2sy_(
  int * n_,
  int * nv_,
  T   * a_,
  int * lda_,
  T   * z_,
  int * ldz_,
  int * mb_
)
{
  cudaStream_t const stream = ASPEN_get_Stream();

  void * ROOT_dev = NULL;
  if ( cuda_ptr_manage_.devPtr == NULL ) {
    size_t len = hhtr2sy_buffersize_ ( n_, nv_, lda_, ldz_, mb_ );
    cudaError_t err_code = cudaMallocAsync( (void *)&ROOT_dev, len, stream );
    if ( err_code != cudaSuccess ) {
      fprintf(stderr, "Memory allocation fault [HHTR2SY]\n");
      fflush(stderr);
      exit(1);
    }
  } else {
    ROOT_dev = (double *)cuda_ptr_manage_.devPtr;
  }

  hhtr2sy ( *n_, *nv_, a_, *lda_, z_, *ldz_, *mb_, ROOT_dev, stream );

  if ( cuda_ptr_manage_.devPtr == NULL ) {
    cudaFreeAsync( ROOT_dev, stream );
  }
}


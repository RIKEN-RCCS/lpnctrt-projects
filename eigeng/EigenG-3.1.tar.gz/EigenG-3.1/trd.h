       integer                :: TRD_inod,TRD_nnod,TRD_COMM_WORLD
       common /USEMPI/           TRD_inod,TRD_nnod,TRD_COMM_WORLD
!
       integer                :: x_inod, x_nnod, x_COMM_WORLD,
     &                           y_inod, y_nnod, y_COMM_WORLD,
     &                           z_inod, z_nnod, z_COMM_WORLD,
     &                           n_common, diag_0, diag_1
       integer, pointer       :: p0_(:),q0_(:)
       common /CYCL2D/           x_inod, x_nnod, x_COMM_WORLD,
     &                           y_inod, y_nnod, y_COMM_WORLD,
     &                           z_inod, z_nnod, z_COMM_WORLD,
     &                           n_common, diag_0, diag_1,
     &                           p0_      ,q0_
!
       external               :: loop_c
       integer, external      :: loop_c_start, loop_c_end
       integer, external      :: loop_c_node
       integer, external      :: loop_c_g2l_depth
       integer, external      :: loop_c_l2g_depth
       real(8), external      :: get_wtime

       integer, parameter :: nsx = 480
       integer, parameter :: nsm = 256 ! 64 +32
       integer, parameter :: ns0 = nsm * nsm + 6

!       integer, parameter :: MBAND = 2

       integer, external :: cuda_alloc
       integer, external :: cuda_alloc_available
       integer, external :: cublas_alloc
       integer, external :: cublas_set_matrix
       integer, external :: cublas_set_matrix_async
       integer, external :: cublas_get_matrix
       integer, external :: cublas_set_vector
       integer, external :: cublas_set_vector_async
       integer, external :: cublas_get_vector
!
       integer(8) :: devPtr_A, size_A
       integer(8) :: devPtr_UX, devPtr_UY, devPtr_VX, devPtr_VY
       common /CUDA_PTR_MANAGE/ devPtr_A, size_A,
     &            devPtr_UX, devPtr_UY, devPtr_VX, devPtr_VY

       integer(8), parameter :: eSize = 8

       real(8)    :: ttt6(8)
       common /t6check/ ttt6

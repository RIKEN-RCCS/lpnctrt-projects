#!/bin/sh
#PBS -l nodes=1:ppn=4

export CUDA_PATH=/usr/local/cuda
export LD_LIBRARY_PATH=$HOME/ASPEN.K2-1.8/lib:$LD_LIBRARY_PATH

export OMP_NUM_THREADS=8
export ASPEN_GPU_ID=0
export GPU_CPU_RATE="28 31"

awk 'BEGIN{ for(i=128;i<20000;i+=128){ print i" 48 6 0 0" } print "-1 48 6 0 0"; }' < /dev/null > IN-x
./a.out < IN-x | tee log-EigenG-GX1080-96-128_28:31

#./a.out < IN | tee log-EigenG-V100-trbak-full-GPU-96-128-large-Timer4

exit

awk '/ 64 /{ gsub(/ 64 /," 32 "); print}' < IN > IN-32
./a.out < IN-32 | tee log-EigenG-V100-trbak-full-GPU-fast4-32

./a.out < IN | tee log-EigenG-V100-trbak-full-GPU-fast4-64

awk '/ 64 /{ gsub(/ 64 /," 96 "); print}' < IN > IN-96
./a.out < IN-96 | tee log-EigenG-V100-trbak-full-GPU-fast4-96

awk '/ 64 /{ gsub(/ 64 /," 128 "); print}' < IN > IN-128
./a.out < IN-128 | tee log-EigenG-V100-trbak-full-GPU-fast4-128



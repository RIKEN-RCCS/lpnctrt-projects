#!/bin/sh

export ASPEN_GPU_ID=1

export OMP_NUM_THREADS=1
./a.out | tee log-GPU1-1threads

export OMP_NUM_THREADS=6
./a.out | tee log-GPU1-6threads

exit 1

awk 'BEGIN{ \
	system("cat /proc/cpuinfo"); \
	for(i=0;i<=32;i++){ \
		j=32-i; \
		G=i; C=j; \
		system("export OMP_NUM_THREADS=6; export GPU_CPU_RATE=\""G" "C"\"; ./a.out|tee logE-"G"-"C); \
	} \
	}'




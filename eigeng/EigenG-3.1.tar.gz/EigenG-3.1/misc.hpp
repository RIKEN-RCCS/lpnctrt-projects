int min(const int x, const int y) { return x <= y ? x : y; }
int max(const int x, const int y) { return x >= y ? x : y; }

float Abs(const float x) { return fabsf(x); }
double Abs(const double x) { return fabs(x); }

float Sign(const float x, const float y) { return y >= (float)0 ? x : -x; }
double Sign(const double x, const double y) { return y >= (double)0 ? x : -x; }



typedef struct {
  int   id_master;
  uint  counter;
  uint  control;
} TB_control_t;

static
__forceinline__ __host__ void
__init_ThreadBlocks__ ( TB_control_t * TB_device, const int n, const cudaStream_t stream )
{
  cudaMemsetAsync( TB_device, 0, sizeof(TB_control_t)*n, stream );
}

static
__forceinline__ __device__ int
get_block_id ( TB_control_t * TB_device )
{
  extern __shared__ double shmem[];
  int * const comm = (int *)&shmem[0];
  __syncwarp ( ); __syncthreads ( );
  if ( threadIdx.x == 0 ) {
    *comm = atomicAdd ( & TB_device->id_master, 1 );
  } __syncwarp ( ); __syncthreads ( );
  const int block_id = *comm;
  __syncwarp ( ); __syncthreads ( );
  return block_id;
}

static
__forceinline__ __device__ void
__arrive_ThreadBlocks__ ( const uint key, TB_control_t * TB_device, const int min_MPs )
{
#if 1
  asm volatile (
                "{\n\t"
                ".reg.pred\t%pp;\n\t"
                ".reg.b32\t%temp;\n\t"

                "mov.b32\t%temp, %tid.x;\n\t"
                "setp.eq.s32\t%pp, %temp, 0;\n\t"
                "@%pp atom.global.inc.u32\t%temp, [%1], %0;\n\t"
                "setp.eq.and.s32\t%pp, %temp, %0, %pp;\n\t"
                "@%pp red.global.or.b32\t[%1+4], %2;\n\t"
                "}" : : "r"(min_MPs-1), "l"(&TB_device->counter), "r"(key) );
#else
  if ( threadIdx.x == 0 ) {
    const uint T = (uint)(min_MPs - 1);
    if ( atomicInc( & TB_device->counter, T ) == T ) {
      asm volatile ( "red.global.or.b32\t[%0], %1;"
      : : "l"( &TB_device->control), "r"(key) );
    }
  }
#endif
}

static
__forceinline__ __device__ void
__weaksync_ThreadBlocks__ ( const uint key, TB_control_t * TB_device, const int timeout )
{
#if 1
  asm volatile (
                "{\n\t"
                ".reg.pred\t%pp;\n\t"
                ".reg.b32\t%temp;\n\t"

                "mov.u32\t%temp, %tid.x;\n\t"
                "setp.eq.s32\t%pp, %temp, 0;\n"
        "LOOP_:\n\t"
                "@%pp atom.global.or.b32\t%temp, [%0], 0;\n\t"
                "setp.ne.and.s32\t%pp, %1, %temp, %pp;\n\t"
                "@%pp bra\tLOOP_;\n"
        "EXIT_:\n\t"
                "}" :: "l"(&TB_device->control), "r"(key) );
#else
  if ( (threadIdx.x & (32-1)) == 0 ) {
    int wait = 1;
#pragma unroll 1
    while ( true ) {
      const int key_ = atomicOr( & TB_device->control, 0 );
      if ( key_ == key ) break;
      wait = min( wait << 1, 128 );
    }
  }
#endif
  __threadfence();
  __syncwarp ( ); __syncthreads ( );
}

static
__forceinline__ __device__ void
__reset_ThreadBlocks__ ( const int N, TB_control_t * TB_device )
{
  extern __shared__ double shmem[];
  int * const comm = (int *)&shmem[0];
  const uint T = (uint)(gridDim.x - 1);
  if ( threadIdx.x == 0 ) {
     *comm = atomicInc( & TB_device[N].counter, T );
  } __syncwarp ( ); __syncthreads ( );
  if ( *comm == T && threadIdx.x <= N ) {
     TB_device[threadIdx.x] = (TB_control_t){ 0, 0, 0 };
     __threadfence_system();
  } __syncwarp ( ); __syncthreads ( );
}


static
__forceinline__ __host__ uint4
gen_random_keys( uint4 & last_key )
{
  uint seed;
  while ( 1 ) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    seed = (uint)(ts.tv_nsec & 0xffffffff);
    if ( seed != last_key.x ) break;
  }
  srand(seed);

  uint4 key;
  key.x = seed;
  key.y = rand();
  key.z = rand();
  key.w = rand();

  return (last_key = key);
}

#define	TASK_LOOP(id, N) \
	while ( (global_id = get_block_id( TB_device+(id) )) < (N) ) {
#define	TASK_WAIT(id, N, d) \
        __arrive_ThreadBlocks__ ( key.d, TB_device+(id), (N) ); \
      } __weaksync_ThreadBlocks__ ( key.d, TB_device+(id), 0 )
#define	TASK_RESET(N) \
	__reset_ThreadBlocks__( (N), TB_device )



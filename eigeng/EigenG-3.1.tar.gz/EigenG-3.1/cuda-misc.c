#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdint.h>
#include "cublas.h"

#include "aspen.h"
#include "fortran.h"


static cudaStream_t stream_for_ASPEN = NULL;
cudaStream_t ASPEN_get_Stream(void);

static cudaStream_t extra_stream = NULL;
cudaStream_t get_extra_stream(void)
{
    return extra_stream;
}

static cublasHandle_t cublas_handler = NULL;
cublasHandle_t get_cublas_handler(void)
{
    return cublas_handler;
}

void
aspen_dsymv_(const char *uplo, const int *n,
                   const double *alpha,
                   const devptr_t *devPtrA, const int *lda,
                   const devptr_t *devPtrx, const int *incx,
                   const double *beta,
                   const devptr_t *devPtry, const int *incy)
{
    double *A = (double *)(uintptr_t)(*devPtrA);
    double *x = (double *)(uintptr_t)(*devPtrx);
    double *y = (double *)(uintptr_t)(*devPtry);

    ASPEN_dsymv( *uplo, *n,
	*alpha, A, *lda, x, *incx, *beta,  y, *incy );
}

void
dzero_(devptr_t *devPtrA, int *n)
{
    double *A = (double *)(uintptr_t)(*devPtrA);
    ASPEN_DZERO( A, *n );
}

void
aspen_init_(int *n)
{
    ASPEN_init( *n );
    stream_for_ASPEN = ASPEN_get_Stream( );
    cudaStreamCreate( &extra_stream );
    cublasCreate_v2( &cublas_handler );
    cublasSetStream_v2( cublas_handler, stream_for_ASPEN );
}

void
aspen_shutdown_(void)
{
    cudaStreamDestroy( extra_stream );
    cublasDestroy_v2( cublas_handler );
    ASPEN_shutdown( );
}

void
cuda_set_device_(const int *ID)
{
    int id = *ID;
    cudaSetDevice( id );
}

void
cuda_sync_device_(void)
{
    cudaDeviceSynchronize( );
}

int
cuda_alloc_(devptr_t *devPtrA, const long *nbytes)
{
    void *A;
    cudaError_t err_code = cudaMalloc( &A, (size_t)(*nbytes) );
    if ( err_code != cudaSuccess ) { A = NULL; }
    *devPtrA = (uintptr_t)A;
    return ( err_code == cudaSuccess ? 0 : 1 );
}

int
cuda_alloc_available_(devptr_t *devPtrA, const long *reqbytes, long *nbytes)
{
  size_t mf, ma;
  cudaMemGetInfo(&mf, &ma);
  size_t mm = ((size_t)((double)mf * 0.9) & 0xffffffffffff0000);
  if ( (*reqbytes) > 0 ) {
    mf = ((*reqbytes) < mm ? (*reqbytes) : mm);
  } else {
    mf = mm;
  }
  void *A;
  cudaError_t err_code = cudaMalloc( &A, mf );
  if ( err_code != cudaSuccess ) {
    cudaFree( A ); A = NULL; mf = 0;
  }
  *devPtrA = (uintptr_t)A;
  *nbytes  = mf;
  return ( err_code == cudaSuccess ? 0 : 1 );
}

void
cuda_free_(devptr_t *devPtrA)
{
    cudaFree( (void *)(uintptr_t)(*devPtrA) );
    *devPtrA = NULL;
}

void
cuda_set_vector_(const long *n, const long *eSize, const void *x, devptr_t *devPtrY)
{
    void *y = (void *)(uintptr_t)(*devPtrY);
    cudaMemcpyAsync( y, x, (*n)*(*eSize),
        cudaMemcpyHostToDevice, stream_for_ASPEN );
}

void
cuda_get_vector_(const long *n, const long *eSize, const devptr_t *devPtrX, void *y )
{
    const void *x = (void *)(uintptr_t)(*devPtrX);
    cudaMemcpyAsync( y, x, (*n)*(*eSize),
        cudaMemcpyDeviceToHost, stream_for_ASPEN );
}


void
cuda_sync_( const int *option )
{
    switch ( *option ) {
    case 0:
        cudaDeviceSynchronize( );
	break;
    case 1:
        cudaStreamSynchronize( stream_for_ASPEN );
	break;
    default:
        /* nothing to do */
	break;
    }
}


void
cuda_set_matrix_(const long *m, const long *n, const long *eSize, const void *x, const long *ldx, devptr_t *devPtrY, const long *ldy)
{
    void *y = (void *)(uintptr_t)(*devPtrY);
    for(long i=0; i<(*n); i++) {
        void *yy = (void *)((uintptr_t)y + ((*ldy)*(*eSize))*i);
        void *xx = (void *)((uintptr_t)x + ((*ldx)*(*eSize))*i);
        cudaMemcpyAsync( yy, xx, (*m)*(*eSize),
            cudaMemcpyHostToDevice, stream_for_ASPEN );
    }
}

void
cuda_get_matrix_(const long *m, const long *n, const long *eSize, const devptr_t *devPtrX, const long *ldx, void *y, const long *ldy )
{
    const void *x = (void *)(uintptr_t)(*devPtrX);
    for(long i=0; i<(*n); i++) {
        void *yy = (void *)((uintptr_t)y + (*ldy)*(*eSize)*i);
        void *xx = (void *)((uintptr_t)x + (*ldx)*(*eSize)*i);
        cudaMemcpyAsync( yy, xx, (*m)*(*eSize),
            cudaMemcpyDeviceToHost, stream_for_ASPEN );
    }
    cudaStreamSynchronize( stream_for_ASPEN );
}

void oo_(void)
{
  size_t mf, ma;
  cudaMemGetInfo(&mf, &ma);
  printf("Free %lx [Byte], All %lx [Byte]\n", mf, ma);
}


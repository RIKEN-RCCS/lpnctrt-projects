#if !defined(HH_BUFFER_H)
#define	HH_BUFFER_H

#include "hh_misc.h"


long
hhsy2tr_buffersize_(
  int    * n_,
  int    * lda_,
  int    * mb_
);

long
dc_buffersize_(
  int * n_,
  int * ldz_
);

long
hhtr2sy_buffersize_(
  int * n_,
  int * nv_,
  int * lda_,
  int * ldz_,
  int * mb_
);

long
eigen_buffersize_(
  int *n_,
  int *nvec_,
  int *lda_,
  int *ldz_,
  int *mf_,
  int *mb_
);

#endif

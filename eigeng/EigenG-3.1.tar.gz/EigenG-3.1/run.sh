#!/bin/sh

export GPU_CPU_RATE="10 0"
export OMP_NUM_THREADS=8

#for b in 2 3 4 8 16 24 32 40 48 64 1; do
for b in 64; do
	awk '{ sub(/ 24 /, " '$b' "); print }' IN0 > INx
	./a.out < INx | tee log-1080-5e-$b
done


!=
      real(8) :: TRBK_TIME_BCAST
      real(8) :: TRBK_TIME_REDUC
      real(8) :: TRBK_TIME_FR
      real(8) :: TRBK_TIME_TRBK1
      real(8) :: TRBK_TIME_TRBK1x
      real(8) :: TRBK_TIME_TRBK1y
      real(8) :: TRBK_TIME_TRBK2
      integer(kind=omp_lock_kind) :: TRBK_LOCK(1:2)
      integer :: DO_OVERLAP_BCAST_LEVEL
      integer :: TRBK_TIME_COUNTER
      integer :: TRBK_TIME_INTERVAL
      integer :: TRBK_TIME_NEXT
      integer :: TRBK_SWITCHED
!=
      common /TRBAK/
     &               TRBK_TIME_BCAST,
     &               TRBK_TIME_REDUC,
     &               TRBK_TIME_FR,
     &               TRBK_TIME_TRBK1,
     &               TRBK_TIME_TRBK1x,
     &               TRBK_TIME_TRBK1y,
     &               TRBK_TIME_TRBK2,
     &               TRBK_LOCK,
     &               DO_OVERLAP_BCAST_LEVEL,
     &               TRBK_TIME_COUNTER,
     &               TRBK_TIME_INTERVAL,
     &               TRBK_TIME_NEXT,
     &               TRBK_SWITCHED



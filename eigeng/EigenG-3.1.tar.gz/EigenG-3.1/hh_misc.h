#if !defined(HH_MISC_H)
#define	HH_MISC_H

#define	T	double


typedef struct {
  int   id_master;
  uint  counter;
  uint  control;
} TB_control_t;

//
// CUDA_PTR__MANAGE is the common name declaired in trd.h
// fortran common storage to be shared with C and C++ modules.
//
struct cuda_ptr_manage {
   double *devPtr;
   long size;
   double *devPtr_1;
   double *devPtr_2;
   double *devPtr_3;
   double *devPtr_4;
};

extern struct cuda_ptr_manage cuda_ptr_manage_;
cudaStream_t get_extra_stream(void);
cublasHandle_t get_cublas_handler(void);

cudaStream_t ASPEN_get_Stream( void );
void ASPEN_dsymv( char, int, double, double *, int, double *, int, double, double *, int);
void t3xx( const int i, const int mdone, double * dev_ux, const int ldu, double * vb, const int ldv, double * d_i, double * e_i, double * workspace, TB_control_t * TB_, cudaStream_t stream );
void t6xx( const int i, double * beta, double * dev_ux, double * dev_vx, cudaStream_t stream );

//-- int32 -> int64 conversion
//   is automatically done when arguments are passed to the functions
__inline__ size_t size1( const size_t dim0 ) { return dim0; }
__inline__ size_t size2( const size_t dim0, const size_t dim1 ) { return dim0 * dim1; }
//--

//--
__inline__ int min(const int x, const int y) { return x<=y ? x : y; }
__inline__ int max(const int x, const int y) { return x>=y ? x : y; }
//--

void zero_triangle_gpu( int const n, double *a, int const lda, cudaStream_t const stream );
void mul_diag_gpu( int const n, double *x, int const incx, cudaStream_t const stream);

__inline__
void zero_triangle( int const n, double *a, int const lda )
{
  _Pragma("omp parallel for")
  for(int i=0; i<n; i++) {
  for(int j=i; j<n; j++) {
    long const pos = (long)j+size2(i,lda);
    *(a+pos) = 0.;
  }
  }
}

__inline__
void mul_diag( int const n, double *x, int const incx ) {
  _Pragma("omp parallel for")
  for(int i=0; i<n; i++) {
    long const pos = size2(i,incx);
    double t = *(x+pos)/2;
    *(x+pos) = (t == 0. ? 1. : t);
  }
}


#endif


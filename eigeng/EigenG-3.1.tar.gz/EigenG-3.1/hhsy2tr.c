#include <cuda.h>
#include <cuda_runtime.h>
#include <cublas.h>
#include <stdio.h>
#include <math.h>

#include "hh_buffer.h"


void
hhsy2tr (
  int const n_,
  T * const a_host,
  int const lda_,
  T * const d_host,
  T * const e_host,
  int const mb_,
  T * const ROOT_dev,
  cudaStream_t const stream
)
{
  int const n   = n_;
  int const lda = lda_;
  int const mb  = min(mb_, n - 1);

#define	A(i,j)	*( a_host + size1((i)-1) + size2((j)-1,lda) )
#define	D(i)	*( d_host + size1((i)-1) )
#define	E(i)	*( e_host + size1((i)-1) )

#define	a(i,j)	*( a_dev  + size1((i)-1) + size2((j)-1,lda) )
#define	d(i)	*( d_dev  + size1((i)-1) )
#define	e(i)	*( e_dev  + size1((i)-1) )
#define	uu(i,j)	*( uu_dev + size1((i)-1) + size2((j)-1,ldu) )
#define	vv(i,j)	*( vv_dev + size1((i)-1) + size2((j)-1,ldv) )
#define	u(i)	*( u_dev  + size1((i)-1) )
#define	v(i)	*( v_dev  + size1((i)-1) )
#define	ub(i)	*( ub_dev + size1((i)-1) )
#define	vb(i)	*( vb_dev + size1((i)-1) )

#define	USE_ASPEN	(1)
#if USE_ASPEN
#define	SYMV_U(...)	ASPEN_dsymv('U', __VA_ARGS__)
#else
#define	SYMV_U(...)	cublasDsymv_v2(handle, CUBLAS_FILL_MODE_UPPER, __VA_ARGS__)
#endif
#define	SYR2K_UN(...)	cublasDsyr2k_v2(handle, CUBLAS_FILL_MODE_UPPER, CUBLAS_OP_N, __VA_ARGS__)



  T const ONE  = (T)(1);
  T const ZERO = (T)(0);

  if (n <= 0) {
    return;
  }

  if (n == 1) {
    D(1) = A(1,1);
    E(1) = ZERO;
    return;
  }

  if (n == 2) {
    const T t = fabs(A(1,2));
    D(1) = A(1,1);
    D(2) = A(2,2);
    A(1,1) = ZERO;
    A(2,2) = -t;
    A(1,2) = 2*t;
    E(1) = ZERO;
    E(2) = -t;
    return;
  }

{
  T * a_dev  = ROOT_dev;
  T * d_dev  = a_dev  + size2(lda,n);
  T * e_dev  = d_dev  + size1(lda);
  T * vv_dev = e_dev  + size1(lda);
  T * beta   = vv_dev + size2(lda,mb);
  T * workspace_dev = beta + size1(1);
  TB_control_t * task_control_dev = (TB_control_t *)(workspace_dev + size1(mb)*2);
  T * uu_dev = NULL;

  cublasHandle_t handle = get_cublas_handler();
  cudaStream_t dpipe = get_extra_stream();

  cudaMemcpyAsync( &a(1,1), &A(1,1), size2(n,lda)*sizeof(T),
		cudaMemcpyHostToDevice, stream );

  int const ib0 = (n - 1) / mb + 1;
  int const ib1 = max(1, 2 - mb);
  int cond_i = n;
  int nxx = 0;

  for(int ib=ib0; ib>=ib1; ib--) {

    //
    // Regular panel distribution [1:i1] x [i0+1,i1]
    //
    //   u(:,1:m0) => map on to a(:,i0+1:i1), i1=i0+m0
    //   v(:,1:m0) => map on to vv(:,1:m0), ldv=ceil(i0+mb,8)
    //
    //      0 1         i0    i1
    //        v         v     v
    //       +-----+-----+-----+
    //     1>|     |     |o o o|
    //       |     |     |o o o|
    //    i0>|     |     |o o o|
    //       +-----+-----+-----+
    //       |     |     |o o o|
    //       |     |     |  o o|
    //    i1>|     |     |    o|
    //       +-----+-----+-----+
    //

    int const i0 = (ib - 1) * mb;
    int const i1 = min(i0 + mb, n);

    int const m0 = i1 - i0;
    int const m1 = max(1, 2 * (2 - ib));

    int const ldu = lda;
    int const ldv = min(((i0 + mb - 1) / 8 + 1) * 8, lda);

    uu_dev = &a(1, i0+1);

    for(int m=m0; m>=m1; m--) {

      int const mdone = m0 - m;
      int const i = i0 + m;
      int const l = i - 1;

      T * const u_dev = &uu(1, m);
      T * const v_dev = &vv(1, m);

      //
      // new t3xx combined 4 kernels implemented as device kernels originally.
      // [t3xx]
      //  u = u + U V[i,:]^T + V U[i,:]^T
      // [t4xx] and [t5xx]
      //  v = (U V^T + V U^T) u
      // [t6xx] as well
      //  v = v * beta
      //  gamma = (u, v) * beta / 2
      //  v = gamma * u + v
      //
      // t6xx is also merged into t3xx
      // and the trailing one is moved in front of SYR2K
      //
      //
      // This source does not care the case of tiny norm
      // as LAPACK or other libraries do rescale by ONE/SAFEMIN
      // but scale vector u by ONE/uL is employed to avoid over/
      // under-flow
      //
      //
      {
        t3xx( i, mdone, &u(1), ldu, &v(1), ldv, &d(i), &e(i),
		       	workspace_dev, task_control_dev, stream );
      }

      //
      // v = A u + v
      //
      {
        const T alpha = (mdone > 0 ? ONE : ZERO);
#if USE_ASPEN
        SYMV_U(l, ONE, &a(1,1), lda, &u(1), 1, alpha, &v(1), 1);
#else
        SYMV_U(l,&ONE, &a(1,1), lda, &u(1), 1,&alpha, &v(1), 1);
#endif
      }

    }

    {
      int mx = i0+m1-1;
      int nx = m0-m1+1;

      if ( 1 ) {
        nxx += nx;
        const int DDX = 10000;
        if ( min( mx, nxx ) >= DDX ) {
          cudaStreamSynchronize( stream );
          cudaMemcpyAsync( &A(1,mx+1), &a(1,mx+1), size2(lda,nxx)*sizeof(T),
                           cudaMemcpyDeviceToHost, dpipe );
          nxx = 0;
          cond_i = mx;
        }
      }

      //
      // A = A + UV^t + VU^t
      //

      T * const u_dev = &uu(1, m1);
      T * const v_dev = &vv(1, m1);

      t6xx( mx, beta, &u(1), &v(1), stream );
      SYR2K_UN(mx, nx, &ONE, &u(1), ldu, &v(1), ldv, &ONE, &a(1,1), lda);

    }

  }

  {
    cudaStreamSynchronize( stream );

    cudaMemcpyAsync( &D(2), &d(2), size1(n-1)*sizeof(T),
		cudaMemcpyDeviceToHost, dpipe );
    cudaMemcpyAsync( &E(2), &e(2), size1(n-1)*sizeof(T),
		cudaMemcpyDeviceToHost, dpipe );
    cudaMemcpyAsync( &A(1,1), &a(1,1), size2(cond_i,lda)*sizeof(T),
		cudaMemcpyDeviceToHost, dpipe );

    cudaStreamSynchronize( dpipe );

    D(1) =  A(1,1);
    E(1) =  ZERO;
  }

}

#undef	a
#undef	d
#undef	e
#undef	uu
#undef	vv
#undef	u
#undef	v
#undef	ub
#undef	vb

#undef	SYMV_U
#undef	SYR2K_UN
}


void
hhsy2tr_ (
  int    * n_,
  double * a_,
  int    * lda_,
  double * d_,
  double * e_,
  int    * mb_
)
{

  const cudaStream_t stream = ASPEN_get_Stream();

  double * ROOT_dev = NULL;
  if ( cuda_ptr_manage_.devPtr == NULL ) {
    if ( *n_ >= 3 ) {
      size_t len = hhsy2tr_buffersize_( n_, lda_, mb_ );
      cudaError_t err_code = cudaMallocAsync( (void *)&ROOT_dev, len, stream );
      if ( err_code != cudaSuccess ) {
        fprintf(stderr, "Memory allocation fault [HHSY2TR]\n");
        fflush(stderr);
        exit(1);
      }
    }
  } else {
    ROOT_dev = (double *)cuda_ptr_manage_.devPtr;
  }

  hhsy2tr ( *n_, a_, *lda_, d_, e_, *mb_, ROOT_dev, stream );

  if ( cuda_ptr_manage_.devPtr == NULL ) {
    if ( *n_ >= 3 ) {
      cudaFreeAsync( ROOT_dev, stream );
    }
  }
}


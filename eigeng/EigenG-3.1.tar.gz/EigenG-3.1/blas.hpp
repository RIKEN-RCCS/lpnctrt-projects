// BLAS fortran routines
extern "C" {

// float
  float snrm2_( int *,... );
  float sdot_( int *,... );
  void scopy_( int *, ... );
  void sscal_( int *,... );
  void saxpy_( int *,... );
  void sgemv_( const char*, ... );
  void ssymv_( const char*, ... );
  void ssyr2k_( const char*, ... );

// double
  double dnrm2_( int *,... );
  double ddot_( int *,... );
  void dcopy_( int *, ... );
  void dscal_( int *,... );
  void daxpy_( int *,... );
  void dgemv_( const char*, ... );
  void dsymv_( const char*, ... );
  void dsyr2k_( const char*, ... );
}


float Nrm2( int n, float* x, int incx ) { return snrm2_( &n, x, &incx ); }
double Nrm2( int n, double* x, int incx ) { return dnrm2_( &n, x, &incx ); }

float Dot( int n, float* x, int incx, float *y, int incy ) { return sdot_( &n, x, &incx, y, &incy ); }
double Dot( int n, double* x, int incx, double *y, int incy ) { return ddot_( &n, x, &incx, y, &incy ); }

void Copy( int n, float* x, int incx, float* y, int incy ) { scopy_( &n, x, &incx, y, &incy ); }
void Copy( int n, double* x, int incx, double* y, int incy ) { dcopy_( &n, x, &incx, y, &incy ); }

void Scal( int n, float alpha, float* x, int incx ) { sscal_( &n, &alpha, x, &incx ); }
void Scal( int n, double alpha, double* x, int incx ) { dscal_( &n, &alpha, x, &incx ); }

void Axpy( int n, float alpha, float* x, int incx, float *y, int incy ) { saxpy_( &n, &alpha, x, &incx, y, &incy ); }
void Axpy( int n, double alpha, double* x, int incx, double *y, int incy ) { daxpy_( &n, &alpha, x, &incx, y, &incy ); }

void Gemv( const char *tra, int m, int n, float alpha, float *a, int lda, float *x, int incx, float beta, float *y, int incy ) { sgemv_( tra, &m, &n, &alpha, a, &lda, x, &incx, &beta, y, &incy ); }
void Gemv( const char *tra, int m, int n, double alpha, double *a, int lda, double *x, int incx, double beta, double *y, int incy ) { dgemv_( tra, &m, &n, &alpha, a, &lda, x, &incx, &beta, y, &incy ); }

void Symv( const char *uplo, int n, float alpha, float *a, int lda, float *x, int incx, float beta, float *y, int incy ) { ssymv_( uplo, &n, &alpha, a, &lda, x, &incx, &beta, y, &incy ); }
void Symv( const char *uplo, int n, double alpha, double *a, int lda, double *x, int incx, double beta, double *y, int incy ) { dsymv_( uplo, &n, &alpha, a, &lda, x, &incx, &beta, y, &incy ); }

void Syr2k( const char *uplo, const char *tra, int m, int n, float alpha, float *x, int ldx, float *y, int ldy, float beta, float *a, int lda ) { ssyr2k_( uplo, tra, &m, &n, &alpha, x, &ldx, y, &ldy, &beta, a, &lda ); }
void Syr2k( const char *uplo, const char *tra, int m, int n, double alpha, double *x, int ldx, double *y, int ldy, double beta, double *a, int lda ) { dsyr2k_( uplo, tra, &m, &n, &alpha, x, &ldx, y, &ldy, &beta, a, &lda ); }

extern "C" void
  ASPEN_dsymv (
               const char                uplo,
               const int                 n,
               const double              alpha,
               const double            * a,
               const int                 lda,
               const double            * x,
               const int                 incx,
               const double              beta,
               double            * y,
               const int                 incy
               );


